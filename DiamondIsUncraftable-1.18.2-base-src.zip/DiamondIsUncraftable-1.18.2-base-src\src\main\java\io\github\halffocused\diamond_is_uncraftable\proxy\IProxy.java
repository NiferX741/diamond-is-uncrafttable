package io.github.halffocused.diamond_is_uncraftable.proxy;

import net.minecraft.world.entity.player.Player;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;

public interface IProxy {
    Player getPlayer();

    Level getWorld();

    MinecraftServer getServer();
}
