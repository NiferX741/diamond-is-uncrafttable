package io.github.halffocused.diamond_is_uncraftable.capability;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandChunkEffectCapabilityPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class StandChunkEffects implements ICapabilitySerializable<Tag> {
    public static final Capability<StandChunkEffects> STAND_CHUNK_EFFECTS = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<StandChunkEffects> STORAGE;
    private final ChunkPos chunk;
    private final Level world;
    private LazyOptional<StandChunkEffects> holder = LazyOptional.of(() -> new StandChunkEffects(getWorld(), getChunk()));
    private Map<UUID, BlockPos> bombs = new ConcurrentHashMap<>();
    private Map<UUID, ArrayBlockingQueue<BlockPos>> soundEffects = new ConcurrentHashMap<>();
    private List<BlockPos> destroyedPositions = new ArrayList<>();

    public StandChunkEffects(Level world, ChunkPos chunk) {
        this.world = world;
        this.chunk = chunk;
    }

    public static LazyOptional<StandChunkEffects> getLazyOptional(LevelChunk chunk) {
        return chunk.getCapability(STAND_CHUNK_EFFECTS);
    }

    public static StandChunkEffects getCapabilityFromChunk(LevelChunk chunk) {
        return getLazyOptional(chunk).orElse(new StandChunkEffects(chunk.getLevel(), chunk.getPos()));
    }

    public static void register() {
        STORAGE = new CapStorage<StandChunkEffects>() {
            @Override
            public Tag writeNBT(Capability<StandChunkEffects> capability, StandChunkEffects instance, Direction side) {
                CompoundTag nbt = new CompoundTag();
                ListTag bombList = new ListTag();
                instance.bombs.forEach(((uuid, pos) -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putUUID("standUser", uuid);
                    compoundNBT.putDouble("blockPosX", pos.getX());
                    compoundNBT.putDouble("blockPosY", pos.getY());
                    compoundNBT.putDouble("blockPosZ", pos.getZ());
                    bombList.add(compoundNBT);
                }));
                nbt.put("bombs", bombList);
                ListTag soundList = new ListTag();
                instance.soundEffects.forEach(((uuid, list) -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putUUID("standUser", uuid);
                    ListTag listNBT = new ListTag();
                    list.forEach(pos -> {
                        CompoundTag compound = new CompoundTag();
                        compound.putDouble("blockPosX", pos.getX());
                        compound.putDouble("blockPosY", pos.getY());
                        compound.putDouble("blockPosZ", pos.getZ());
                        listNBT.add(compound);
                    });
                    compoundNBT.put("blockPosList", listNBT);
                    soundList.add(compoundNBT);
                }));
                nbt.put("sounds", soundList);
                ListTag positionList = new ListTag();
                instance.destroyedPositions.forEach(pos -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putDouble("blockPosX", pos.getX());
                    compoundNBT.putDouble("blockPosY", pos.getY());
                    compoundNBT.putDouble("blockPosZ", pos.getZ());
                    positionList.add(compoundNBT);
                });
                nbt.put("positions", positionList);
                return nbt;
            }

            @Override
            public void readNBT(Capability<StandChunkEffects> capability, StandChunkEffects instance, Direction side, Tag nbt) {
                CompoundTag compoundNBT = (CompoundTag) nbt;
                compoundNBT.getList("bombs", Tag.TAG_COMPOUND).forEach(compound -> {
                    if (compound instanceof CompoundTag && ((CompoundTag) compound).contains("blockPosX"))
                        instance.bombs.put(compoundNBT.getUUID("standUser"), new BlockPos(((CompoundTag) compound).getDouble("blockPosX"), ((CompoundTag) compound).getDouble("blockPosY"), ((CompoundTag) compound).getDouble("blockPosZ")));
                });
                compoundNBT.getList("sounds", Tag.TAG_COMPOUND).forEach(compound -> {
                    if (compound instanceof CompoundTag && ((CompoundTag) compound).contains("standUser")) {
                        ArrayBlockingQueue<BlockPos> list = new ArrayBlockingQueue<>(1000);
                        ((CompoundTag) compound).getList("blockPosList", Tag.TAG_COMPOUND).forEach(inbt -> {
                            if (inbt instanceof CompoundTag && ((CompoundTag) inbt).contains("blockPosX"))
                                list.add(new BlockPos(((CompoundTag) compound).getDouble("blockPosX"), ((CompoundTag) compound).getDouble("blockPosY"), ((CompoundTag) compound).getDouble("blockPosZ")));
                        });
                        instance.soundEffects.put(compoundNBT.getUUID("standUser"), list);
                    }
                });
                compoundNBT.getList("positions", Tag.TAG_COMPOUND).forEach(compound -> {
                    if (compound instanceof CompoundTag && ((CompoundTag) compound).contains("blockPosX"))
                        instance.destroyedPositions.add(new BlockPos(((CompoundTag) compound).getDouble("blockPosX"), ((CompoundTag) compound).getDouble("blockPosY"), ((CompoundTag) compound).getDouble("blockPosZ")));
                });
            }
        };
    }

    public ChunkPos getChunk() {
        return chunk;
    }

    public Level getWorld() {
        return world;
    }

    public void addBombPos(Player player, BlockPos blockPos) {
        bombs.put(player.getUUID(), blockPos);
        onDataUpdated();
    }

    public void removeBombPos(Player player) {
        bombs.remove(player.getUUID());
        onDataUpdated();
    }

    public Map<UUID, BlockPos> getBombs() {
        return bombs;
    }

    public Map<UUID, ArrayBlockingQueue<BlockPos>> getSoundEffects() {
        return soundEffects;
    }

    public void addSoundEffect(Player player, BlockPos pos) {
        if (!soundEffects.containsKey(player.getUUID())) {
            ArrayBlockingQueue<BlockPos> list = new ArrayBlockingQueue<>(1000);
            list.add(pos);
            soundEffects.put(player.getUUID(), list);
        } else
            soundEffects.get(player.getUUID()).add(pos);
        onDataUpdated();
    }

    public void removeSoundEffect(Player player, BlockPos pos) {
        soundEffects.get(player.getUUID()).remove(pos);
        onDataUpdated();
    }

    public void addDestroyedPosition(@Nonnull BlockPos pos) {
        destroyedPositions.add(pos);
        onDataUpdated();
    }

    public void removeDestroyedPosition(@Nonnull BlockPos pos) {
        destroyedPositions.remove(pos);
        onDataUpdated();
    }

    public List<BlockPos> getDestroyedPositions() {
        return destroyedPositions;
    }

    private void onDataUpdated() {
        if (world.isClientSide) return;
        if (world.getChunkSource().hasChunk(chunk.x, chunk.z)) {
            LevelChunk chunk = world.getChunk(this.chunk.x, this.chunk.z);
            chunk.setUnsaved(true);
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_CHUNK.with(() -> chunk), new SSyncStandChunkEffectCapabilityPacket(this));
        }
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == STAND_CHUNK_EFFECTS ? holder.cast() : LazyOptional.empty();
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(STAND_CHUNK_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(STAND_CHUNK_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }
}
