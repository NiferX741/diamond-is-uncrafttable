package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CAerosmithRotationPacket implements IMessage<CAerosmithRotationPacket> {
    private int entityID;
    private float yaw, pitch, yawHead;

    public CAerosmithRotationPacket(int entityID, float yaw, float pitch, float yawHead) {
        this.entityID = entityID;
        this.yaw = yaw;
        this.pitch = pitch;
        this.yawHead = yawHead;
    }

    public CAerosmithRotationPacket() {
    }

    @Override
    public void encode(CAerosmithRotationPacket message, FriendlyByteBuf buffer) {
        buffer.writeInt(message.entityID);
        buffer.writeFloat(message.yaw);
        buffer.writeFloat(message.pitch);
        buffer.writeFloat(message.yawHead);
    }

    @Override
    public CAerosmithRotationPacket decode(FriendlyByteBuf buffer) {
        return new CAerosmithRotationPacket(buffer.readInt(), buffer.readFloat(), buffer.readFloat(), buffer.readFloat());
    }

    @Override
    public void handle(CAerosmithRotationPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ctx.get().getSender();
                if (sender == null) return;
                Entity entity = sender.level.getEntity(message.entityID);
                if (entity instanceof LivingEntity) {
                    entity.setYRot(message.yaw);
                    entity.setXRot(message.pitch);
                    ((LivingEntity) entity).yHeadRot = message.yawHead;
                }
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
