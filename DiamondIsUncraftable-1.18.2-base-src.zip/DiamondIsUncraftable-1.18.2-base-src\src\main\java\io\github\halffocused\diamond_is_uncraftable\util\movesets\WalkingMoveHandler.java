package io.github.halffocused.diamond_is_uncraftable.util.movesets;


import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SAnimatePacket;
import io.github.halffocused.diamond_is_uncraftable.util.ICommandGrab;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.ChatFormatting;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;

public class WalkingMoveHandler {

    private enum Targeting {WITH_MASTER, ALL, HOSTILE_ONLY, PLAYERS_ONLY}

    Targeting currentTargeting = Targeting.WITH_MASTER;

    Stance.WalkingMove nextMove = null;
    private final AbstractStandEntity stand;
    ArrayList<Stance> stanceList = new ArrayList<>();
    int activeStanceId;
    LivingEntity currentTarget = null; //null if no target
    boolean walkingOrIdle = false; // true if walking
    boolean outOfRange = false;
    boolean tooFar = false;
    boolean tooClose = false;
    String lastAnimation = "joejan";
    String currentAnimation = "";
    int attackCooldown = 10;

    /*
    Command grab stuff :/
     */
    boolean hasCommandGrab;
    LivingEntity commandGrabEntity = null;


    public WalkingMoveHandler(AbstractStandEntity standIn, int defaultStance){
        stand = standIn;
        activeStanceId = defaultStance;
        hasCommandGrab = standIn instanceof ICommandGrab;
    }

    public WalkingMoveHandler addStance(Stance stanceIn){
        stanceList.add(stanceIn);
        return this;
    }

    public Stance getActiveStance(){
        for(Stance stance : stanceList){
            if(stance.getId() == activeStanceId){
                return stance;
            }
        }
        return null; //Should never, ever, happen :)
    }

    public int getActiveStanceId(){
        return getActiveStance().getId();
    }

    public void setActiveStance(int activeStanceId) {
        if(getActiveStanceId() != activeStanceId) {
            this.activeStanceId = activeStanceId;
            currentTarget = null;
        }
    }

    public boolean isMoveActive(){
        for(Stance.WalkingMove move : getActiveStance().getMoves()){
            if(move.move.getFramedata().isActive()){
                return true;
            }
        }
        return false;
    }

    public Stance.WalkingMove getActiveMove(){
        for(Stance.WalkingMove move : getActiveStance().getMoves()){
            if(move.move.getFramedata().isActive()){
                return move;
            }
        }
        return null;
    }

    public void tick(boolean attackKeyDown, boolean specialKeyDown){
        if(stand.level.isClientSide){return;}


        if(stand instanceof ICommandGrab) {
            if (commandGrabEntity != null) {
                if (commandGrabEntity.isAlive()) {
                    double distance = ((ICommandGrab) stand).commandGrabDistance();
                    Vec3 positionVector = this.stand.position().add(this.stand.getLookAngle().normalize().multiply(distance, distance, distance));
                    commandGrabEntity.setPos(positionVector.x,positionVector.y,positionVector.z);
                }
            }
        }

        if(attackCooldown == 1){
            nextMove = null;
        }

        pickTarget();
        if(commandGrabEntity == null) {
            handleMovement();
        }
        handleAnimations();
        Stand.getLazyOptional(stand.getMaster()).ifPresent(stand -> {
            stand.setPreventUnsummon(currentTarget != null);
        });

        if(currentTarget != null) {
            if (!currentTarget.isAlive()) {
                currentTarget = null;
            }
        }

        attackCooldown = Math.max(0, attackCooldown - 1);

        for(Stance.WalkingMove walkingMove : getActiveStance().getMoves()){ //Tick active moves
            if(walkingMove.move.getFramedata().isActive()){
                walkingMove.move.getFramedata().attackTick(stand);
            }
        }
    }

    public void setMoveActive(int id){
            for (Stance.WalkingMove Wmove : getActiveStance().getMoves()) {
                if (Wmove.move.getId() == id) {
                    Wmove.move.getFramedata().initAttack();
                    attackCooldown = Wmove.cooldown + Wmove.move.getFramedata().getAttackDuration();
                }
            }
    }


    private void handleMovement(){

        if (currentTarget == null) { //No target, automatically follows master
            if (stand.distanceTo(stand.getMaster()) > getActiveStance().getWanderDistanceMax()) {
                outOfRange = true;
                tooFar = true;
            }

            if(stand.distanceTo(stand.getMaster()) < getActiveStance().getWanderDistanceMin()){
                outOfRange = true;
                tooClose = true;
            }

            if (outOfRange) {
                if (stand.hasLineOfSight(stand.getMaster())) {
                    walkingOrIdle = true;
                    Vec3 movementVector = stand.getMaster().position().subtract(stand.position()).normalize().multiply(getActiveStance().getMovementSpeed(), 0, getActiveStance().getMovementSpeed());
                    movementVector = tooClose ? movementVector.reverse() : movementVector;


                    if(tooFar){
                        stand.lookAt(stand.getMaster(), Float.MAX_VALUE, Float.MAX_VALUE);
                    }
                    stand.setDeltaMovement(movementVector.x, stand.getDeltaMovement().y, movementVector.z);

                    handleJump(new AABB(stand.getX() - 1.2, stand.getY(), stand.getZ() - 1.2, stand.getX() + 1.2, stand.getY() + 0.35, stand.getZ() + 1.2));

                } else {
                    walkingOrIdle = false;
                }

                if(stand.distanceTo(stand.getMaster()) > getActiveStance().getWanderDistanceMin() * 1.2 && stand.distanceTo(stand.getMaster()) < getActiveStance().getWanderDistanceMax() * 0.8){
                    outOfRange = false;
                    tooClose = false;
                    tooFar = false;
                }

            } else {
                walkingOrIdle = false;
            }
        } else {
            if(!isMoveActive()) {
                stand.lookAt(currentTarget, Float.MAX_VALUE, Float.MAX_VALUE);
            }

            if(nextMove == null){
                nextMove = pickNextMove(getActiveStance());
            }
            outOfRange = stand.distanceTo(currentTarget) > nextMove.distanceToUse * 0.8;

            if (outOfRange) {
                if (stand.hasLineOfSight(currentTarget) && !isMoveActive()) {
                    walkingOrIdle = true;
                    Vec3 movementVector = currentTarget.position().subtract(stand.position()).normalize().multiply(getActiveStance().getMovementSpeed(), 0, getActiveStance().getMovementSpeed());
                    stand.setDeltaMovement(movementVector.x, stand.getDeltaMovement().y, movementVector.z);

                    handleJump(new AABB(stand.getX() - 1.2, stand.getY(), stand.getZ() - 1.2, stand.getX() + 1.2, stand.getY() + 0.35, stand.getZ() + 1.2));

                    if (stand.distanceTo(currentTarget) <= nextMove.distanceToUse * 0.8) {
                        outOfRange = false;
                    }
                } else {
                    walkingOrIdle = false;
                }

            } else {
                walkingOrIdle = false;
                if(!isMoveActive() && attackCooldown == 0) {
                    setMoveActive(nextMove.id);
                }
            }
        }
    }

    private void handleJump(AABB p_70972_1_) {
        int i = Mth.floor(p_70972_1_.minX);
        int j = Mth.floor(p_70972_1_.minY);
        int k = Mth.floor(p_70972_1_.minZ);
        int l = Mth.floor(p_70972_1_.maxX);
        int i1 = Mth.floor(p_70972_1_.maxY);
        int j1 = Mth.floor(p_70972_1_.maxZ);

        for(int k1 = i; k1 <= l; ++k1) {
            for(int l1 = j; l1 <= i1; ++l1) {
                for(int i2 = k; i2 <= j1; ++i2) {
                    BlockPos blockpos = new BlockPos(k1, l1, i2);
                    BlockState blockstate = stand.level.getBlockState(blockpos);
                    if (!blockstate.isAir() && blockstate.getMaterial().isSolid() && blockstate.getMaterial() != Material.SNOW) {
                        stand.setPos(stand.getX(), stand.getY() + 0.15, stand.getZ());
                    }
                }
            }
        }
    }

    private void handleAnimations(){
        if(stand instanceof ICommandGrab && commandGrabEntity != null ){
            if (commandGrabEntity.isAlive()) {
                setAnimation(((ICommandGrab) stand).holdingAnimation(), true);
            }
        }else if(isMoveActive()){
            setAnimation(getActiveMove().move.animation, true);
        }else{
            setAnimation(walkingOrIdle ? getActiveStance().getMovingAnimation() : getActiveStance().getIdleAnimation(), true);
        }
    }

    public void setAnimation(String animationNameIn, boolean shouldLoop){
        if(!stand.level.isClientSide) {
            if(!animationNameIn.equals(lastAnimation)) {
                DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> stand), new SAnimatePacket(stand.getId(), animationNameIn, shouldLoop));
                currentAnimation = animationNameIn;
                lastAnimation = animationNameIn;
            }
        }
    }

    /**
     * Weighted randomness formula from: https://stackoverflow.com/questions/6737283/weighted-randomness-in-java
     * Took me a lil bit to figure out how it worked but it's very cool!
     * @param stance The Stance
     * @return Walking Move
     */
    private Stance.WalkingMove pickNextMove(Stance stance){
        ArrayList<Stance.WalkingMove> list = getActiveStance().getRandomlySelectableMoves();
        double totalWeight = 0.0;
        for(Stance.WalkingMove move : list){
            totalWeight += move.weight;
        }
        int idx = 0;
        for(double r = Math.random() * totalWeight; idx < list.size() - 1; ++idx){
            r -= list.get(idx).weight;
            if(r < 0.0){break;}
        }
        return list.get(idx);
    }


    private void pickTarget(){
        ArrayList<LivingEntity> possibleTargets = new ArrayList<>();
        if((currentTargeting != Targeting.WITH_MASTER || getActiveStance().getAttackMaster()) && !stand.level.isClientSide()){
            if(currentTarget == null) {
                if(currentTargeting == Targeting.ALL || getActiveStance().getAttackMaster()) {
                    java.util.stream.StreamSupport.stream(stand.getServer().getLevel(stand.level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity -> !entity.equals(stand))
                            .filter(stand::hasLineOfSight)
                            .filter(entity -> entity instanceof LivingEntity)
                            .filter(entity -> isEntityWithinAttackRange(getActiveStance(), (LivingEntity) entity))
                            .filter(entity -> !(entity instanceof Player) || !((Player) entity).isCreative() || entity.isSpectator())
                            .forEach(entity -> possibleTargets.add((LivingEntity) entity));
                }else if(currentTargeting == Targeting.HOSTILE_ONLY){
                    java.util.stream.StreamSupport.stream(stand.getServer().getLevel(stand.level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity -> !entity.equals(stand))
                            .filter(stand::hasLineOfSight)
                            .filter(entity -> entity instanceof Mob)
                            .filter(entity -> isEntityWithinAttackRange(getActiveStance(), (LivingEntity) entity))
                            .forEach(entity -> possibleTargets.add((LivingEntity) entity));
                }else if(currentTargeting == Targeting.PLAYERS_ONLY){
                    java.util.stream.StreamSupport.stream(stand.getServer().getLevel(stand.level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity -> !entity.equals(stand))
                            .filter(stand::hasLineOfSight)
                            .filter(entity -> entity instanceof Player)
                            .filter(entity -> isEntityWithinAttackRange(getActiveStance(), (LivingEntity) entity))
                            .filter(entity -> !((Player) entity).isCreative() || entity.isSpectator())
                            .forEach(entity -> possibleTargets.add((LivingEntity) entity));
                }

                if(!getActiveStance().getAttackMaster()){
                    possibleTargets.remove(stand.getMaster());
                }
                if(possibleTargets.size() > 0) {
                    currentTarget = possibleTargets.get(stand.getRandom().nextInt(possibleTargets.size()));
                }
            }
        }
    }

    private boolean isEntityWithinAttackRange(Stance stance, LivingEntity entity){
        return entity.distanceTo(stand.getMaster()) > stance.getAttackDistanceMin() && entity.distanceTo(stand.getMaster()) < getActiveStance().getAttackDistanceMax();
    }


    public void changeTargetting(){
        Style actionBarStyle = Style.EMPTY.applyFormat(ChatFormatting.LIGHT_PURPLE);

        switch (currentTargeting){
            case WITH_MASTER:
                currentTargeting = Targeting.ALL;
                stand.getMaster().displayClientMessage(new TextComponent("Targeting all entities").setStyle(actionBarStyle), true);
                break;
            case ALL:
                currentTargeting = Targeting.HOSTILE_ONLY;
                stand.getMaster().displayClientMessage(new TextComponent("Targeting hostile entities").setStyle(actionBarStyle), true);
                break;
            case HOSTILE_ONLY:
                currentTargeting = Targeting.PLAYERS_ONLY;
                stand.getMaster().displayClientMessage(new TextComponent("Targeting players").setStyle(actionBarStyle), true);
                break;
            case PLAYERS_ONLY:
                currentTargeting = Targeting.WITH_MASTER;
                stand.getMaster().displayClientMessage(new TextComponent("Following master").setStyle(actionBarStyle), true);
                break;
            default:
                break;
        }
        currentTarget = null;
    }

    public void startCommandGrab(LivingEntity entity){
        commandGrabEntity = entity;
    }
}
