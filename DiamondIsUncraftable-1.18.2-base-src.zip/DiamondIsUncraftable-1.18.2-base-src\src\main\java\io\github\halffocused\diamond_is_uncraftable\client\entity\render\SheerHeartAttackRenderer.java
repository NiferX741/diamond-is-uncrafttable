package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.client.entity.model.SheerHeartAttackModel;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.SheerHeartAttackEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nonnull;

public class SheerHeartAttackRenderer extends StandAttackRenderer<SheerHeartAttackEntity> {
    public SheerHeartAttackRenderer(EntityRendererProvider.Context renderManagerIn) {
        super(renderManagerIn);
    }

    @Override
    public void render(@Nonnull SheerHeartAttackEntity entityIn, float entityYaw, float partialTicks, PoseStack matrixStackIn, MultiBufferSource bufferIn, int packedLightIn) {
        if (!(Minecraft.getInstance().getCameraEntity() instanceof Player) && !(Minecraft.getInstance().getCameraEntity() instanceof AbstractStandEntity))
            return;
        SheerHeartAttackModel shaModel = new SheerHeartAttackModel();

        if (Minecraft.getInstance().getCameraEntity() instanceof AbstractStandEntity)
            render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn, shaModel);
        else Stand.getLazyOptional((Player) Minecraft.getInstance().getCameraEntity()).ifPresent(props -> {
            if (props.getStandID() != 0)
                super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn, shaModel);
        });
    }

    @Override
    public ResourceLocation getTextureLocation(SheerHeartAttackEntity entity) {
        return Util.ResourceLocations.SHEER_HEART_ATTACK;
    }
}

