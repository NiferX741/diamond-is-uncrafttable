package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStandMasterPacket implements IMessage<SSyncStandMasterPacket> {
    private int standID;
    private int masterID;

    public SSyncStandMasterPacket() {
    }

    public SSyncStandMasterPacket(int standID, int masterID) {
        this.standID = standID;
        this.masterID = masterID;
    }

    @Override
    public void encode(SSyncStandMasterPacket message, FriendlyByteBuf buffer) {
        buffer.writeInt(message.standID);
        buffer.writeInt(message.masterID);
    }

    @Override
    public SSyncStandMasterPacket decode(FriendlyByteBuf buffer) {
        return new SSyncStandMasterPacket(buffer.readInt(), buffer.readInt());
    }

    @Override
    public void handle(SSyncStandMasterPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                Entity stand = Minecraft.getInstance().level.getEntity(message.standID);
                Entity master = Minecraft.getInstance().level.getEntity(message.masterID);
                if (stand != null && master != null)
                    ((AbstractStandEntity) stand).setMaster((Player) master);
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
