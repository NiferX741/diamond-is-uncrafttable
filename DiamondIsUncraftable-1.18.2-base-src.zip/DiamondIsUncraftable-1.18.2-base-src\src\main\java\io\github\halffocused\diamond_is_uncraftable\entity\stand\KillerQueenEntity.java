package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import io.github.halffocused.diamond_is_uncraftable.capability.*;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.SheerHeartAttackEntity;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.ChargeAttackFormat;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import software.bernie.geckolib3.core.IAnimatable;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("ConstantConditions")
public class KillerQueenEntity extends AbstractStandEntity implements IAnimatable, IOnMasterAttacked {
    public LivingEntity bombEntity;
    public int shaCount;
    BlockPos setBlockBombPosition = null;

    /*
    Balancing variables for KQ's item and block bomb explosion. It happens all over the code in many different places, so these variables should allow easy tweaking.
     */

    public static final double maxExplosionDamage = 15;
    public static final double minExplosionDamage = 5;
    public static final double explosionRange = 7;

    AttackFramedata leftPunchData = new AttackFramedata(20)
            .addDamageFrame(13, 8, Vec3.ZERO, 2.3, 2);

    AttackFramedata rightPunchData = new AttackFramedata(20)
            .addDamageFrame(13, 8, Vec3.ZERO, 2.3, 2);

    AttackFramedata barrageData = new AttackFramedata(32)
            .generateInterval(6, 30, 3, 2, Vec3.ZERO, 2.4, 4);

    AttackFramedata bombData = new AttackFramedata(14)
            .addBombFrame(8, 3.2);

    AttackFramedata detonateData = new AttackFramedata(43)
            .addMessageFrame(39, 1, null, null)
            .addMessageFrame(32, 5, null, null);

    AttackFramedata blockBombData = new AttackFramedata(54)
            .addMessageFrame(20, 2, null, null);

    AttackFramedata itemBombData = new AttackFramedata(45)
            .addMessageFrame(12, 3, null, null);

    AttackFramedata executeData = new AttackFramedata(50)
            .addMessageFrame(42, 4, null, null)
            .addMenacingFrame(42);

    ChargeAttackFormat chargeAttackFormat = new ChargeAttackFormat("firstbombcharge", 54, "holding")
            .addChargeNode(54, 4, true);

    HoveringMoveHandler controller = new HoveringMoveHandler(this)
            .addMove("Jab",1, rightPunchData, "rightpunch", 2.0)
            .addMove("Jab",2, leftPunchData, "leftpunch", 2.0)
            .addMove("Barrage",3, barrageData, "barrage", HoveringMoveHandler.RepositionConstants.MASTER_POSITION)
            .addMove("First Bomb (Entity)",4, bombData,"firstbomb", 2.0)
            .addMove("Detonate",5, detonateData, "click", HoveringMoveHandler.RepositionConstants.IDLE_POSITION)
            .addMove("First Bomb (Block)",6, blockBombData, "blockbomb", HoveringMoveHandler.RepositionConstants.DO_NOT_MOVE)
            .addMove("First Bomb (Item)",7, itemBombData, "itembomb", HoveringMoveHandler.RepositionConstants.IDLE_POSITION)
            .addMove("Eliminate Witness", 8, executeData, "execute", HoveringMoveHandler.RepositionConstants.DO_NOT_MOVE)
            .addChargeAttack(chargeAttackFormat);

    public HoveringMoveHandler getController(){
        return controller;
    }

    public KillerQueenEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    public void detonate() {
        if (getMaster() == null || level.isClientSide()) return;
        if(spendEnergy(65)) { //In conditional statements like this all other checks must precede the spendEnergy() method.
            controller.setMoveActive(5);
        }
    }

    public void toggleSheerHeartAttack() {

        if(!level.isClientSide() && this.shaCount == 0 && spendEnergy(50)) {
            SheerHeartAttackEntity sheerHeartAttackEntity = new SheerHeartAttackEntity(level, this, master);
            sheerHeartAttackEntity.setPos(master.getX(), master.getY() + master.getEyeHeight(), master.getZ());
            sheerHeartAttackEntity.shoot(getMaster(), master.getXRot(), master.getYRot(), 0.35f, Float.MIN_VALUE);
            level.addFreshEntity(sheerHeartAttackEntity);
            shaCount++;
        }

    }

    public void turnItemOrBlockIntoBomb() {
        if (getMaster() == null || level.isClientSide || !getController().isActionable()) return;
        Stand.getLazyOptional(master).ifPresent(props -> {
            if (!master.isCrouching() && master.getMainHandItem() != ItemStack.EMPTY) {
                controller.setMoveActive(7);
            } else if (master.isCrouching()) {
                setBlockBombPosition = master.blockPosition().offset(0,-1,0);
                controller.setMoveActive(6);
            }
        });
    }

    @Override
    public void tick() {
        super.tick();
        if (getMaster() != null) {
            Stand.getLazyOptional(master).ifPresent(stand -> {
                stand.setAbility(false);
                stand.setPreventUnsummon2(shaCount > 0);
            });
        }

        if(controller.isMoveActive()){
            if(controller.getActiveMove().getId() == 6){
                setPos(setBlockBombPosition.getX(), setBlockBombPosition.getY() + 1, setBlockBombPosition.getZ());
            }

            if(controller.getActiveMove().getId() == 8){

                if(bombEntity != null) {

                    if(!bombEntity.isAlive()){
                        bombEntity = null;
                    }else{
                        Vec3 executeVec = position().add(getLookAngle().normalize().scale(1.3));
                        bombEntity.teleportTo(executeVec.x, this.getY(), executeVec.z);
                        if(bombEntity instanceof Player){
                            Util.applyUnactionableTicks((Player) bombEntity, 1);
                        }
                    }
                }
            }

            if(controller.getActiveMove().getId() == 5 && controller.getActiveMove().getFramedata().getTicker() <= 39){
                Util.spawnParticle(this, 8, this.getX(), this.getY(), this.getZ(), 1.2, 2.5, 1.2, 1);
            }
        }

    }

    @Override
    public int getJabMoveId(){
        return getRandom().nextBoolean() ? 1 : 2;
    }

    @Override
    public int getBarrageMoveId(){
        return 3;
    }

    @Override
    public void messageFrame(int message1, Object message2, Object message3) {

        if (message1 == 1) {
            Stand stand = Stand.getCapabilityFromPlayer(master);
            Stand.getLazyOptional(master).ifPresent(props -> { //Remove bomb block if it was mined.
                if (level.getBlockState(stand.getBlockPos()).isAir()) {
                    stand.setBlockPos(BlockPos.ZERO);
                }

                    for(ServerLevel currentWorld : getServer().getAllLevels()){

                        java.util.stream.StreamSupport.stream(currentWorld.getAllEntities().spliterator(), false)
                            .filter(entity -> entity instanceof ItemEntity)
                            .forEach(entity -> {
                                ItemEntity itemEntity = ((ItemEntity) entity);
                                CompoundTag nbt = itemEntity.getItem().getOrCreateTag();
                                if (nbt.getBoolean("bomb") && nbt.getUUID("ownerUUID").equals(master.getUUID())) {
                                    Util.standExplosion(master, this.level, entity.position(), explosionRange, 3, maxExplosionDamage, minExplosionDamage);
                                    entity.discard();
                                }
                            });
                    }
                    if (stand.getBlockPos() != BlockPos.ZERO) {
                        if (!level.getChunkSource().hasChunk(stand.getBlockPos().getX() >> 4, stand.getBlockPos().getZ() >> 4))
                            return;
                        Util.standExplosion(master, this.level, new Vec3(stand.getBlockPos().getX(), stand.getBlockPos().getY(), stand.getBlockPos().getZ()), explosionRange, 3, maxExplosionDamage, minExplosionDamage);
                        StandChunkEffects.getLazyOptional(level.getChunkAt(master.blockPosition())).ifPresent(standChunkEffects -> standChunkEffects.removeBombPos(master));
                        removeFirstBombFromAll();
                    }

                    if (bombEntity != null) {
                        if (bombEntity.isAlive()) {
                            if (bombEntity instanceof Mob) {
                                if (stand.getGameTime() == -1) {
                                    Util.standExplosionFX(master, this.level, bombEntity.position());
                                    bombEntity.discard();
                                    removeFirstBombFromAll();
                                }
                            } else if (bombEntity instanceof Player) {
                                Stand.getLazyOptional((Player) bombEntity).ifPresent(bombProps -> {
                                    Explosion explosion = new Explosion(bombEntity.level, master, bombEntity.getX(), bombEntity.getY(), bombEntity.getZ(), 4, true, Explosion.BlockInteraction.NONE);
                                    ((Player) bombEntity).sweepAttack();
                                    explosion.finalizeExplosion(true);
                                    Util.spawnParticle(this, 5, bombEntity.getX(), bombEntity.getY(), bombEntity.getZ(), 1, 1, 1, 1);
                                    Util.spawnParticle(this, 14, bombEntity.getX(), bombEntity.getY() + 1, bombEntity.getZ(), 1, 1, 1, 20);
                                    Util.dealStandDamage(this, bombEntity, 15, Vec3.ZERO, false);
                                    removeFirstBombFromAll();
                                });
                            }
                            if (!master.isCreative() && !master.isSpectator())
                                master.getFoodData().eat(-2, 0);
                        }
                    }
            });
        }

        if(message1 == 2){
            removeFirstBombFromAll();
            Stand props = Stand.getCapabilityFromPlayer(master);
            props.setBlockPos(setBlockBombPosition);
            StandChunkEffects.getLazyOptional(level.getChunkAt(master.blockPosition())).ifPresent(standChunkEffects -> standChunkEffects.addBombPos(master, setBlockBombPosition));
            props.setAbilityUseCount(1);
        }

        if(message1 == 3){
            removeFirstBombFromAll();
            Stand props = Stand.getCapabilityFromPlayer(master);
            if (master.getMainHandItem().getCount() > 1) {
                if (master.getInventory().getItem(master.getInventory().getSuitableHotbarSlot()).isEmpty()) {
                    ItemStack stack = master.getMainHandItem().copy();
                    stack.shrink(master.getMainHandItem().getCount() - 1);
                    stack.getOrCreateTag().putBoolean("bomb", true);
                    stack.getOrCreateTag().putUUID("ownerUUID", master.getUUID());
                    master.getMainHandItem().shrink(1);
                    stack.setHoverName(new TextComponent("Bomb"));
                    master.getInventory().add(master.getInventory().getSuitableHotbarSlot(), stack);
                }
            } else if (master.getMainHandItem().getCount() == 1) {
                master.getMainHandItem().getOrCreateTag().putBoolean("bomb", true);
                master.getMainHandItem().getOrCreateTag().putUUID("ownerUUID", master.getUUID());
                master.getMainHandItem().setHoverName(new TextComponent("Bomb"));
            }
        }


        if(message1 == 4) {
            if(!level.isClientSide()) {
                if (bombEntity != null) {
                    if (bombEntity instanceof Player) {
                        Util.spawnParticle(this, 5, bombEntity.getX(), bombEntity.getY(), bombEntity.getZ(), 1, 1, 1, 1);
                        Util.spawnParticle(this, 14, bombEntity.getX(), bombEntity.getY() + 1, bombEntity.getZ(), 1, 1, 1, 20);
                        level.playSound(null, master.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, 1);
                        bombEntity.hurt(DamageSource.explosion(master), Float.MAX_VALUE);
                    } else {
                        level.playSound(null, master.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, 1);
                        Util.spawnParticle(this, 5, bombEntity.getX(), bombEntity.getY(), bombEntity.getZ(), 1, 1, 1, 1);
                        Util.spawnParticle(this, 14, bombEntity.getX(), bombEntity.getY() + 1, bombEntity.getZ(), 1, 1, 1, 20);
                        bombEntity.discard();
                    }
                }
                bombEntity = null;
                removeFirstBombFromAll();
            }
        }

        if(message1 == 5){
            level.playSound(null, this.blockPosition(), SoundInit.DETONATION_CLICK.get(), SoundSource.NEUTRAL, 2f, 1);
        }

    }

    @Override
    public void onMasterAttacked(Entity damager, float damage) {
        if(controller.isMoveActive()){
            if(controller.getActiveMove().getId() == 5){
                controller.cancelActiveMoves();
            }
        }
    }

    /*
     Removes first bomb status from any entity, block, or item. Items have their names reset.
     */
    public void removeFirstBombFromAll() {

        Stand stand = Stand.getCapabilityFromPlayer(master);
        stand.setBlockPos(BlockPos.ZERO);
        stand.setBombEntityId(0);
        bombEntity = null;

        /*

        AtomicInteger processes = new AtomicInteger();

        bombEntity = null;
        Stand stand = Stand.getCapabilityFromPlayer(master);
        stand.setBombEntityId(0);

        for (ServerLevel currentWorld : getServer().getAllLevels()) {
            Util.loadedBlockEntities(currentWorld)
                    .forEach(tile -> {

                        processes.getAndIncrement();
                        if(processes.get() > 1000){
                            return;
                        }
                        if (tile instanceof BaseContainerBlockEntity && !((BaseContainerBlockEntity) tile).isEmpty()) {
                            int size = ((BaseContainerBlockEntity) tile).getContainerSize();
                            for (int i = 0; i < size; i++) {
                                if (((BaseContainerBlockEntity) tile).getItem(i).getOrCreateTag().getBoolean("bomb") && ((BaseContainerBlockEntity) tile).getItem(i).getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                                    tile.setChanged();
                                    ((BaseContainerBlockEntity) tile).getItem(i).getOrCreateTag().remove("bomb");
                                    ((BaseContainerBlockEntity) tile).getItem(i).getOrCreateTag().remove("ownerUUID");
                                    ((BaseContainerBlockEntity) tile).getItem(i).clearCustomName();
                                }
                            }
                        }
                    });

            java.util.stream.StreamSupport.stream(currentWorld.getAllEntities().spliterator(), false)
                    .filter(entity -> entity instanceof ItemEntity)
                    .forEach(entity -> {

                                processes.getAndIncrement();
                                if (processes.get() > 1000) {
                                    return;
                                }

                                StandEffects.getLazyOptional(entity).ifPresent(effects -> {
                                    effects.setBomb(false);
                                    ItemStack item = ((ItemEntity) entity).getItem();

                                    CompoundTag nbt = item.getOrCreateTag();
                                    if (nbt.getUUID("ownerUUID").equals(master.getUUID())) {
                                        nbt.remove("bomb");
                                        nbt.remove("ownerUUID");
                                        item.clearCustomName();
                                    }
                                });
                            });

            java.util.stream.StreamSupport.stream(currentWorld.getAllEntities().spliterator(), false)
                    .filter(entity -> entity instanceof LivingEntity)
                    .forEach(entity -> {

                        processes.getAndIncrement();
                        if (processes.get() > 1000) {
                            return;
                        }

                        if (entity instanceof Player) {
                            Player playerEntity = (Player) entity;

                            for (int i = 0; i < playerEntity.getEnderChestInventory().getContainerSize(); i++) {
                                if (playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().getBoolean("bomb") && playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                                    playerEntity.getEnderChestInventory().setChanged();
                                    playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().remove("bomb");
                                    playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().remove("ownerUUID");
                                    playerEntity.getEnderChestInventory().getItem(i).clearCustomName();
                                }
                            }

                            for (ItemStack stack : playerEntity.getInventory().items) {

                                processes.getAndIncrement();
                                if (processes.get() > 1000) {
                                    return;
                                }

                                if (stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                                    CompoundTag nbt = stack.getOrCreateTag();
                                    playerEntity.getInventory().setChanged();
                                    nbt.remove("bomb");
                                    nbt.remove("ownerUUID");
                                    stack.clearCustomName();
                                }
                            }
                            for (ItemStack stack : playerEntity.getInventory().offhand) {

                                processes.getAndIncrement();
                                if (processes.get() > 1000) {
                                    return;
                                }

                                if (stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                                    CompoundTag nbt = stack.getOrCreateTag();
                                    playerEntity.getInventory().setChanged();
                                    nbt.remove("bomb");
                                    nbt.remove("ownerUUID");
                                    stack.clearCustomName();
                                }
                            }
                            for (ItemStack stack : playerEntity.getInventory().armor) {

                                processes.getAndIncrement();
                                if (processes.get() > 1000) {
                                    return;
                                }

                                if (stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                                    CompoundTag nbt = stack.getOrCreateTag();
                                    playerEntity.getInventory().setChanged();
                                    nbt.remove("bomb");
                                    nbt.remove("ownerUUID");
                                    stack.clearCustomName();
                                }
                            }
                        } else {
                            for (ItemStack stack : entity.getAllSlots()) {

                                processes.getAndIncrement();
                                if (processes.get() > 1000) {
                                    return;
                                }

                                CompoundTag nbt = stack.getOrCreateTag();
                                if (nbt.getBoolean("bomb") && nbt.getUUID("ownerUUID").equals(master.getUUID())) {
                                    nbt.remove("bomb");
                                    nbt.remove("ownerUUID");
                                    stack.clearCustomName();
                                }
                            }
                        }
                    });
            java.util.stream.StreamSupport.stream(currentWorld.getAllEntities().spliterator(), false)
                    .filter(entity -> entity instanceof ItemFrameEntity)
                    .forEach(itemFrame -> {

                        processes.getAndIncrement();
                        if (processes.get() > 1000) {
                            return;
                        }

                        ItemFrameEntity frame = (ItemFrameEntity) itemFrame;
                        if (frame.getDisplayedItem().getOrCreateTag().getBoolean("bomb") && frame.getDisplayedItem().getOrCreateTag().getUUID("ownerUUID").equals(master.getUUID())) {
                            CompoundTag nbt = frame.getDisplayedItem().getOrCreateTag();
                            nbt.remove("bomb");
                            nbt.remove("ownerUUID");
                            frame.getDisplayedItem().clearCustomName();
                        }
                    });
        }
        stand.setBombEntityId(0);
        stand.setBlockPos(BlockPos.ZERO);

         */
    }
}

