package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.capability.BitesTheDustCapability;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncBitesTheDustCapabilityPacket implements IMessage<SSyncBitesTheDustCapabilityPacket> {
    private Tag data;

    public SSyncBitesTheDustCapabilityPacket() {
    }

    private SSyncBitesTheDustCapabilityPacket(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncBitesTheDustCapabilityPacket(BitesTheDustCapability props) {
        data = BitesTheDustCapability.STORAGE.writeNBT(BitesTheDustCapability.BITES_THE_DUST, props, null);
    }

    @Override
    public SSyncBitesTheDustCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncBitesTheDustCapabilityPacket(buffer.readNbt());
    }

    @Override
    public void handle(SSyncBitesTheDustCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                Minecraft.getInstance().level.entitiesForRendering().forEach(entity -> BitesTheDustCapability.getLazyOptional(entity).ifPresent(props ->
                        BitesTheDustCapability.STORAGE.readNBT(BitesTheDustCapability.BITES_THE_DUST, props, null, message.data)
                ));
            });
        }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(SSyncBitesTheDustCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }
}
