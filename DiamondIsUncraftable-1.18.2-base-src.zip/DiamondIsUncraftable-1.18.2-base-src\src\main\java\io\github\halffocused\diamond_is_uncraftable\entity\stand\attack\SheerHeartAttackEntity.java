package io.github.halffocused.diamond_is_uncraftable.entity.stand.attack;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.KillerQueenEntity;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

public class SheerHeartAttackEntity extends AbstractStandAttackEntity {

    LivingEntity target = null;
    private int firstFuse = 100;
    private int secondFuse = 40;

    public SheerHeartAttackEntity(EntityType<? extends AbstractStandAttackEntity> type, Level worldIn) {
        super(type, worldIn);
    }

    public SheerHeartAttackEntity(Level worldIn, KillerQueenEntity shooter, Player player) {
        super(EntityInit.SHEER_HEART_ATTACK.get(), worldIn, shooter, player);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if(!level.isClientSide()) {
            firstFuse = 0;
            setVelocity(0,0,0);
            setDeltaMovement(0,0,0);
        }
    }

    @Override
    public void tick(){
        super.tick();
        if(!level.isClientSide()) {
            firstFuse--;
            Util.spawnParticle(shootingStand, 13, this.getX(), this.getY() + 1, this.getZ(), 0.5, 0.5, 0.5, 1);
            if (firstFuse <= 0) {
                setVelocity(0, 0, 0);
                setDeltaMovement(0, 0, 0);
                secondFuse--;
                Util.spawnParticle(shootingStand, 14, this.getX(), this.getY() + 1, this.getZ(), 0.4, 0.4, 0.4, 2);
                if (secondFuse <= 0) {
                    Util.standExplosion(standMaster, standMaster.level, new Vec3(this.position().x, this.position().y + 1, this.position().z), 6.5, 3, 5, 23);
                    discard();
                }
            }else{
                if(target == null) {
                    java.util.stream.StreamSupport.stream(getServer().getLevel(level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity -> !entity.equals(standMaster))
                            .filter(entity -> entity instanceof LivingEntity)
                            .filter(entity -> !(entity instanceof AbstractStandEntity))
                            .filter(entity -> entity.distanceTo(this) < 7)
                            .filter(Entity::isAlive)
                            .filter(entity -> ((LivingEntity) entity).hasLineOfSight(this))
                            .forEach(entity -> target = (LivingEntity) entity);
                }

                if(target != null) {
                    double x = (target.getBoundingBox().minX + (target.getBoundingBox().maxX - target.getBoundingBox().minX) / 2) - getX();
                    double y = (target.getBoundingBox().minY + (target.getBoundingBox().maxY - target.getBoundingBox().minY) / 2) - getY();
                    double z = (target.getBoundingBox().minZ + (target.getBoundingBox().maxZ - target.getBoundingBox().minZ) / 2) - getZ();
                    Vec3 vec3d = (new Vec3(x, y, z)).normalize().add(this.random.nextGaussian() * (double) 0.0075f * (double) 0, this.random.nextGaussian() * (double) 0.0075f * 0, this.random.nextGaussian() * (double) 0.0075F * 0).scale(1);
                    setDeltaMovement(vec3d.scale(0.2));
                    float f = Mth.sqrt((float) Util.horizontalMag(vec3d));
                    setYRot((float) (Mth.atan2(vec3d.x, vec3d.z) * (double) (180 / (float) Math.PI)));
                    setXRot((float) (Mth.atan2(vec3d.y, f) * (double) (180 / (float) Math.PI)));
                    yRotO = getYRot();
                    xRotO = getXRot();
                }

            }
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult result) {
        if(!level.isClientSide()) {
            firstFuse = 0;
            setVelocity(0,0,0);
            setDeltaMovement(0,0,0);
        }
    }

    @Override
    public ResourceLocation getTextureLocation() {
        return Util.ResourceLocations.SHEER_HEART_ATTACK;
    }

    @Override
    protected int getRange() {
        return 10000;
    }

    @Override
    public void remove(net.minecraft.world.entity.Entity.RemovalReason reason){
        if(shootingStand instanceof KillerQueenEntity){
            ((KillerQueenEntity) shootingStand).shaCount--;
        }
        super.remove(reason);
    }

    @Override
    public boolean shouldRemoveOnHitEntity(){
        return false;
    }

    protected boolean shouldBeDestroyedByBlocks(BlockState state) {
        return false;
    }
}
