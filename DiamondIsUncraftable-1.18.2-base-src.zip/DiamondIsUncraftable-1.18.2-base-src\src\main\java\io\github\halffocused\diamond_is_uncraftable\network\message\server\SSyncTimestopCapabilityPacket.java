package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.capability.ITimestop;
import io.github.halffocused.diamond_is_uncraftable.capability.Timestop;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncTimestopCapabilityPacket implements IMessage<SSyncTimestopCapabilityPacket> {
    private Tag data;

    public SSyncTimestopCapabilityPacket() {
    }

    private SSyncTimestopCapabilityPacket(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncTimestopCapabilityPacket(Timestop props) {
        data = Timestop.STORAGE.writeNBT(Timestop.TIMESTOP, props, null);
    }

    @Override
    public SSyncTimestopCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncTimestopCapabilityPacket(buffer.readNbt());
    }

    @Override
    public void handle(SSyncTimestopCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                Minecraft.getInstance().level.entitiesForRendering().forEach(entity -> Timestop.getLazyOptional(entity).ifPresent(props ->
                        Timestop.STORAGE.readNBT(Timestop.TIMESTOP, props, null, message.data)
                ));
            });
        }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(SSyncTimestopCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }
}
