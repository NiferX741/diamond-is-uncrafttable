package io.github.halffocused.diamond_is_uncraftable.entity;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.init.ItemInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.protocol.Packet;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.ParametersAreNonnullByDefault;

@SuppressWarnings("ALL")
@ParametersAreNonnullByDefault
public class StandArrowEntity extends AbstractArrow {

    public StandArrowEntity(EntityType<? extends AbstractArrow> type, Level level) {
        super(type, level);
    }

    @Deprecated //Use below constructor instead
    private StandArrowEntity(EntityType<? extends AbstractArrow> type, Level level, LivingEntity shooter) {
        super(type, shooter, level);
    }

    public StandArrowEntity(Level level, LivingEntity shooter) {
        this(EntityInit.STAND_ARROW.get(), level, shooter);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof Player) {
            Stand.getLazyOptional((Player) entity).ifPresent(props -> {
                if (props.getStandID() == 0) {
                    props.setStandID(Util.StandID.STANDS[level.random.nextInt(Util.StandID.STANDS.length)]);
                    level.playSound(null, blockPosition(), SoundEvents.SHIELD_BREAK, SoundSource.NEUTRAL, 1, 1);
                    discard();
                }
            });
        }
        super.onHitEntity(result);
    }

    @Override
    protected ItemStack getPickupItem() {
        return new ItemStack(ItemInit.STAND_ARROW.get());
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
