package io.github.halffocused.diamond_is_uncraftable.capability;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandPerWorldCapabilityPacket;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncWorldTimestopCapability;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.UUID;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class WorldTimestopCapability implements ICapabilitySerializable<Tag> {
    public static final Capability<WorldTimestopCapability> WORLD = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<WorldTimestopCapability> STORAGE;
    Level world;
    private LazyOptional<WorldTimestopCapability> holder = LazyOptional.of(() -> new WorldTimestopCapability(getWorld()));
    ArrayList<TimestoppedChunk> timestoppedChunks = new ArrayList<>();

    public WorldTimestopCapability(@Nonnull Level world) {
        this.world = world;
    }

    public static LazyOptional<WorldTimestopCapability> getLazyOptional(Level world) {
        return world.getCapability(WORLD);
    }

    public static WorldTimestopCapability getCapabilityFromWorld(Level world) {
        return world.getCapability(WORLD).orElse(new WorldTimestopCapability(world));
    }

    public static void register() {
        STORAGE = new CapStorage<WorldTimestopCapability>() {
            @Nonnull
            @Override
            public Tag writeNBT(Capability<WorldTimestopCapability> capability, WorldTimestopCapability instance, Direction side) {
                CompoundTag nbt = new CompoundTag();

                ListTag timestoppedChunks = new ListTag();
                instance.getTimestoppedChunkPosList().forEach(timestoppedChunk -> {
                    CompoundTag chunkNBT = new CompoundTag();
                    chunkNBT.putUUID("masterUUID", timestoppedChunk.getUUID());
                    chunkNBT.putInt("chunkX", timestoppedChunk.pos.x);
                    chunkNBT.putInt("chunkZ", timestoppedChunk.pos.z);
                });
                nbt.put("timestoppedChunks", timestoppedChunks);

                return nbt;
            }

            @Override
            public void readNBT(Capability<WorldTimestopCapability> capability, WorldTimestopCapability instance, Direction side, Tag nbt) {
                CompoundTag compoundNBT = (CompoundTag) nbt;

                compoundNBT.getList("timestoppedChunks", Tag.TAG_COMPOUND).forEach(compound -> {
                    if(compound instanceof CompoundTag){
                        CompoundTag chunkNBT = (CompoundTag) compound;
                        instance.addTimestoppedChunk(new ChunkPos(chunkNBT.getInt("chunkX"), chunkNBT.getInt("chunkZ")), chunkNBT.getUUID("masterUUID"));
                    }
                });
            }
        };
    }

    public ArrayList<TimestoppedChunk> getTimestoppedChunkPosList(){
        return timestoppedChunks;
    }

    public void addTimestoppedChunk(ChunkPos posIn, UUID uuidIn){
        TimestoppedChunk chunk = new TimestoppedChunk(posIn, uuidIn);
        timestoppedChunks.add(chunk);
        onDataUpdated();
    }

    public void removeTimestoppedChunk(ChunkPos posIn, UUID uuidIn){
        TimestoppedChunk chunk = new TimestoppedChunk(posIn, uuidIn);
        timestoppedChunks.removeIf(timestoppedChunk -> timestoppedChunk.equals(chunk));
        onDataUpdated();
    }


    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @Nullable Direction side) {
        return capability == WORLD ? holder.cast() : LazyOptional.empty();
    }

    public Level getWorld() {
        return world;
    }

    public void onDataUpdated() {
        if (!world.isClientSide)
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.ALL.noArg(), new SSyncWorldTimestopCapability(this));
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(WORLD, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(WORLD, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }

    public static class TimestoppedChunk{
        private UUID uuid;
        private ChunkPos pos;

        public TimestoppedChunk(ChunkPos posIn, UUID uuidIn){
            pos = posIn;
            uuid = uuidIn;
        }

        public ChunkPos getChunkPos(){
            return pos;
        }

        public UUID getUUID(){
            return uuid;
        }

        public boolean equals(TimestoppedChunk other){
            return this.getChunkPos().equals(other.getChunkPos()) && this.getUUID().equals(other.getUUID());
        }
    }

}
