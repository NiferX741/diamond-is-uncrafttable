package io.github.halffocused.diamond_is_uncraftable.item;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;

public class StandDiscItem extends Item {
    public StandDiscItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!player.level.isClientSide) {
            ItemStack stack = player.getItemInHand(hand);
            CompoundTag nbt = stack.getTag() == null ? new CompoundTag() : stack.getTag();
            Stand props = Stand.getCapabilityFromPlayer(player);
            if (props.getStandID() != 0 && nbt.getInt("StandID") == 0) {
                nbt.putInt("StandID", props.getStandID());
                props.removeStand(false);
                stack.setTag(nbt);
                return InteractionResultHolder.consume(stack);
            } else if (props.getStandID() == 0 && nbt.getInt("StandID") != 0) {
                props.setStandID(nbt.getInt("StandID"));
                nbt.putInt("StandID", 0);
                return InteractionResultHolder.consume(stack);
            }
            stack.setTag(nbt);
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity livingEntityIn, LivingEntity attacker) {
        CompoundTag nbt = stack.getTag() == null ? new CompoundTag() : stack.getTag();
        if (livingEntityIn instanceof Player) {
            Stand.getLazyOptional((Player) livingEntityIn).ifPresent(props -> {
                if (attacker instanceof Player) {
                    final int standID = Stand.getCapabilityFromPlayer(((Player) attacker)).getStandID();
                    final int standAct = Stand.getCapabilityFromPlayer(((Player) attacker)).getAct();
                    /*
                    if (standID == Util.StandID.WHITESNAKE || (standID == Util.StandID.MADE_IN_HEAVEN && standAct == 2)) {
                        if (props.getStandID() != 0 && nbt.getInt("StandID") == 0) {
                            nbt.putInt("StandID", props.getStandID());
                            props.removeStand(false);
                            stack.setTag(nbt);
                        } else if (props.getStandID() == 0 && props.getStandID() != Util.StandID.GER && nbt.getInt("StandID") != 0) {
                            props.setStandID(nbt.getInt("StandID"));
                            nbt.putInt("StandID", 0);
                        }
                        stack.setTag(nbt);
                    }
                     */
                }
            });
        }
        return true;
    }
}
