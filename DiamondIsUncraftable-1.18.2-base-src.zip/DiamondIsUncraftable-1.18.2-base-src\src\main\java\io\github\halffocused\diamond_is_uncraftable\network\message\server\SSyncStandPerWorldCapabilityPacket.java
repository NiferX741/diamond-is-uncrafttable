package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.StandPerWorldCapability;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStandPerWorldCapabilityPacket implements IMessage<SSyncStandPerWorldCapabilityPacket> {
    private Tag data;

    public SSyncStandPerWorldCapabilityPacket() {
    }

    private SSyncStandPerWorldCapabilityPacket(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncStandPerWorldCapabilityPacket(StandPerWorldCapability props) {
        data = StandPerWorldCapability.STORAGE.writeNBT(StandPerWorldCapability.WORLD, props, null);
    }

    @Override
    public SSyncStandPerWorldCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncStandPerWorldCapabilityPacket(buffer.readNbt());
    }

    @Override
    public void handle(SSyncStandPerWorldCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if(DiamondIsUncraftable.PROXY.getWorld() == null) return;
                StandPerWorldCapability.getLazyOptional(DiamondIsUncraftable.PROXY.getWorld()).ifPresent(props -> StandPerWorldCapability.STORAGE.readNBT(StandPerWorldCapability.WORLD, props, null, message.data));
            });
        }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(SSyncStandPerWorldCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }
}
