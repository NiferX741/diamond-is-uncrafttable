package io.github.halffocused.diamond_is_uncraftable.effect;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class StandWeaknessEffect extends MobEffect {
    public StandWeaknessEffect(MobEffectCategory typeIn, int liquidColorIn) {
        super(typeIn, liquidColorIn);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public void applyEffectTick(LivingEntity entityLivingBaseIn, int amplifier) {
        if(!(entityLivingBaseIn instanceof Player)){
            entityLivingBaseIn.removeEffect(this);
        }else{
            Stand playerCapability = Stand.getCapabilityFromPlayer((Player) entityLivingBaseIn);

            if(playerCapability.getStandID() == 0){
                entityLivingBaseIn.removeEffect(this);
            }
        }
    }
}
