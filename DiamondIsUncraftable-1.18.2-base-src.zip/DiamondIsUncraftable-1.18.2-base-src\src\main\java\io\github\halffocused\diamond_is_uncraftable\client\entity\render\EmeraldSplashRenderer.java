package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.EmeraldSplashEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.resources.ResourceLocation;
import com.mojang.math.Vector3f;

public class EmeraldSplashRenderer extends EntityRenderer<EmeraldSplashEntity> {
    private final ItemRenderer itemRenderer;
    private final float scale;

    public EmeraldSplashRenderer(EntityRendererProvider.Context manager, ItemRenderer renderer, float scale, boolean b) {
        super(manager);
        this.itemRenderer = renderer;
        this.scale = scale;
    }

    public EmeraldSplashRenderer(EntityRendererProvider.Context manager, ItemRenderer renderer) {
        this(manager, renderer, 1, false);
    }

    public void render(EmeraldSplashEntity entity, float p_225623_2_, float p_225623_3_, PoseStack matrixStack, MultiBufferSource buffer, int packedLightIn) {
        matrixStack.pushPose();
        matrixStack.scale(this.scale, this.scale, this.scale);
        matrixStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        matrixStack.mulPose(Vector3f.YP.rotationDegrees(180.0F));
        itemRenderer.renderStatic(new ItemStack(Items.EMERALD), ItemTransforms.TransformType.GROUND, packedLightIn, OverlayTexture.NO_OVERLAY, matrixStack, buffer, 0);
        matrixStack.popPose();
        super.render(entity, p_225623_2_, p_225623_3_, matrixStack, buffer, packedLightIn);
    }

    @Override
    public ResourceLocation getTextureLocation(EmeraldSplashEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
