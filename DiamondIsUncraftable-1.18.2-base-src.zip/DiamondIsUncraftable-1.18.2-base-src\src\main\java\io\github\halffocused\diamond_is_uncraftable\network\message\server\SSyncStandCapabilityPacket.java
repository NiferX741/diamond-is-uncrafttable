package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStandCapabilityPacket implements IMessage<SSyncStandCapabilityPacket> {
    private Tag data;

    public SSyncStandCapabilityPacket() {
    }

    private SSyncStandCapabilityPacket(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncStandCapabilityPacket(Stand props) {
        data = Stand.STORAGE.writeNBT(Stand.STAND, props, null);
    }

    @Override
    public void encode(SSyncStandCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }

    @Override
    public SSyncStandCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncStandCapabilityPacket(buffer.readNbt());
    }

    @Override
    public void handle(SSyncStandCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                Player player = DiamondIsUncraftable.PROXY.getPlayer();
                if (player == null) return;
                Stand.getLazyOptional(player).ifPresent(props -> Stand.STORAGE.readNBT(Stand.STAND, props, null, message.data));
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
