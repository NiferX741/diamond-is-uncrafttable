package io.github.halffocused.diamond_is_uncraftable.client.entity.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 1.16 ModelRenderer-shaped wrapper over 1.18 {@link ModelPart}.
 * The stand attack and Sticky Fingers meshes were authored against the old API.
 */
public class ModelRenderer {
    public float rotateAngleX;
    public float rotateAngleY;
    public float rotateAngleZ;
    public float rotationPointX;
    public float rotationPointY;
    public float rotationPointZ;

    private final List<ModelPart.Cube> cubes = new ArrayList<>();
    private final List<ModelRenderer> children = new ArrayList<>();
    private final int texWidth;
    private final int texHeight;
    private int texU;
    private int texV;

    public ModelRenderer(EntityModel<?> model) {
        this.texWidth = readInt(model, "textureWidth", 64);
        this.texHeight = readInt(model, "textureHeight", 32);
    }

    public void setRotationPoint(float x, float y, float z) {
        this.rotationPointX = x;
        this.rotationPointY = y;
        this.rotationPointZ = z;
    }

    public ModelRenderer setTextureOffset(int u, int v) {
        this.texU = u;
        this.texV = v;
        return this;
    }

    public void addBox(float x, float y, float z, float width, float height, float depth, float grow, boolean mirror) {
        cubes.add(new ModelPart.Cube(texU, texV, x, y, z, width, height, depth, grow, grow, grow, mirror, texWidth, texHeight));
    }

    public void addChild(ModelRenderer child) {
        children.add(child);
    }

    public void render(PoseStack pose, VertexConsumer consumer, int light, int overlay) {
        bake().render(pose, consumer, light, overlay);
    }

    public void render(PoseStack pose, VertexConsumer consumer, int light, int overlay, float red, float green, float blue, float alpha) {
        bake().render(pose, consumer, light, overlay, red, green, blue, alpha);
    }

    private ModelPart bake() {
        Map<String, ModelPart> bakedChildren = new LinkedHashMap<>();
        for (int i = 0; i < children.size(); i++) {
            bakedChildren.put("c" + i, children.get(i).bake());
        }
        ModelPart part = new ModelPart(new ArrayList<>(cubes), bakedChildren);
        part.x = rotationPointX;
        part.y = rotationPointY;
        part.z = rotationPointZ;
        part.xRot = rotateAngleX;
        part.yRot = rotateAngleY;
        part.zRot = rotateAngleZ;
        return part;
    }

    private static int readInt(Object model, String name, int fallback) {
        for (Class<?> type = model.getClass(); type != null; type = type.getSuperclass()) {
            try {
                Field field = type.getDeclaredField(name);
                field.setAccessible(true);
                return field.getInt(model);
            } catch (NoSuchFieldException ignored) {
            } catch (IllegalAccessException ignored) {
                break;
            }
        }
        return fallback;
    }
}
