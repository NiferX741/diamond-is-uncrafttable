package io.github.halffocused.diamond_is_uncraftable.client.entity.model;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import net.minecraft.client.model.EntityModel;

/**
 * Handles the head rotation of {@link AbstractStandEntity}s.
 */
public abstract class AbstractStandModel<T extends AbstractStandEntity> extends EntityModel<T> {
    public int textureWidth = 64;
    public int textureHeight = 32;
    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        setRotationAngle(getHead(), headPitch / 90, netHeadYaw / 90, getHead().rotateAngleZ);
    }

    protected void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    protected abstract ModelRenderer getHead();
}
