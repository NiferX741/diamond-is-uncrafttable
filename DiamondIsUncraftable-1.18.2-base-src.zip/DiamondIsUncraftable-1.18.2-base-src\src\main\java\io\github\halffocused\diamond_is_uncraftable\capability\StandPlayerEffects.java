package io.github.halffocused.diamond_is_uncraftable.capability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class StandPlayerEffects implements ICapabilitySerializable<Tag> {
    public static final Capability<StandPlayerEffects> STAND_PLAYER_EFFECTS = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<StandPlayerEffects> STORAGE;
    private final Player player;
    private final NonNullList<ItemStack> mainInventory = NonNullList.withSize(36, ItemStack.EMPTY);
    private final NonNullList<ItemStack> armorInventory = NonNullList.withSize(4, ItemStack.EMPTY);
    private final NonNullList<ItemStack> offHandInventory = NonNullList.withSize(1, ItemStack.EMPTY);
    private final NonNullList<ItemStack> enderChestInventory = NonNullList.withSize(27, ItemStack.EMPTY);
    private LazyOptional<StandPlayerEffects> holder = LazyOptional.of(() -> new StandPlayerEffects(getPlayer()));

    public StandPlayerEffects(Player player) {
        this.player = player;
    }

    public static void register() {
        STORAGE = new CapStorage<StandPlayerEffects>() {
            @Override
            public Tag writeNBT(Capability<StandPlayerEffects> capability, StandPlayerEffects instance, Direction side) {
                CompoundTag compoundNBT = new CompoundTag();
                ListTag inventory = new ListTag();
                ListTag enderChestInventory = new ListTag();
                for (int i = 0; i < instance.mainInventory.size(); i++)
                    if (!instance.mainInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.mainInventory.get(i).save(compoundnbt);
                        inventory.add(compoundnbt);
                    }
                for (int j = 0; j < instance.armorInventory.size(); j++)
                    if (!instance.armorInventory.get(j).isEmpty()) {
                        CompoundTag compoundnbt1 = new CompoundTag();
                        compoundnbt1.putByte("Slot", (byte) (j + 100));
                        instance.armorInventory.get(j).save(compoundnbt1);
                        inventory.add(compoundnbt1);
                    }
                for (int k = 0; k < instance.offHandInventory.size(); k++)
                    if (!instance.offHandInventory.get(k).isEmpty()) {
                        CompoundTag compoundnbt2 = new CompoundTag();
                        compoundnbt2.putByte("Slot", (byte) (k + 150));
                        instance.offHandInventory.get(k).save(compoundnbt2);
                        inventory.add(compoundnbt2);
                    }
                for (int l = 0; l < instance.enderChestInventory.size(); l++)
                    if (!instance.enderChestInventory.get(l).isEmpty()) {
                        CompoundTag compoundnbt3 = new CompoundTag();
                        compoundnbt3.putByte("Slot", (byte) l);
                        instance.enderChestInventory.get(l).save(compoundnbt3);
                        enderChestInventory.add(compoundnbt3);
                    }
                compoundNBT.put("inventory", inventory);
                compoundNBT.put("enderChestInventory", enderChestInventory);
                return compoundNBT;
            }

            @SuppressWarnings("ConstantConditions")
            @Override
            public void readNBT(Capability<StandPlayerEffects> capability, StandPlayerEffects instance, Direction side, Tag nbt) {
                ListTag inventory = ((CompoundTag) nbt).getList("inventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < inventory.size(); i++) {
                    CompoundTag compoundnbt = inventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j >= 0 && j < instance.mainInventory.size())
                            instance.mainInventory.set(j, itemstack);
                        else if (j >= 100 && j < instance.armorInventory.size() + 100)
                            instance.armorInventory.set(j - 100, itemstack);
                        else if (j >= 150 && j < instance.offHandInventory.size() + 150)
                            instance.offHandInventory.set(j - 150, itemstack);
                }
                ListTag enderChestInventory = ((CompoundTag) nbt).getList("enderChestInventory", Tag.TAG_COMPOUND);
                for (int k = 0; k < enderChestInventory.size(); k++) {
                    CompoundTag compoundnbt = enderChestInventory.getCompound(k);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        instance.enderChestInventory.set(j, itemstack);
                }
            }
        };
    }

    public static LazyOptional<StandPlayerEffects> getLazyOptional(Player player) {
        return player.getCapability(STAND_PLAYER_EFFECTS);
    }

    public Player getPlayer() {
        return player;
    }

    public NonNullList<ItemStack> getMainInventory() {
        return mainInventory;
    }

    public NonNullList<ItemStack> getArmorInventory() {
        return armorInventory;
    }

    public NonNullList<ItemStack> getOffHandInventory() {
        return offHandInventory;
    }

    public NonNullList<ItemStack> getEnderChestInventory() {
        return enderChestInventory;
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == STAND_PLAYER_EFFECTS ? holder.cast() : LazyOptional.empty();
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(STAND_PLAYER_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(STAND_PLAYER_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }
}
