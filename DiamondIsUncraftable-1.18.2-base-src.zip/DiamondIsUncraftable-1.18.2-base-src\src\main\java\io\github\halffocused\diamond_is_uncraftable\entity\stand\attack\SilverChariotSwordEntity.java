package io.github.halffocused.diamond_is_uncraftable.entity.stand.attack;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

public class SilverChariotSwordEntity extends AbstractStandAttackEntity {
    public SilverChariotSwordEntity(EntityType<? extends AbstractStandAttackEntity> type, Level worldIn) {
        super(type, worldIn);
    }

    public SilverChariotSwordEntity(Level worldIn, AbstractStandEntity shooter, Player player) {
        super(EntityInit.SILVER_CHARIOT_SWORD.get(), worldIn, shooter, player);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if(!level.isClientSide()) {
            Entity entity = result.getEntity();
            if (entity instanceof LivingEntity) {
                Util.dealStandDamage(shootingStand, (LivingEntity) entity, 18, Vec3.ZERO, false);
            }
            entity.invulnerableTime = 0;
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult result) {
    }

    @Override
    public ResourceLocation getTextureLocation() {
        return Util.ResourceLocations.SILVER_CHARIOT_SWORD;
    }

    @Override
    protected int getRange() {
        return 100;
    }
}
