package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.capability.StandPerWorldCapability;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent.Context;

import java.util.Objects;
import java.util.function.Supplier;


@SuppressWarnings("ConstantConditions")
public class CAddStandToWorldData implements IMessage<CAddStandToWorldData> {
    private int standId;

    public CAddStandToWorldData(int entityId) {
        this.standId = entityId;
    }

    public CAddStandToWorldData() {
    }

    @Override
    public void handle(CAddStandToWorldData message, Supplier<Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                Player sender = ctx.get().getSender();
                assert sender != null;
                Level world = sender.level;
                if (world != null)
                    if (!world.isClientSide) {
                        Objects.requireNonNull(world.getServer()).getLevel(world.dimension());
                        StandPerWorldCapability.getLazyOptional(world.getServer().getLevel(world.dimension())).ifPresent(uniqueStandHandler -> {
                            uniqueStandHandler.addTakenStandId(standId);
                        });
                    }
                });
            }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(CAddStandToWorldData message, FriendlyByteBuf buffer) {
        buffer.writeInt(message.standId);
    }

    @Override
    public CAddStandToWorldData decode(FriendlyByteBuf buffer) {
        return new CAddStandToWorldData(
            buffer.readInt()
        );
    }
}
