package io.github.halffocused.diamond_is_uncraftable.particle;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ParticleList {

    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, DiamondIsUncraftable.MOD_ID);

    public static final RegistryObject<SimpleParticleType> MENACING_PARTICLE = PARTICLES.register("menacing_particle",() -> new SimpleParticleType(true));

    public static final RegistryObject<SimpleParticleType> ZIPPER = PARTICLES.register("zipper_particle",() -> new SimpleParticleType(true));

}
