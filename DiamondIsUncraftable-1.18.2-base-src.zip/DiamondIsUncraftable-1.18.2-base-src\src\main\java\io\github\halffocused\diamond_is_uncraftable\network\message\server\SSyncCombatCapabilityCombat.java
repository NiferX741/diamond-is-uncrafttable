package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.capability.CombatCapability;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncCombatCapabilityCombat implements IMessage<SSyncCombatCapabilityCombat> {
    private Tag data;

    public SSyncCombatCapabilityCombat() {
    }

    private SSyncCombatCapabilityCombat(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncCombatCapabilityCombat(CombatCapability props) {
        data = CombatCapability.STORAGE.writeNBT(CombatCapability.COMBAT, props, null);
    }

    @Override
    public void encode(SSyncCombatCapabilityCombat message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }

    @Override
    public SSyncCombatCapabilityCombat decode(FriendlyByteBuf buffer) {
        return new SSyncCombatCapabilityCombat(buffer.readNbt());
    }

    @Override
    public void handle(SSyncCombatCapabilityCombat message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                Minecraft.getInstance().level.entitiesForRendering().forEach(entity -> CombatCapability.getLazyOptional(entity).ifPresent(props ->
                        CombatCapability.STORAGE.readNBT(CombatCapability.COMBAT, props, null, message.data)
                ));
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
