package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.systems.RenderSystem;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.client.entity.model.AbstractStandAttackModel;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.AbstractStandAttackEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.EntityModel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;

public class StandAttackRenderer<T extends AbstractStandAttackEntity> extends EntityRenderer<T> {
    AbstractStandAttackModel<T> model;

    public StandAttackRenderer(EntityRendererProvider.Context manager) {
        super(manager);
    }

    public StandAttackRenderer(EntityRendererProvider.Context manager, AbstractStandAttackModel<T> model) {
        super(manager);
        this.model = model;
    }


    protected void render(T entityIn, float entityYaw, float partialTicks, PoseStack matrixStackIn, MultiBufferSource bufferIn, int packedLightIn, EntityModel<T> model) {
        RenderSystem.setShaderTexture(0, getTextureLocation(entityIn));
        matrixStackIn.pushPose();
        matrixStackIn.translate((float) entityIn.getX(), (float) entityIn.getY(), (float) entityIn.getZ());
        matrixStackIn.scale(2, 2, 2);
        matrixStackIn.popPose();
        model.setupAnim(entityIn, partialTicks, 0, partialTicks, entityIn.getYRot(), entityIn.getXRot()); //Rotates the punch to face away from the Stand user,
        model.renderToBuffer(matrixStackIn, bufferIn.getBuffer(RenderType.entitySmoothCutout(getTextureLocation(entityIn))), packedLightIn, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
    }

    @Override
    public void render(T entityIn, float entityYaw, float partialTicks, PoseStack matrixStackIn, MultiBufferSource bufferIn, int packedLightIn) {
        if (Minecraft.getInstance().getCameraEntity() instanceof AbstractStandEntity)
            render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn, model);
        else if (Minecraft.getInstance().getCameraEntity() instanceof Player)
            Stand.getLazyOptional((Player) Minecraft.getInstance().getCameraEntity()).ifPresent(props -> {
                if (props.getStandID() != 0)
                    render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn, model);
            });
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return entity.getTextureLocation();
    }
}
