package io.github.halffocused.diamond_is_uncraftable.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.Tag;
import net.minecraftforge.common.capabilities.Capability;

/**
 * Replaces the 1.16 {@code Capability.IStorage} API, which Forge removed in 1.18.
 * Persistence still goes through {@code ICapabilitySerializable}; this just keeps the old read/write bodies.
 */
public interface CapStorage<T> {
    Tag writeNBT(Capability<T> capability, T instance, Direction side);

    void readNBT(Capability<T> capability, T instance, Direction side, Tag nbt);
}
