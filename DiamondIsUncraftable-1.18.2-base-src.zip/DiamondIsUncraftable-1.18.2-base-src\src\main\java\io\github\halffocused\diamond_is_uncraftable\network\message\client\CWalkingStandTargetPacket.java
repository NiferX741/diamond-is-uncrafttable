package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import io.github.halffocused.diamond_is_uncraftable.util.IWalkingStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CWalkingStandTargetPacket implements IMessage<CWalkingStandTargetPacket> {
    @Override
    public void encode(CWalkingStandTargetPacket message, FriendlyByteBuf buffer) {
    }

    @Override
    public CWalkingStandTargetPacket decode(FriendlyByteBuf buffer) {
        return new CWalkingStandTargetPacket();
    }

    @Override
    public void handle(CWalkingStandTargetPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                Player sender = ctx.get().getSender();
                assert sender != null;
                Level world = sender.level;
                if (world != null)
                    if (!world.isClientSide) {
                        java.util.stream.StreamSupport.stream(world.getServer().getLevel(sender.level.dimension()).getAllEntities().spliterator(), false)
                                .filter(entity -> entity instanceof AbstractStandEntity)
                                .filter(entity -> entity instanceof IWalkingStand)
                                .filter(entity -> ((AbstractStandEntity) entity).getMaster().equals(sender))
                                .forEach(entity -> ((IWalkingStand) entity).getWalkingController().changeTargetting());
                    }
            });
        }
        ctx.get().setPacketHandled(true);
    }
}