package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.capability.StandEffects;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStandEffectsCapabilityPacket implements IMessage<SSyncStandEffectsCapabilityPacket> {
    private Tag data;

    public SSyncStandEffectsCapabilityPacket() {
    }

    private SSyncStandEffectsCapabilityPacket(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncStandEffectsCapabilityPacket(StandEffects props) {
        data = StandEffects.STORAGE.writeNBT(StandEffects.STAND_EFFECTS, props, null);
    }

    @Override
    public SSyncStandEffectsCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncStandEffectsCapabilityPacket(buffer.readNbt());
    }

    @Override
    public void handle(SSyncStandEffectsCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                Minecraft.getInstance().level.entitiesForRendering().forEach(entity -> StandEffects.getLazyOptional(entity).ifPresent(props ->
                        StandEffects.STORAGE.readNBT(StandEffects.STAND_EFFECTS, props, null, message.data)
                ));
            });
        }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(SSyncStandEffectsCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }
}
