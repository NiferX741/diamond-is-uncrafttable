package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.init.EffectInit;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Stance;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.WalkingMoveHandler;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import software.bernie.geckolib3.core.IAnimatable;

@SuppressWarnings("ConstantConditions")
public class PurpleHazeEntity extends AbstractStandEntity implements IAnimatable, IWalkingStand, IOnHit, ICommandGrab {

    int viralModifier = 0;

    AttackFramedata normalPunchData = new AttackFramedata(22)
            .addDamageFrame(9, 4, Vec3.ZERO, 2.0, 3)
            .addDamageFrame(12, 6, Vec3.ZERO, 2.0, 3);

    AttackFramedata ragePunchData = new AttackFramedata(14)
            .addDamageFrame(9, 10, Vec3.ZERO, 2.0, 1, false);

    AttackFramedata rageSlam = new AttackFramedata(50)
            .addRadialDamageFrame(31, 16, new Vec3(0, 0.7, 0), 6, false)
            .addMessageFrame(31, 1, 0,0);

    AttackFramedata barrageData = new AttackFramedata(109)
            .generateInterval(45, 108, 2, 2, Vec3.ZERO, 3, 4);

    AttackFramedata commandGrabData = new AttackFramedata(80)
            .addGrabFrame(23, 3.0);



    public HoveringMoveHandler getController(){
        return null;
    }

    Stance normalStance = new Stance(1, 0.17, 0.5, 3, 2, 12,"idle", "forward", false)
            .addWalkingMove(1, new Move("Double Punch", normalPunchData, "jab", 1, -3), 1.0, 3, 20);

    Stance enragedStance = new Stance(3, 0.25, 0.5, 10, -1, 15,"rageidle", "ragesprint", true)
            .addWalkingMove(1, new Move("Rage Punch", ragePunchData, "ragepunch", 1, -3, true), 0.7, 3, 15)
            .addWalkingMove(2, new Move("Rage Slam", rageSlam, "rageslam", 2, -3, true), 0.3, 6, 20);

    Stance violentStance = new Stance(2, 0.17, 0.5, 3, 2, 12,"idle", "forward", false)
            .addWalkingMove(1, new Move("Double Punch", normalPunchData, "jab", 1, -3), 0.6, 3, 20)
            .addWalkingMove(2, new Move("Rage Punch", ragePunchData, "ragepunch", 2, -3), 0.4, 3, 20);

    WalkingMoveHandler controller = new WalkingMoveHandler(this, 1)
            .addStance(normalStance)
            .addStance(enragedStance)
            .addStance(violentStance);

    public PurpleHazeEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    public void commandGrab() {
        if(controller.getActiveStance().getId() != 3){
            controller.setMoveActive(3);
        }
    }

    @Override
    public void playSpawnSound() {
        level.playSound(null, getMaster().blockPosition(), getSpawnSound(), SoundSource.NEUTRAL, 2, 1);
    }

    @Override
    public void tick() {
        super.tick();
        if (getMaster() != null) {

            Stand.getLazyOptional(master).ifPresent(stand ->{

                if(controller.getActiveStanceId() == 3) {
                    if (this.tickCount % 40 == 0) {
                        stand.setRage(Math.max(stand.getRage() - 1, 0));
                    }
                }else{
                    if (this.tickCount % 25 == 0) {
                        stand.setRage(Math.max(stand.getRage() - 1, 0));
                    }
                }

            });

            if(controller.getActiveStanceId() == 3){
                if(distanceTo(master) > 20){
                    this.setPos(master.getX(), master.getY(), master.getZ());
                }
            }
        }

        Stand.getLazyOptional(master).ifPresent(stand -> {
            stand.setPreventUnsummon2(stand.getRage() >= 25);

            Style warningStyle = Style.EMPTY.setUnderlined(true);
            if((this.tickCount + 20) % 20 >= 11){
                warningStyle.applyFormat(ChatFormatting.RED);
            }else{
                warningStyle.applyFormat(ChatFormatting.GRAY);
            }
            String message = "";
            if(stand.getRage() < 25){
                message = "Purple Haze: Under Control";
                viralModifier = 0;
                controller.setActiveStance(1);
            }else if(stand.getRage() < 50){
                message = "Purple Haze: Mildly Angered";
                viralModifier = 0;
                controller.setActiveStance(1);
            }else if(stand.getRage() < 75){
                message = "Purple Haze: Violent";
                viralModifier = 1;
                controller.setActiveStance(2);
            }else if(stand.getRage() < 100){
                message = "Purple Haze: On The Verge!";
                viralModifier = 1;
                controller.setActiveStance(2);
            }else if(stand.getRage() >= 100){
                message = "Purple Haze: Rampaging!";
                viralModifier = 2;
                controller.setActiveStance(3);
            }

            master.displayClientMessage(new TextComponent(message).setStyle(warningStyle), true);
        });


    }

    @Override
    public void chargeAttack(boolean isCharging, boolean isBarrage) {
        if (getMaster() == null) return;
        controller.tick(isCharging, isBarrage);
    }




    @Override
    public void changeTargetingMode() {
        controller.changeTargetting();
    }

    @Override
    public WalkingMoveHandler getWalkingController() {
        return controller;
    }

    private void addRage(int incrementRage){
        Stand.getLazyOptional(master).ifPresent(props -> {
            int newRage = (Math.max(0, props.getRage() + incrementRage));
            props.setRage(Math.min(200, newRage));
        });
    }

    @Override
    public boolean hurt(DamageSource damageSource, float damage) {
        if (master == null || damageSource.getEntity() == master || damageSource == DamageSource.CACTUS || damageSource == DamageSource.FALL)
            return false; //Prevents Stands from taking damage they shouldn't, fall damage, cactus damage, etc.
            addRage((int) (damage * 2));

        master.hurt(damageSource, damage * 0.25f);

        return false;
    }

    @Override
    public void messageFrame(int message1, Object message2, Object message3){
        if(message1 == 1){
            if(!this.level.isClientSide()) {
                Explosion explosion = new Explosion(this.level, master, this.getX(), this.getY(), this.getZ(), 2, true, Explosion.BlockInteraction.DESTROY);
                this.level.addParticle(net.minecraft.core.particles.ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 0, 0, 0);
                level.playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, 1);
                explosion.finalizeExplosion(true);
                Util.spawnParticle(this, 3, this.getX(), this.getY(), this.getZ(), 16, 2, 16, 25);

            }
        }
    }

    @Override
    public void onHit(LivingEntity entity, float damage) {
        entity.addEffect(new MobEffectInstance(EffectInit.HAZE.get(), 80, (int) Math.ceil(damage / 8) + viralModifier));
        addRage((int) (damage / 1.2));
    }

    @Override
    public void onCommandGrabEnd(LivingEntity entity){

    }

    @Override
    public void whileCommandGrabbing(LivingEntity entity){
        //Do nothing
    }

    @Override
    public double commandGrabDistance() {
        return 1.75;
    }

    @Override
    public int commandGrabDuration() {
        return 60;
    }

    @Override
    public String holdingAnimation() {
        return "holding";
    }
}
