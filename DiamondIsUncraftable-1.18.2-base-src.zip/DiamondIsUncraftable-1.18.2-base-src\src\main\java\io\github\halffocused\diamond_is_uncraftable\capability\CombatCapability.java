package io.github.halffocused.diamond_is_uncraftable.capability;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncCombatCapabilityCombat;
import net.minecraft.world.entity.Entity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.core.Direction;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

/**
 * The {@link Capability} used for storing combat related values like hit-stun.
 */
public class CombatCapability implements ICapabilitySerializable<Tag> {
    public static final Capability<CombatCapability> COMBAT = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<CombatCapability> STORAGE; //Null method suppresses warnings
    private final Entity entity;
    private int hitstun = 0;

    private LazyOptional<CombatCapability> holder = LazyOptional.of(() -> new CombatCapability(getEntity()));

    public CombatCapability(@Nonnull Entity entityIn) {
        this.entity = entityIn;
    }

    public static CombatCapability getCapabilityFromEntity(Entity entityIn) {
        return entityIn.getCapability(COMBAT).orElse(new CombatCapability(entityIn));
    }

    public static LazyOptional<CombatCapability> getLazyOptional(Entity entityIn) {
        return entityIn.getCapability(COMBAT);
    }

    public static void register() {
        STORAGE = new CapStorage<CombatCapability>() {
            @Nonnull
            @Override
            public Tag writeNBT(Capability<CombatCapability> capability, CombatCapability instance, Direction side) {
                CompoundTag nbt = new CompoundTag();
                nbt.putInt("hitstun", instance.getHitstun());
                return nbt;
            }

            @Override
            public void readNBT(Capability<CombatCapability> capability, CombatCapability instance, Direction side, Tag nbt) {
                CompoundTag compoundNBT = (CompoundTag) nbt;
                instance.hitstun = compoundNBT.getInt("hitstun");
            }
        };
    }

    public int getHitstun() {
        return this.hitstun;
    }

    public void setHitstun(int hitStunIn) {
        this.hitstun = hitStunIn;
        onDataUpdated();
    }

    public Entity getEntity() {
        return entity;
    }

    /**
     * Called to update the {@link Capability} to the client.
     */
    public void onDataUpdated() {
        if (!entity.level.isClientSide)
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity), new SSyncCombatCapabilityCombat(this));
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @Nullable Direction side) {
        return capability == COMBAT ? holder.cast() : LazyOptional.empty();
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(COMBAT, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(COMBAT, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }
}
