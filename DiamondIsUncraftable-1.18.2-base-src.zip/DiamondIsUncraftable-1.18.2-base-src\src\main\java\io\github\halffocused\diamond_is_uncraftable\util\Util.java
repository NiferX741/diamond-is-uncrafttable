package io.github.halffocused.diamond_is_uncraftable.util;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.capability.StandChunkEffects;
import io.github.halffocused.diamond_is_uncraftable.capability.Timestop;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.*;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.AbstractStandAttackEntity;
import io.github.halffocused.diamond_is_uncraftable.init.*;
import io.github.halffocused.diamond_is_uncraftable.item.StandArrowItem;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SParticlePacket;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.entity.animal.horse.ZombieHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.model.data.EmptyModelData;
import net.minecraftforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import javax.annotation.CheckForNull;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;
import java.util.function.Predicate;

/**
 * Used for various utilities and constants.
 */
@SuppressWarnings("unused")
public class Util {

    public static double horizontalMag(Vec3 vec) {
        return vec.x * vec.x + vec.z * vec.z;
    }

    public static int getIntField(Object target, String name) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(name);
            field.setAccessible(true);
            return field.getInt(target);
        } catch (ReflectiveOperationException exception) {
            return 0;
        }
    }

    public static void setIntField(Object target, String name, int value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(name);
            field.setAccessible(true);
            field.setInt(target, value);
        } catch (ReflectiveOperationException ignored) {
        }
    }

    public static void revive(Entity entity) {
        try {
            java.lang.reflect.Method method = Entity.class.getDeclaredMethod("unsetRemoved");
            method.setAccessible(true);
            method.invoke(entity);
        } catch (ReflectiveOperationException ignored) {
        }
    }

    public static boolean isOffsetPositionInLiquid(LivingEntity entity, double x, double y, double z) {
        AABB box = entity.getBoundingBox().move(x, y, z);
        return entity.level.noCollision(entity, box) && !entity.level.containsAnyLiquid(box);
    }

    public static java.util.List<net.minecraft.world.level.block.entity.BlockEntity> loadedBlockEntities(net.minecraft.server.level.ServerLevel level) {
        java.util.List<net.minecraft.world.level.block.entity.BlockEntity> list = new java.util.ArrayList<>();
        int radius = level.getServer().getPlayerList().getViewDistance();
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            net.minecraft.world.level.ChunkPos center = player.chunkPosition();
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    net.minecraft.world.level.chunk.LevelChunk chunk = level.getChunkSource().getChunkNow(center.x + x, center.z + z);
                    if (chunk != null) {
                        list.addAll(chunk.getBlockEntities().values());
                    }
                }
            }
        }
        return list;
    }

    static Random rand = new Random();

    /**
     * The true default Y motion for entities.
     */
    public static final double ENTITY_DEFAULT_Y_MOTION = -0.0784000015258789;

    public static int getHighestBlockInXZ(Level world, BlockPos pos) {
        for (int height = world.getHeight(); height > 0; height--)
            if (world.getBlockState(new BlockPos(pos.getX(), height, pos.getZ())).getMaterial() != Material.AIR)
                return height;
        return -1;
    }

    public static Vec3 rotationVectorIgnoreY(LivingEntity entity) {
        float f = entity.getXRot() * ((float)Math.PI / 180F);
        float f1 = -entity.getYRot() * ((float)Math.PI / 180F);
        float f2 = Mth.cos(f1);
        float f3 = Mth.sin(f1);
        float f4 = Mth.cos(f);
        float f5 = Mth.sin(f);
        return new Vec3((double)(f3), 0, (double)(f2));
    }

    /**
     * Returns whether or not the exact point pos is in any block's collision box.
     * world.getBlockState().getMaterial().isSolid() has a lot of issues that necessitated the creation of this method.
     * @param world The world that the collision check is taking place in.
     * @param pos The position vector being checked.
     * @return if the pos exists in any block's collision.
     */
    public static boolean isPointAtVecSolid(Level world, Vec3 pos){
        VoxelShape collision = world.getBlockState(new BlockPos(pos)).getCollisionShape(world, new BlockPos(pos));
        for(AABB box : collision.toAabbs()){
            if(box.move(new BlockPos(pos)).contains(pos)){
                return true;
            }
        }
        return false;
    }

    public static void teleportUntilWall(LivingEntity entity, Vec3 vec, double maxDistance){

        double incrementSize = 0.01;
        
        Vec3 currentPosition = new Vec3(entity.getX(), entity.getY() + entity.getEyeHeight(), entity.getZ());
        Vec3 increment = vec.normalize().scale(incrementSize);
        boolean hitWall = false;
        Vec3 futurePosition = currentPosition.add(increment.scale(1 / incrementSize));

        for(int i = 0; i < maxDistance * (1 / incrementSize) && !hitWall; i++){

            if(Util.isPointAtVecSolid(entity.level, futurePosition)){
                hitWall = true;
            }
            currentPosition = currentPosition.add(increment);
            futurePosition = currentPosition.add(increment.scale(1 / incrementSize));
        }
        if(!hitWall){
            currentPosition = futurePosition;
        }
         entity.teleportTo(currentPosition.x, currentPosition.y, currentPosition.z);
    }

    public static double heightAboveGround(Level world, Vec3 pos){
        double distanceUntilGround = 0;
        while(!Util.isPointAtVecSolid(world, pos.add(new Vec3(0, -distanceUntilGround, 0)))){
            distanceUntilGround -= 0.01;
        }
        System.out.println("heightAboveGround resolved");
        return distanceUntilGround;
    }

    public static BlockPos getNearestBlockEnd(Level world, BlockPos pos) {
        for (int height = world.getHeight(); height > 0; height--) {
            if (pos.getX() > 0) {
                for (int x = pos.getX(); x > 0; x--)
                    if (world.getBlockState(new BlockPos(x, height, pos.getZ())).getMaterial() != Material.AIR)
                        return new BlockPos(x, height, pos.getZ());
            } else if (pos.getX() < 0) {
                for (int x = pos.getX(); x < 0; x++)
                    if (world.getBlockState(new BlockPos(x, height, pos.getZ())).getMaterial() != Material.AIR)
                        return new BlockPos(x, height, pos.getZ());
            }
        }
        return new BlockPos(0, 65, 0); //The location of the End exit portal.
    }

    public static SoundEvent getHitSound(AbstractStandEntity standIn){

        Random randomNoise = standIn.getRandom();

        switch(randomNoise.nextInt(7)){
            case 1:
                return SoundInit.PUNCH_2.get();
            case 2:
                return SoundInit.PUNCH_3.get();
            case 3:
                return SoundInit.PUNCH_4.get();
            case 4:
                return SoundInit.PUNCH_5.get();
            case 5:
                return SoundInit.PUNCH_6.get();
            case 6:
                return SoundInit.PUNCH_7.get();
            default:
                return SoundInit.PUNCH_1.get();
        }


    }

    public static boolean canStandMoveInStoppedTime(int standId){
        return standId == StandID.THE_WORLD;
    }

    public static boolean isTimeStoppedForEntity(LivingEntity entity){
            if(entity instanceof Player){
                Stand props = Stand.getCapabilityFromPlayer((Player) entity);
                return props.getExperiencingTimeStop() && !canStandMoveInStoppedTime(props.getStandID());
            }else{
                return !Timestop.getCapabilityFromEntity(entity).isEmpty();
            }
    }

    public static void activateEchoesAbility(Level world, @Nonnull LivingEntity entity, BlockPos pos, StandChunkEffects chunkEffects, @Nullable Player player, List<BlockPos> list) {
        if (world.isClientSide) return;
        switch (new Random().nextInt(4)) {
            case 0: {
                world.explode(null, pos.getX(), pos.getY(), pos.getZ(), 3, Explosion.BlockInteraction.DESTROY);
                break;
            }
            case 1: {
                entity.setDeltaMovement(entity.getDeltaMovement().add(0, 1, 0));
                entity.hasImpulse = true;
                break;
            }
            case 2: {
                entity.hurt(DamageSource.HOT_FLOOR, 2);
                entity.setSecondsOnFire(4);
                break;
            }
            case 3: {
                entity.hurt(DamageSource.OUT_OF_WORLD, 10);
                break;
            }
            default:
                break;
        }
        if (player != null) {
            list.add(pos);
            Stand.getLazyOptional(player).ifPresent(stand -> stand.setAbilityUseCount(stand.getAbilityUseCount() - 1));
        }
        world.removeBlock(pos, false);
    }

    @SuppressWarnings("SwitchStatementWithTooFewBranches")
    public static void setupActSwitch(ServerPlayer standMaster, int standID, int act) {
        switch (standID) {
            default:
                break;
        }
    }

    public static boolean isClientHoldingShift() {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_KEY_LEFT_SHIFT) || InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    public static EntityHitResult getEntityHitResult(Entity shooter, Vec3 startVec, Vec3 endVec, AABB boundingBox, Predicate<Entity> filter, double distance) {
        Level world = shooter.level;
        double d0 = distance;
        Entity entity = null;
        Vec3 vec3d = null;

        for (Entity entity1 : world.getEntities(shooter, boundingBox, filter)) {
            AABB axisalignedbb = entity1.getBoundingBox().inflate(entity1.getPickRadius());
            Optional<Vec3> optional = axisalignedbb.clip(startVec, endVec);
            if (axisalignedbb.contains(startVec)) {
                if (d0 >= 0) {
                    entity = entity1;
                    vec3d = optional.orElse(startVec);
                    d0 = 0;
                }
            } else if (optional.isPresent()) {
                Vec3 vec3d1 = optional.get();
                double d1 = startVec.distanceToSqr(vec3d1);
                if (d1 < d0 || d0 == 0) {
                    if (entity1.getRootVehicle() == shooter.getRootVehicle() && !entity1.canRiderInteract()) {
                        if (d0 == 0) {
                            entity = entity1;
                            vec3d = vec3d1;
                        }
                    } else {
                        entity = entity1;
                        vec3d = vec3d1;
                        d0 = d1;
                    }
                }
            }
        }

        return entity == null ? Null() : new EntityHitResult(entity, vec3d);
    }

    /**
     * Suppresses warning for unchecked casts.
     */
    @SuppressWarnings("unchecked")
    public static <T> T cast(Object o) {
        return (T) o;
    }

    /**
     * Got these values from <a href ="https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/minecraft-mods/modification-development/1435515-how-i-can-do-to-move-to-where-i-look#c5">this</a> thread, shortened it a little bit.
     */
    public static Vec3 getEntityForwardsMotion(Entity entity) {
        return new Vec3(
                -Mth.sin(entity.getYRot() / 180 * (float) Math.PI) * Mth.cos(entity.getXRot() / 180 * (float) Math.PI),
                Mth.cos(entity.getYRot() / 180 * (float) Math.PI) * Mth.cos(entity.getXRot() / 180 * (float) Math.PI),
                Mth.cos(entity.getYRot() / 180 * (float) Math.PI) * Mth.cos(entity.getXRot() / 180 * (float) Math.PI)
        );
    }

    public static AABB getAttackHitbox(AbstractStandEntity standIn, double rangeIn){
        return getAttackHitbox(standIn, rangeIn, 0.25D);
    }

    public static AABB getAttackHitbox(AbstractStandEntity standIn, double rangeIn, double sizeIn){
        return standIn.getBoundingBox()
                .move(standIn.getLookAngle().normalize().multiply(1.5, 1.5, 1.5))
                .expandTowards(standIn.getLookAngle().scale(rangeIn - 1.0)).inflate(sizeIn);
    }

    /**
     * Statically renders the given {@link BlockState} at the given {@link BlockPos}, like {@link net.minecraft.client.renderer.entity.EntityRendererProvider#renderEntityStatic(Entity, double, double, double, float, float, PoseStack, MultiBufferSource, int)}, but for blocks.
     */
    public static void renderBlockStatic(PoseStack matrixStack, MultiBufferSource.BufferSource buffer, Level world, BlockState blockState, BlockPos blockPos, Vec3 projectedView, boolean occlusionCulling) {
        matrixStack.pushPose();
        matrixStack.translate(-projectedView.x + blockPos.getX(), -projectedView.y + blockPos.getY(), -projectedView.z + blockPos.getZ());
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(blockState, matrixStack, buffer, 15728880, OverlayTexture.NO_OVERLAY);
        matrixStack.popPose();
        buffer.endBatch();
    }

    /**
     * Used to suppress warnings saying that <code>static final</code> fields are <code>null</code>.
     * Based on diesieben07's solution <a href="http://www.minecraftforge.net/forum/topic/60980-solved-disable-%E2%80%9Cconstant-conditions-exceptions%E2%80%9D-inspection-for-field-in-intellij-idea/?do=findCommentcomment=285024">here</a>.
     *
     * @return null
     */
    @Nonnull
    @SuppressWarnings("ConstantConditions")
    public static <T> T Null() {
        return null;
    }

    public static void travelWithFriction(LivingEntity entity, float slipperiness) {
        Vec3 positionIn = new Vec3(entity.xxa, entity.yya, entity.zza);
        if (!entity.level.isClientSide() || entity.isControlledByLocalInstance()) {
            double d0 = 0.08;
            boolean flag = entity.getDeltaMovement().y <= 0;
            if (flag && entity.hasEffect(MobEffects.SLOW_FALLING))
                entity.fallDistance = 0;
            if (!entity.isInWater() || entity instanceof Player && ((Player) entity).getAbilities().flying) {
                if (!entity.isInLava() || entity instanceof Player && ((Player) entity).getAbilities().flying) {
                    if (entity.isFallFlying()) {
                        Vec3 vec3d3 = entity.getDeltaMovement();
                        if (vec3d3.y > -0.5)
                            entity.fallDistance = 1;

                        Vec3 vec3d = entity.getLookAngle();
                        float f6 = entity.getXRot() * ((float) Math.PI / 180);
                        double d9 = Math.sqrt(vec3d.x * vec3d.x + vec3d.z * vec3d.z);
                        double d11 = Math.sqrt(horizontalMag(vec3d3));
                        double d12 = vec3d.length();
                        float f3 = Mth.cos(f6);
                        f3 = (float) ((double) f3 * (double) f3 * Math.min(1, d12 / 0.4));
                        vec3d3 = entity.getDeltaMovement().add(0, d0 * (-1 + (double) f3 * 0.75), 0);
                        if (vec3d3.y < 0 && d9 > 0) {
                            double d3 = vec3d3.y * -0.1 * (double) f3;
                            vec3d3 = vec3d3.add(vec3d.x * d3 / d9, d3, vec3d.z * d3 / d9);
                        }
                        if (f6 < 0 && d9 > 0) {
                            double d13 = d11 * (double) (-Mth.sin(f6)) * 0.04;
                            vec3d3 = vec3d3.add(-vec3d.x * d13 / d9, d13 * 3.2, -vec3d.z * d13 / d9);
                        }
                        if (d9 > 0)
                            vec3d3 = vec3d3.add((vec3d.x / d9 * d11 - vec3d3.x) * 0.1, 0.0, (vec3d.z / d9 * d11 - vec3d3.z) * 0.1D);

                        entity.setDeltaMovement(vec3d3.multiply(0.99, 0.98, 0.99));
                        entity.move(MoverType.SELF, entity.getDeltaMovement());
                        if (entity.horizontalCollision && !entity.level.isClientSide) {
                            double d14 = Math.sqrt(horizontalMag(entity.getDeltaMovement()));
                            double d4 = d11 - d14;
                            float f4 = (float) (d4 * 10 - 3);
                            if (f4 > 0)
                                entity.hurt(DamageSource.FLY_INTO_WALL, f4);
                        }
                    } else {
                        BlockPos blockpos = new BlockPos(entity.getX(), entity.getBoundingBox().minY - 0.5000001, entity.getZ());
                        float f7 = entity.isOnGround() ? slipperiness * 0.91F : 0.91F;
                        entity.moveRelative(entity.isOnGround() ? entity.getSpeed() * (0.21600002f / (slipperiness * slipperiness * slipperiness)) : 0.02F, positionIn);
                        entity.move(MoverType.SELF, entity.getDeltaMovement());
                        Vec3 vec3d5 = entity.getDeltaMovement();
                        if ((entity.horizontalCollision || !entity.isOnGround()) && entity.onClimbable())
                            vec3d5 = new Vec3(vec3d5.x, 0.2, vec3d5.z);
                        double d10 = vec3d5.y;
                        if (entity.hasEffect(MobEffects.LEVITATION)) {
                            d10 += (0.05 * (double) (entity.getEffect(MobEffects.LEVITATION).getAmplifier() + 1) - vec3d5.y) * 0.2;
                            entity.fallDistance = 0;
                        } else if (entity.level.isClientSide && !entity.level.hasChunkAt(blockpos)) {
                            if (entity.getY() > 0)
                                d10 = -0.1;
                            else
                                d10 = 0;
                        } else if (!entity.isNoGravity())
                            d10 -= d0;
                        entity.setDeltaMovement(vec3d5.x * (double) f7, d10 * 0.98, vec3d5.z * (double) f7);
                    }
                } else {
                    double d7 = entity.getY();
                    entity.moveRelative(0.02F, positionIn);
                    entity.move(MoverType.SELF, entity.getDeltaMovement());
                    entity.setDeltaMovement(entity.getDeltaMovement().scale(0.5D));
                    if (!entity.isNoGravity())
                        entity.setDeltaMovement(entity.getDeltaMovement().add(0, -d0 / 4, 0));
                    Vec3 vec3d4 = entity.getDeltaMovement();
                    if (entity.horizontalCollision && Util.isOffsetPositionInLiquid(entity, vec3d4.x, vec3d4.y + 0.6 - entity.getY() + d7, vec3d4.z))
                        entity.setDeltaMovement(vec3d4.x, 0.3, vec3d4.z);
                }
            } else {
                double d1 = entity.getY();
                float f1 = 0.02f;
                float f2 = (float) EnchantmentHelper.getDepthStrider(entity);
                entity.move(MoverType.SELF, entity.getDeltaMovement());
                Vec3 vec3d1 = entity.getDeltaMovement();
                if (entity.horizontalCollision && entity.onClimbable()) {
                    vec3d1 = new Vec3(vec3d1.x, 0.2, vec3d1.z);
                }

                entity.setDeltaMovement(vec3d1.multiply(1, 0.8, 1));
                if (!entity.isNoGravity() && !entity.isSprinting()) {
                    Vec3 vec3d2 = entity.getDeltaMovement();
                    double d2;
                    if (flag && Math.abs(vec3d2.y - 0.005) >= 0.003 && Math.abs(vec3d2.y - d0 / 16) < 0.003)
                        d2 = -0.003D;
                    else
                        d2 = vec3d2.y - d0 / 16;
                    entity.setDeltaMovement(vec3d2.x, d2, vec3d2.z);
                }

                Vec3 vec3d6 = entity.getDeltaMovement();
                if (entity.horizontalCollision && Util.isOffsetPositionInLiquid(entity, vec3d6.x, vec3d6.y + 0.6 - entity.getY() + d1, vec3d6.z))
                    entity.setDeltaMovement(vec3d6.x, 0.3, vec3d6.z);
            }
        }

        entity.animationSpeedOld = entity.animationSpeed;
        double d5 = entity.getX() - entity.xo;
        double d6 = entity.getZ() - entity.zo;
        double d8 = entity instanceof FlyingAnimal ? entity.getY() - entity.yo : 0.0D;
        float f8 = Mth.sqrt((float) (d5 * d5 + d8 * d8 + d6 * d6)) * 4.0F;
        if (f8 > 1.0F) {
            f8 = 1.0F;
        }

        entity.animationSpeed += (f8 - entity.animationSpeed) * 0.4F;
        entity.animationPosition += entity.animationSpeed;
    }

    public static void spawnParticle(LivingEntity trackingEntity, int particleId, double posX, double posY, double posZ, double dX, double dY, double dZ, int amount) {
        DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> trackingEntity), new SParticlePacket(particleId, posX, posY, posZ, dX, dY, dZ, amount));
    }

    public static void spawnParticle(Level world, int particleId, double posX, double posY, double posZ, double dX, double dY, double dZ, int amount) {
        DiamondIsUncraftable.INSTANCE.send(PacketDistributor.DIMENSION.with(world::dimension), new SParticlePacket(particleId, posX, posY, posZ, dX, dY, dZ, amount));
    }

    public static void spawnClientParticle(ServerPlayer player, int particleId, double posX, double posY, double posZ, double dX, double dY, double dZ, int amount) {
        DiamondIsUncraftable.INSTANCE.send(PacketDistributor.PLAYER.with(() -> player), new SParticlePacket(particleId, posX, posY, posZ, dX, dY, dZ, amount));
    }

    public static void dealStandDamage(AbstractStandEntity stand, LivingEntity entity, float damage, Vec3 motion, boolean blockable){

        LivingEntity attackedEntity;

        Random random = stand.getRandom();
        boolean blockedFlag = false;

        if (entity instanceof Player) {
            if (entity.isBlocking() && blockable) {
                entity.getHandSlots().forEach(itemStack -> {
                    if (itemStack.getItem().equals(Items.SHIELD)) {
                        itemStack.hurtAndBreak((int) damage * 4, ((Player) entity), (playerEntity) -> {
                            playerEntity.broadcastBreakEvent(InteractionHand.MAIN_HAND); //F**k it I'm just gonna play the animation on both hands
                            playerEntity.broadcastBreakEvent(InteractionHand.OFF_HAND);
                        });
                    }
                });
                blockedFlag = true;
            }
        }
        if (!blockedFlag) {
            entity.invulnerableTime = 0;
            if (entity instanceof AbstractStandEntity) {
                ((AbstractStandEntity) entity).getMaster().invulnerableTime = 0;
            }

            double damageModifier = (float) DiamondIsUncraftableConfig.COMMON.standDamageMultiplier.get().doubleValue();
            double potionModifier = 1.0;

            for(MobEffectInstance effect : stand.getMaster().getActiveEffects()){
                if(effect.getEffect().equals(EffectInit.STAND_STRENGTH.get())){
                    potionModifier += (effect.getAmplifier() + 1) * 0.1;
                }
                if(effect.getEffect().equals(EffectInit.STAND_WEAKNESS.get())){
                    potionModifier -= (effect.getAmplifier() + 1) * 0.1;
                }
            }
            potionModifier = Math.max(potionModifier, 0); //Can't let it go into the negatives
            float modifiedDamage = (float) (damage * damageModifier * potionModifier);
            entity.hurt(DamageSource.mobAttack(stand.getMaster()), modifiedDamage);


            /*
             * Drawn together by fate achievement
             */
            if(!entity.level.isClientSide()) {
                Player killedPlayer = null;
                if (!entity.isAlive()) {
                    if (entity instanceof Player) {
                        killedPlayer = (Player) entity;
                    }
                }
                if (entity instanceof AbstractStandEntity && !((AbstractStandEntity) entity).getMaster().isAlive()){
                    killedPlayer = ((AbstractStandEntity) entity).getMaster();
                }
                if(killedPlayer != null){
                    Stand killedStand = Stand.getCapabilityFromPlayer(killedPlayer);
                    if(killedStand.getStandID() != 0){
                        Util.giveAdvancement((ServerPlayer) stand.getMaster(), "killstanduser");
                    }
                }
            }

            entity.setDeltaMovement(motion);

            stand.setMostRecentlyDamagedEntity(entity);

            Util.spawnParticle(stand, stand.attackParticle(), entity.getX(), entity.getEyeHeight() + entity.getY(), entity.getZ(), 2.4, 1.4, 2.4, 1);
            Util.spawnParticle(stand, 4, entity.getX() + (random.nextFloat() - 0.5), entity.getEyeHeight() + entity.getY() + (random.nextFloat() - 0.5), entity.getZ() + (random.nextFloat() - 0.5), 0.7, 0.9, 0.7, (int) (damage * 8.5));

            Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {
                if (stand instanceof IMomentum) {
                    props.setMomentum(Math.min(100, props.getMomentum() + ((IMomentum) stand).addMomentumAmount()));
                }
            });

            if(stand instanceof IOnHit){
                ((IOnHit) stand).onHit(entity, modifiedDamage);
            }
        }else{
            entity.level.playSound(null, stand.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.NEUTRAL, 0.25F, (random.nextFloat() * 0.3f + 1) * 2);
        }

    }

    public static void dealUnsummonedStandDamage(Player standMaster, LivingEntity entity, float damage, Vec3 motion, boolean blockable){
        LivingEntity attackedEntity;

        Random random = standMaster.getRandom();
        boolean blockedFlag = false;

        if (entity instanceof Player) {
            if (entity.isBlocking() && blockable) {
                entity.getHandSlots().forEach(itemStack -> {
                    if (itemStack.getItem().equals(Items.SHIELD)) {
                        itemStack.hurtAndBreak((int) damage * 4, ((Player) entity), (playerEntity) -> {
                            playerEntity.broadcastBreakEvent(InteractionHand.MAIN_HAND); //F**k it I'm just gonna play the animation on both hands
                            playerEntity.broadcastBreakEvent(InteractionHand.OFF_HAND);
                        });
                    }
                });
                blockedFlag = true;
            }
        }
        if (!blockedFlag) {
            entity.invulnerableTime = 0;
            if (entity instanceof AbstractStandEntity) {
                ((AbstractStandEntity) entity).getMaster().invulnerableTime = 0;
            }

            double damageModifier = (float) DiamondIsUncraftableConfig.COMMON.standDamageMultiplier.get().doubleValue();
            double potionModifier = 1.0;

            for(MobEffectInstance effect : standMaster.getActiveEffects()){
                if(effect.getEffect().equals(EffectInit.STAND_STRENGTH.get())){
                    potionModifier += (effect.getAmplifier() + 1) * 0.1;
                }
                if(effect.getEffect().equals(EffectInit.STAND_WEAKNESS.get())){
                    potionModifier -= (effect.getAmplifier() + 1) * 0.1;
                }
            }
            potionModifier = Math.max(potionModifier, 0); //Can't let it go into the negatives
            float modifiedDamage = (float) (damage * damageModifier * potionModifier);
            entity.hurt(DamageSource.mobAttack(standMaster), modifiedDamage);


            /*
             * Drawn together by fate achievement
             */
            if(!entity.level.isClientSide()) {
                Player killedPlayer = null;
                if (!entity.isAlive()) {
                    if (entity instanceof Player) {
                        killedPlayer = (Player) entity;
                    }
                }
                if (entity instanceof AbstractStandEntity && !((AbstractStandEntity) entity).getMaster().isAlive()){
                    killedPlayer = ((AbstractStandEntity) entity).getMaster();
                }
                if(killedPlayer != null){
                    Stand killedStand = Stand.getCapabilityFromPlayer(killedPlayer);
                    if(killedStand.getStandID() != 0){
                        Util.giveAdvancement((ServerPlayer) standMaster, "killstanduser");
                    }
                }
            }

            entity.setDeltaMovement(motion);

        }else{
            entity.level.playSound(null, standMaster.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.NEUTRAL, 0.25F, (random.nextFloat() * 0.3f + 1) * 2);
        }

    }

    public static void applyUnactionableTicks(Player playerIn, int ticks){
        Stand.getLazyOptional(playerIn).ifPresent(stand -> {
            if(stand.getStandOn()){
                Entity grabbedStand = playerIn.level.getEntity(stand.getPlayerStand());
                if(grabbedStand != null){
                    if(grabbedStand instanceof AbstractStandEntity){
                        ((AbstractStandEntity) grabbedStand).getController().setUnactionableTicks(ticks);
                    }
                }
            }
        });
    }

    @CheckForNull
    public static AbstractStandEntity getStandEntityFromPlayer(Player playerIn){
        Stand stand = Stand.getCapabilityFromPlayer(playerIn);
            if(stand.getStandOn()){
                Entity grabbedStand = playerIn.level.getEntity(stand.getPlayerStand());
                if(grabbedStand instanceof AbstractStandEntity){
                    return (AbstractStandEntity) grabbedStand;
                }
            }
            return null;
    }

    public static class Predicates {
        public static final Predicate<Entity> NOT_STAND = entity -> !(entity instanceof AbstractStandEntity);
        public static final Predicate<Entity> IS_STAND = entity -> entity instanceof AbstractStandEntity;

        public static final Predicate<Entity> STAND_PUNCH_TARGET =
                net.minecraft.world.entity.EntitySelector.NO_SPECTATORS
                        .and(net.minecraft.world.entity.EntitySelector.ENTITY_STILL_ALIVE)
                        .and(Entity::canBeCollidedWith);

        public static final Predicate<Entity> BREATHS = //Pretty much a list of every entity that doesn't breath.
                ((Predicate<Entity>) entity -> !(entity instanceof Zombie))
                        .and(((Predicate<Entity>) entity -> !(entity instanceof Husk))
                                .and(((Predicate<Entity>) entity -> !(entity instanceof Drowned))
                                        .and(((Predicate<Entity>) entity -> !(entity instanceof ZombieHorse))
                                                .and(((Predicate<Entity>) entity -> !(entity instanceof Skeleton))
                                                        .and(((Predicate<Entity>) entity -> !(entity instanceof WitherSkeleton))
                                                                .and(((Predicate<Entity>) entity -> !(entity instanceof SkeletonHorse))
                                                                        .and(((Predicate<Entity>) entity -> !(entity instanceof Giant))
                                                                                .and(((Predicate<Entity>) entity -> !(entity instanceof ZombieVillager))
                                                                                        .and(((Predicate<Entity>) entity -> !(entity instanceof Stray))
                                                                                                .and(entity -> !(entity instanceof ZombifiedPiglin))
                                                                                                .and(entity -> !(entity instanceof Phantom))
                                                                                                .and(entity -> !(entity instanceof AbstractStandAttackEntity))
                                                                                                .and(entity -> !(entity instanceof AbstractStandEntity))
                                                                                                .and(entity -> !(entity instanceof ItemEntity)))))))))));
    }

    public static class StandID {
        public static final int KING_CRIMSON = 1;

        public static final int KILLER_QUEEN = 2;

        public static final int KILLER_QUEEN_BTD = 102;

        public static final int SILVER_CHARIOT = 3;

        public static final int THE_WORLD = 4;

        public static final int STICKY_FINGERS = 5;


        /**
         * An array of Stand's that can be obtained through the {@link StandArrowItem}.
         */
        public static final int[] STANDS = {
                KING_CRIMSON,
                KILLER_QUEEN,
                SILVER_CHARIOT,
                THE_WORLD
        };

        public static final List<Integer> MOMENTUM_METER_STANDS = Arrays.asList( //What stands should render the momentum meter on the HUD
            SILVER_CHARIOT,
            THE_WORLD
        );

        public static final List<Integer> STANDS_WITH_ACTS = Arrays.asList(

        );

        public static final List<Integer> EVOLUTION_STANDS = Arrays.asList(
                KILLER_QUEEN
        );

        /**
         * Returns an {@link AbstractStandEntity} based on the StandID inputted.
         *
         * @param standID The StandID of the Stand, see {@link StandID}.
         * @param world   The {@link Level} the Stand will be summoned in.
         */
        public static AbstractStandEntity getStandByID(int standID, Level world) {
            switch (standID) {
                default:
                    return Null();
                case KING_CRIMSON:
                    return new KingCrimsonEntity(EntityInit.KING_CRIMSON.get(), world);
                case KILLER_QUEEN:
                    return new KillerQueenEntity(EntityInit.KILLER_QUEEN.get(), world);
                case KILLER_QUEEN_BTD:
                    return new KillerQueenBitesTheDustEntity(EntityInit.KILLER_QUEEN_BTD.get(), world);
                case THE_WORLD:
                    return new TheWorldEntity(EntityInit.THE_WORLD.get(), world);
                case SILVER_CHARIOT:
                    return new SilverChariotEntity(EntityInit.SILVER_CHARIOT.get(), world);
                case STICKY_FINGERS:
                    return new StickyFingersEntity(EntityInit.SILVER_CHARIOT.get(), world);
            }
        }

        public static boolean isStandThatEvolves(int id){
            return EVOLUTION_STANDS.contains(id); //Add any maximum tier evolutions here.
        }
    }


    public static class KeyCodes {
        public static final String SUMMON_STAND = KeyInit.SPAWN_STAND.getName().toUpperCase();
        public static final String ABILITY_TOGGLE = KeyInit.TOGGLE_ABILITY.getName().toUpperCase();
        public static final String ABILITY_1 = KeyInit.ABILITY1.getName().toUpperCase();
        public static final String ABILITY_2 = KeyInit.ABILITY2.getName().toUpperCase();
        public static final String ABILITY_3 = KeyInit.ABILITY3.getName().toUpperCase();
        public static final String SWITCH_ACT = KeyInit.SWITCH_ACT.getName().toUpperCase();
    }

    public static class ResourceLocations {
        public static final ResourceLocation KING_CRIMSON = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/king_crimson.png");
        public static final ResourceLocation KING_CRIMSON_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/king_crimson_punch.png");
        public static final ResourceLocation D4C = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/d4c.png");
        public static final ResourceLocation D4C_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/d4c_punch.png");
        public static final ResourceLocation GOLD_EXPERIENCE = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/gold_experience.png");
        public static final ResourceLocation GOLD_EXPERIENCE_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/gold_experience_punch.png");
        public static final ResourceLocation MADE_IN_HEAVEN = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/made_in_heaven.png");
        public static final ResourceLocation MADE_IN_HEAVEN_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/made_in_heaven_punch.png");
        public static final ResourceLocation GER = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/ger.png");
        public static final ResourceLocation GER_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/ger_punch.png");
        public static final ResourceLocation AEROSMITH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/aerosmith.png");
        public static final ResourceLocation AEROSMITH_BULLET = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/aerosmith_bullet.png");
        public static final ResourceLocation WEATHER_REPORT = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/weather_report.png");
        public static final ResourceLocation WEATHER_REPORT_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/weather_report_punch.png");
        public static final ResourceLocation KILLER_QUEEN = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/killer_queen.png");
        public static final ResourceLocation KILLER_QUEEN_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/killer_queen_punch.png");
        public static final ResourceLocation SHEER_HEART_ATTACK = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/sheer_heart_attack.png");
        public static final ResourceLocation CRAZY_DIAMOND = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/crazy_diamond.png");
        public static final ResourceLocation CRAZY_DIAMOND_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/crazy_diamond_punch.png");
        public static final ResourceLocation PURPLE_HAZE = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/purple_haze.png");
        public static final ResourceLocation PURPLE_HAZE_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/purple_haze_punch.png");
        public static final ResourceLocation EMPEROR_BULLET = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/emperor_bullet.png");
        public static final ResourceLocation WHITESNAKE = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/whitesnake.png");
        public static final ResourceLocation WHITESNAKE_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/whitesnake_punch.png");
        public static final ResourceLocation CMOON = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/cmoon.png");
        public static final ResourceLocation CMOON_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/cmoon_punch.png");
        public static final ResourceLocation THE_WORLD = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_world.png");
        public static final ResourceLocation THE_WORLD_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_world_punch.png");
        public static final ResourceLocation STAR_PLATINUM = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/star_platinum.png");
        public static final ResourceLocation STAR_PLATINUM_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/star_platinum_punch.png");
        public static final ResourceLocation SILVER_CHARIOT = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/silver_chariot.png");
        public static final ResourceLocation SILVER_CHARIOT_SWORD = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/silver_chariot_sword.png");
        public static final ResourceLocation MAGICIANS_RED = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/magicians_red.png");
        public static final ResourceLocation MAGICIANS_RED_FLAME = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/magicians_red_flames.png");
        public static final ResourceLocation THE_HAND = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_hand.png");
        public static final ResourceLocation THE_HAND_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_hand_punch.png");
        public static final ResourceLocation HIEROPHANT_GREEN = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/hierophant_green.png");
        public static final ResourceLocation HIEROPHANT_GREEN_TAIL = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/hierophant_green_tail.png");
        public static final ResourceLocation GREEN_DAY = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/green_day.png");
        public static final ResourceLocation GREEN_DAY_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/green_day_punch.png");
        public static final ResourceLocation TWENTIETH_CENTURY_BOY = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/20th_century_boy.png");
        public static final ResourceLocation THE_GRATEFUL_DEAD = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_grateful_dead.png");
        public static final ResourceLocation THE_GRATEFUL_DEAD_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/the_grateful_dead_punch.png");
        public static final ResourceLocation STICKY_FINGERS = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/sticky_fingers.png");
        public static final ResourceLocation STICKY_FINGERS_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/sticky_fingers_punch.png");
        public static final ResourceLocation NAIL_BULLET = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/nail_bullet.png");
        public static final ResourceLocation TUSK_ACT_1 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/tusk_act_1.png");
        public static final ResourceLocation TUSK_ACT_2 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/tusk_act_2.png");
        public static final ResourceLocation TUSK_ACT_3 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/tusk_act_3.png");
        public static final ResourceLocation TUSK_ACT_4 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/tusk_act_4.png");
        public static final ResourceLocation TUSK_ACT_4_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/tusk_act_4_punch.png");
        public static final ResourceLocation ECHOES_ACT_1 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/echoes_act_1.png");
        public static final ResourceLocation ECHOES_SOUND_WAVE = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/echoes_act_1_attack.png");
        public static final ResourceLocation ECHOES_ACT_2 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/echoes_act_2.png");
        public static final ResourceLocation ECHOES_ACT_3 = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/echoes_act_3.png");
        public static final ResourceLocation ECHOES_ACT_3_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/echoes_act_3_punch.png");
        public static final ResourceLocation SOFT_AND_WET = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/soft_and_wet.png");
        public static final ResourceLocation SOFT_AND_WET_PUNCH = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/soft_and_wet_punch.png");
        public static final ResourceLocation BUBBLE = new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/bubble.png");
    }

    /**
     * Give the player an advancement from this mod. Yep, I totally cheated implementing this.
     * @param player The player to give the achievement.
     * @param name The name of the advancement.
     * @return true if the player didn't have the advancement prior to this.
     */
    public static boolean giveAdvancement(ServerPlayer player, String name) {

        Advancement advancement = Objects.requireNonNull(player.getServer()).getAdvancements().getAdvancement(new ResourceLocation(DiamondIsUncraftable.MOD_ID, name));



        if (advancement != null) {
            AdvancementProgress advancementprogress = player.getAdvancements().getOrStartProgress(advancement);
            if (advancementprogress.isDone()) {
                return false;
            } else {
                for (String s : advancementprogress.getRemainingCriteria()) {
                    player.getAdvancements().award(advancement, s);
                }

                return true;
            }
        }
        return false;
    }

    public static void standExplosion(Player master, Level world, Vec3 position, double range, double blockableDistance, double minDamage, double maxDamage) {
        if(!world.isClientSide()) {
            if (master.level != null) {
                Util.spawnParticle(master.level, 5, position.x, position.y, position.z, 1, 1, 1, 1);
                Util.spawnParticle(master.level, 14, position.x, position.y, position.z, 1, 1, 1, 20);
                master.level.playSound(null, new BlockPos(position), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, (1.0F + (world.random.nextFloat() - world.random.nextFloat()) * 0.2F) * 0.7F);


                if(master.getServer() != null && master.getServer().getLevel(master.level.dimension()) != null) {
                    java.util.stream.StreamSupport.stream(Objects.requireNonNull(master.getServer().getLevel(master.level.dimension())).getAllEntities().spliterator(), false)
                            .filter(entity -> entity instanceof LivingEntity)
                            .filter(entity -> !(entity instanceof AbstractStandEntity))
                            .filter(entity -> Math.sqrt((entity.distanceToSqr(position))) <= range)
                            .filter(Entity::isAlive)
                            .forEach(entity -> Util.dealUnsummonedStandDamage(master, (LivingEntity) entity, (float) lerp(minDamage, maxDamage, Math.sqrt((entity.distanceToSqr(position))) / range), Vec3.ZERO, Math.sqrt((entity.distanceToSqr(position))) >= blockableDistance));
                    }
                }
        }
    }

    public static void standExplosionFX(Player master, Level world, Vec3 position) {
        if(!world.isClientSide()) {
            Util.spawnParticle(master.level, 5, position.x, position.y, position.z, 1, 1, 1, 1);
            Util.spawnParticle(master.level, 14, position.x, position.y, position.z, 1, 1, 1, 20);
            master.level.playSound(null, new BlockPos(position), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, (1.0F + (world.random.nextFloat() - world.random.nextFloat()) * 0.2F) * 0.7F);
        }
    }

    private static double lerp(double min, double max, double value)
    {
        return min + value * (max - min);
    }
}


