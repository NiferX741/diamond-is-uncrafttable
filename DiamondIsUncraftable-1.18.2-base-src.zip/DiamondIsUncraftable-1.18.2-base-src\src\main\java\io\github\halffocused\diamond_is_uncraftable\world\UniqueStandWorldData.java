package io.github.halffocused.diamond_is_uncraftable.level;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

public class UniqueStandWorldData extends SavedData {
    public CompoundTag data = new CompoundTag();

    public UniqueStandWorldData() {
    }

    public static UniqueStandWorldData load(CompoundTag nbt) {
        UniqueStandWorldData saved = new UniqueStandWorldData();
        saved.data = nbt.getCompound("TakenStands");
        return saved;
    }

    @Override
    public CompoundTag save(CompoundTag nbt) {
        nbt.put("TakenStands", data);
        return nbt;
    }

    public static UniqueStandWorldData forWorld(ServerLevel world) {
        return world.getDataStorage().computeIfAbsent(UniqueStandWorldData::load, UniqueStandWorldData::new, DiamondIsUncraftable.MOD_ID);
    }
}
