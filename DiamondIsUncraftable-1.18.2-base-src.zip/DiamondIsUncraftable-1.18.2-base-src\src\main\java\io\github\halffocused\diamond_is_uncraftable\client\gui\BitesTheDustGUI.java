package io.github.halffocused.diamond_is_uncraftable.client.gui;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.capability.BitesTheDustCapability;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.BitesTheDustHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;

@SuppressWarnings("unused")
public class BitesTheDustGUI extends GuiComponent {
    public static final Minecraft mc = Minecraft.getInstance();

    protected void renderString(PoseStack stack, String text, int... position) {
        if (position.length < 2)
            drawString(stack, mc.font, text, 4, 4, 0xFFFFFF);
        else if (position.length == 2)
            drawString(stack, mc.font, text, position[0], position[1], 0xFFFFFF);
    }

    public void renderToBuffer(PoseStack stack) {
        assert mc.player != null;
        BitesTheDustCapability.getLazyOptional(mc.player).ifPresent(standEffects -> {
            if(!standEffects.isEmpty()) {
                if (BitesTheDustHelper.bitesTheDustPlayer == null) return;
                renderString(stack, "Bites The Dust - Time Remaining: " + (BitesTheDustCapability.getCapabilityFromEntity(BitesTheDustHelper.bitesTheDustPlayer).getAge() / 20) + " seconds");
            }
        });
    }
}
