package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.SilverChariotSwordEntity;
import io.github.halffocused.diamond_is_uncraftable.init.EffectInit;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncSilverChariotArmorPacket;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.MovementAnimationHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.core.PlayState;
import software.bernie.geckolib3.core.builder.AnimationBuilder;
import software.bernie.geckolib3.core.controller.AnimationController;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;
import software.bernie.geckolib3.core.manager.AnimationData;

@SuppressWarnings({"ConstantConditions", "unused"})
public class SilverChariotEntity extends AbstractStandEntity implements IAnimatable, IMomentum, IOnHit, IOnMasterAttacked {
    private boolean hasArmor = false;

    int swingChargeTicks;
    int prevSwingChargeTicks;
    boolean isBarrageAttack;
    int outgoingChargeAttackTicks;
    boolean isOutgoingAttackBarrage;
    boolean hasMoveHitOnce = false;

    int noSwordTicks = 0;

    int swordChargeTicker = 0;

    boolean initialArmorSet = false;

    final int ARMOR_OFF_FRAME = 40;

    AttackFramedata jabData = new AttackFramedata(22)
            .addDamageFrame(6, 1, Vec3.ZERO, 2.6, 3)
            .addDamageFrame(8, 1, Vec3.ZERO, 2.6, 3)
            .addDamageFrame(10, 1, Vec3.ZERO, 2.6, 3)
            .addDamageFrame(12, 1, Vec3.ZERO, 2.6, 3)
            .addDamageFrame(14, 2, Vec3.ZERO, 2.6, 3);

    AttackFramedata fastJabData = new AttackFramedata(16)
            .addDamageFrame(6, 1, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(7, 1, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(8, 1, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(9, 1, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(10, 2, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(12, 2, Vec3.ZERO, 2.6, 4)
            .addDamageFrame(14, 2, new Vec3(0, 0.45, 0), 2.6, 4);

    AttackFramedata barrageData = new AttackFramedata(47)
            .addDamageFrame(4, 2, Vec3.ZERO, 2.2, 2)
            .addDamageFrame(9, 2, Vec3.ZERO, 2.4, 2)
            .generateInterval(16, 38, 2, 1, Vec3.ZERO, 2.6, 3);

    AttackFramedata spinAttack = new AttackFramedata(20)
            .addRadialDamageFrame(1, 2, new Vec3(0, 0.4, 0), 4)
            .generateRadialInterval(0, 20, 2, 1, Vec3.ZERO, 5);

    AttackFramedata countering = new AttackFramedata(15);

    AttackFramedata counterSlash = new AttackFramedata(60)
            .addRadialDamageFrame(1, 2, new Vec3(0, 0.4, 0), 5)
            .addMenacingFrame(1)
            .addMessageFrame(1, 2, null, null)
            .generateRadialInterval(18, 30, 2, 4, Vec3.ZERO, 5);

    AttackFramedata shedArmor = new AttackFramedata(55)
            .addRadialDamageFrame(ARMOR_OFF_FRAME, 3, Vec3.ZERO, 8, false)
            .addMessageFrame(54, 3, null, null);

    AttackFramedata armorOn = new AttackFramedata(45);

    AttackFramedata aimSword = new AttackFramedata(30)
            .addMessageFrame(1,4, null, null)
            .addMessageFrame(10,4, null, null)
            .addMessageFrame(20,4, null, null)
            .addMessageFrame(30, 0, null, null);

    AttackFramedata fireSword = new AttackFramedata(4)
            .addMessageFrame(3, 1, null, null);

    HoveringMoveHandler controller = new HoveringMoveHandler(this)
            .addMove("Rapid Swings", 1, jabData, "jabs", 2.0)
            .addMove("Light-Speed Swings",2, fastJabData, "offjab", 2.0)
            .addMove("Sword Barrage",3, barrageData, "horahora", 2.0)
            .addMove("Spin Attack",4, spinAttack, "spintowin", -1)
            .addMove("Counter",5, countering, "parry", -1)
            .addMove("Counter-Attack",6, counterSlash, "counter", -3)
            .addMove("Shed Armor",7, shedArmor, "armoroff", -3)
            .addMove("Equip Armor",8, armorOn, "armoron", -3)
            .addMove("Aim Sword",9, aimSword, "aim", -2)
            .addMove("Fire Sword", 10, fireSword, "shoot", -2);



    public SilverChariotEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    public boolean hasArmor() {
        return hasArmor;
    }

    public void ability(){

        if(hasArmor()){
            if(spendEnergy(0)) {
                controller.setMoveActive(9);
            }
        }else{
            Stand.getLazyOptional(master).ifPresent(props -> {
                if (props.getCooldown() <= 0 && master.invulnerableTime == 0 && spendEnergy(40)) {
                    if (controller.isActionable()) {
                        controller.setMoveActive(5);
                    }
                }
            });
        }

    }

    /**
     * Sets whether Silver Chariot has his armor on and passes the information to the client.
     *
     * @param hasArmor Simply says if Silver Chariot should have his armor or not.
     */
    public void setHasArmor(boolean hasArmor) {
        if(!initialArmorSet){
            this.hasArmor = hasArmor;
            if (!level.isClientSide) //Packet is necessary because hasArmor can change after the entity has spawned, after IEntityAdditionalSpawnData#writeSpawnData has already fired.
                DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> this), new SSyncSilverChariotArmorPacket(getId(), hasArmor()));
                initialArmorSet = true;
        }else {

            if (!hasArmor()) {
                if (this.tickCount < 10) {
                    if (!level.isClientSide) //Packet is necessary because hasArmor can change after the entity has spawned, after IEntityAdditionalSpawnData#writeSpawnData has already fired.
                        DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> this), new SSyncSilverChariotArmorPacket(getId(), hasArmor()));
                } else {
                    if (controller.isActionable()) {
                        controller.setMoveActive(8);
                        this.hasArmor = hasArmor;
                        Stand.getLazyOptional(master).ifPresent(props -> {
                            props.setAbility(false);
                        });
                        if (!level.isClientSide) //Packet is necessary because hasArmor can change after the entity has spawned, after IEntityAdditionalSpawnData#writeSpawnData has already fired.
                            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> this), new SSyncSilverChariotArmorPacket(getId(), hasArmor()));
                    }
                }
            } else {
                if (controller.isActionable()) {
                    controller.setMoveActive(7);
                    this.hasArmor = hasArmor;
                    Stand.getLazyOptional(master).ifPresent(props -> {
                        props.setAbility(true);
                    });
                    if (!level.isClientSide) //Packet is necessary because hasArmor can change after the entity has spawned, after IEntityAdditionalSpawnData#writeSpawnData has already fired.
                        DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> this), new SSyncSilverChariotArmorPacket(getId(), hasArmor()));
                }
            }
        }
    }

    public void putHasArmor(boolean hasArmor) {
        this.hasArmor = hasArmor;
    }

    @Override
    public void onRemovedFromWorld() {
        super.onRemovedFromWorld();
        Stand.getLazyOptional(master).ifPresent(props -> props.setAbility(false));
    }

    @Override
    public void tick() {
        super.tick();
        if (getMaster() != null) {
            Stand.getLazyOptional(master).ifPresent(props -> {
                ability = props.getAbility() && props.getMomentum() > 0;
                    if (ability == hasArmor() && controller.isActionable()) {
                        setHasArmor(!ability);
                        props.setAbilityActive(!hasArmor && props.getMomentum() > 0);
                        if (!hasArmor()) {
                            if (props.getTimeLeft() % 20 == 0 && !master.isCreative())
                                master.getFoodData().eat(-1, 0);
                            level.playSound(null, new BlockPos(getX(), getY(), getZ()), SoundEvents.GENERIC_EXPLODE, getSoundSource(), 2.0f, 1.0f);
                        }
                }
                if(!level.isClientSide) {
                    if (!(controller.isMoveActive())) {
                        props.setCounterBuffer(false);
                    }
                    if (!controller.isMoveActive() && hasMoveHitOnce) {
                        hasMoveHitOnce = false;
                    }
                    boolean shouldRemoveStrength = false;
                    for(MobEffectInstance effect : getMaster().getActiveEffects()){
                        if(effect.getEffect().equals(EffectInit.STAND_STRENGTH.get())){
                            if(!spendEnergy((2.5 / 20.0) * (effect.getAmplifier() + 1), true)){
                                shouldRemoveStrength = true;
                            }
                        }
                    }
                    if(shouldRemoveStrength){
                        master.removeEffect(EffectInit.STAND_STRENGTH.get());
                        addEnergy(50);
                    }

                }
                if(controller.isMoveActive()){ //Sound effects while SC is removing it's armor
                    if(controller.getActiveMove().getId() == 7 && controller.getActiveMove().getFramedata().getTicker() < ARMOR_OFF_FRAME){

                        SoundEvent soundEvent;

                        if(this.random.nextInt(4) == 0){
                            switch (this.random.nextInt(3)){
                                case 0: {
                                    soundEvent = SoundInit.ARMOR_OFF_1.get();
                                    break;
                                }
                                case 1: {
                                    soundEvent = SoundInit.ARMOR_OFF_2.get();
                                    break;
                                }
                                default: {
                                    soundEvent = SoundInit.ARMOR_OFF_3.get();
                                    break;
                                }
                            }

                            level.playSound(null, this.getX(), this.getY(), this.getZ(), soundEvent, SoundSource.HOSTILE, 1.0f, 0.6f / (this.random.nextFloat() * 0.3f + 1) * 3.5f);
                        }
                    }

                    if(controller.getActiveMove().getId() == 9 && this.random.nextInt(9) == 0){
                        Util.spawnParticle(this, 9, getX(), getY() + this.getEyeHeight(), getZ(), 1.8, 1.8, 1.8, 1);
                    }
                }

            });
        }
    }


    @Override
    public MovementAnimationHolder getMovementAnimations(){
        if(hasArmor()) {
            if(controller.isActionable()) {
                return new MovementAnimationHolder().create("idle", "forward", "left", "right", "backwards");
            }else{
                return new MovementAnimationHolder().create("noswordidel", "noswordforward", "noswordleft", "noswordright", "noswordback");
                //If you're reading this: Tell joejan to spell his damn animation names properly
            }
        }else{
            return new MovementAnimationHolder().create("offidle", "offorward", "offorward", "offorward", "offorward");
        }
    }


    @Override
    public HoveringMoveHandler getController() {
        return controller;
    }

    @Override
    public int getJabMoveId() {
        return hasArmor() ? 1 : 2;
    }

    @Override
    public int getBarrageMoveId() {
        return hasArmor() ? 3 : 4;
    }

    @Override
    public void registerControllers(AnimationData data) {
        data.addAnimationController(new AnimationController(this, "controller", 2, this::predicate));
    }

    private <E extends IAnimatable> PlayState predicate(AnimationEvent<E> event)
    {
        if (level.isClientSide && currentAnimation != null) {
            event.getController().setAnimation(new AnimationBuilder().addAnimation(currentAnimation, animationLooping));
        }
        return PlayState.CONTINUE;
    }

    @Override
    public void messageFrame(int message1, Object message2, Object message3){
        if(message1 == 0){
            controller.cancelActiveMoves();
            controller.setMoveActive(10);
        }
        if(message1 == 1){

            SilverChariotSwordEntity swordEntity = new SilverChariotSwordEntity(level, this, master);
            swordEntity.setPos(master.getX(), master.getY() + master.getEyeHeight(), master.getZ());
            swordEntity.shoot(getMaster(), master.getXRot(), master.getYRot(), 4f, Float.MIN_VALUE);

            level.addFreshEntity(swordEntity);


            Util.applyUnactionableTicks(master, 120);
        }
        if(message1 == 2){
            Stand.getLazyOptional(master).ifPresent(props -> {
                props.setMomentum(Math.min(100, props.getMomentum() + 20));
            });
        }
        if(message1 == 3){
            addEnergy(100);
        }
    }

    @Override
    public double addMomentumAmount() {
        return hasArmor ? 3 : 0;
    }

    @Override
    public double getMomentumDrainRate() {
        if(controller.isMoveActive() && controller.getActiveMove().getId() == 7){
            return 0;
        }else{
            return hasArmor ? 2.5 : 4;
        }
    }

    @Override
    public void onHit(LivingEntity entity, float damage) {
        if(!level.isClientSide()) {
            if (!hasArmor()) {
                addEnergy(1);
            }

            if(!hasMoveHitOnce){
                MobEffectInstance newEffect = null;
                for(MobEffectInstance effect : getMaster().getActiveEffects()){
                    if(effect.getEffect().equals(EffectInit.STAND_STRENGTH.get())){
                        newEffect = new MobEffectInstance(EffectInit.STAND_STRENGTH.get(), 100, Math.min(effect.getAmplifier() + 1, 6));
                    }
                }
                if(newEffect == null){
                    newEffect = new MobEffectInstance(EffectInit.STAND_STRENGTH.get(), 100, 0);
                }
                master.removeEffect(EffectInit.STAND_STRENGTH.get());
                master.addEffect(newEffect);
                hasMoveHitOnce = true;
            }
        }
    }

    @Override
    public void onMasterAttacked(Entity attacker, float damage) {
        if (controller.isMoveActive()) {
            if (controller.getActiveMove().getId() == 5) {
                controller.cancelActiveMoves();
                controller.setMoveActive(6);
                Stand.getLazyOptional(master).ifPresent(props -> {
                    props.setCounterBuffer(true);
                });
            }
        }
    }

    @Override
    public float getDamageSharingPercentage(){
        return hasArmor() ? 0.35f : 1.25f;
    }

    @Override
    public int attackParticle(){
        return 2;
    }
}
