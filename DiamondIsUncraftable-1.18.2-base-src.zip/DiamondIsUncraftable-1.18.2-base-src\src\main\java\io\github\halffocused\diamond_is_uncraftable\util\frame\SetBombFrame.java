package io.github.halffocused.diamond_is_uncraftable.util.frame;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.KillerQueenEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.Level;

import java.util.List;

public class SetBombFrame extends AbstractFrame{

    private double hitboxRange;

    public SetBombFrame(int tickIn, double hitboxRangeIn) {
        super(tickIn);
        hitboxRange = hitboxRangeIn;
    }

    public double getHitboxRange(){
        return hitboxRange;
    }

    @Override
    public void doThing(AbstractStandEntity standEntity, Move assignedMove) {
        if(standEntity.getServer() == null) {return;}
        Level world = standEntity.getServer().getLevel(standEntity.level.dimension());
        if(world == null || standEntity.getServer().getLevel(standEntity.level.dimension()) == null) {return;}

        AABB hitbox = Util.getAttackHitbox(standEntity, getHitboxRange(), 0.5);

        List<Entity> listOfEntities = world.getEntities(standEntity, hitbox);

        boolean blockedFlag = false;
        
        for(Entity entity : listOfEntities){
            if(entity instanceof LivingEntity && !(entity instanceof AbstractStandEntity) && !(entity instanceof EnderDragon)){
                if(entity != standEntity.getMaster() && standEntity instanceof KillerQueenEntity){ //There should be no way this frame gets called without the stand being Killer Queen, but I would find a way
                    LivingEntity bombTarget = (LivingEntity) entity;
                    if (entity instanceof Player) {
                        if (bombTarget.isBlocking()) {
                            entity.getHandSlots().forEach(itemStack -> {
                                if (itemStack.getItem().equals(Items.SHIELD)) {
                                    itemStack.hurtAndBreak(50, ((Player) entity), (playerEntity) -> {
                                        playerEntity.broadcastBreakEvent(InteractionHand.MAIN_HAND);
                                        playerEntity.broadcastBreakEvent(InteractionHand.OFF_HAND);
                                    });
                                }
                            });
                            blockedFlag = true;
                        }
                    }

                    Util.spawnParticle(standEntity, 14, entity.getX(), entity.getY() + 1, entity.getZ(), 1, 1, 1, 20);

                    ((KillerQueenEntity) standEntity).removeFirstBombFromAll();

                    Stand stand = Stand.getCapabilityFromPlayer(standEntity.getMaster());


                    if(bombTarget.getHealth() / bombTarget.getMaxHealth() <= 0.15 || bombTarget.getHealth() <= 3){
                        ((KillerQueenEntity) standEntity).bombEntity = bombTarget;
                        stand.setBombEntityId(bombTarget.getId());
                        standEntity.getController().setMoveActive(8);
                    }else{
                        ((KillerQueenEntity) standEntity).bombEntity = bombTarget;
                        stand.setBombEntityId(bombTarget.getId());
                    }
                }
            }
        }

    }
}
