package io.github.halffocused.diamond_is_uncraftable.init;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.effect.*;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;


public class EffectInit {
    public static DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, DiamondIsUncraftable.MOD_ID);

    public static final RegistryObject<MobEffect> HAZE = EFFECTS.register("haze",
            () -> new HazeEffect(MobEffectCategory.HARMFUL, 9250166));

    public static final RegistryObject<MobEffect> STAND_WEAKNESS = EFFECTS.register("stand_weakness",
            () -> new StandWeaknessEffect(MobEffectCategory.HARMFUL, 16646144));

    public static final RegistryObject<MobEffect> STAND_STRENGTH = EFFECTS.register("stand_strength",
            () -> new StandStrengthEffect(MobEffectCategory.BENEFICIAL, 5826842));
}
