package io.github.halffocused.diamond_is_uncraftable.entity.stand.attack;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.Level;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class EmeraldSplashEntity extends AbstractStandAttackEntity {
    public EmeraldSplashEntity(EntityType<? extends AbstractStandAttackEntity> type, Level worldIn) {
        super(type, worldIn);
    }

    public EmeraldSplashEntity(Level worldIn, AbstractStandEntity shooter, Player player) {
        super(EntityInit.EMERALD_SPLASH.get(), worldIn, shooter, player);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        entity.hurt(DamageSource.mobAttack(standMaster), 1.5f);
        entity.invulnerableTime = 0;
    }

    @Override
    protected void onBlockHit(BlockHitResult result) {
        BlockPos pos = result.getBlockPos();
        BlockState state = level.getBlockState(pos);
        if (state.getDestroySpeed(level, pos) != -1 && state.getDestroySpeed(level, pos) < 3) {
            level.removeBlock(pos, false);
            if (level.random.nextBoolean())
                state.getBlock().playerDestroy(level, standMaster, pos, state, null, standMaster.getUseItem());
        }
    }

    @Override
    public ResourceLocation getTextureLocation() {
        return Null(); //This renders as an emerald, so this is unused.
    }

    @Override
    protected int getRange() {
        return 3;
    }
}
