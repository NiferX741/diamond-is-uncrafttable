package io.github.halffocused.diamond_is_uncraftable.util.frame;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

import java.util.Random;

public class RadialDamageFrame extends AbstractFrame {

    private float damage;
    private Vec3 motion;
    private double hitboxRange;
    private boolean blockable;

    public RadialDamageFrame(int tickIn, float damageIn, Vec3 motionIn, double hitboxRangeIn, boolean blockableIn) {
        super(tickIn);
        damage = damageIn;
        motion = motionIn;
        hitboxRange = hitboxRangeIn;
        blockable = blockableIn;
    }

    public float getDamage(){
        return damage;
    }

    public Vec3 getDeltaMovement(){
        return motion;
    }

    public double getHitboxRange(){
        return hitboxRange;
    }

    public boolean getBlockable(){
        return blockable;
    }

    @Override
    public void doThing(AbstractStandEntity standEntity, Move assignedMove) {
        if(standEntity.getServer() == null) {return;}
        Level world = standEntity.getServer().getLevel(standEntity.level.dimension());
        if(world == null || standEntity.getServer().getLevel(standEntity.level.dimension()) == null) {return;}

        java.util.stream.StreamSupport.stream(standEntity.getServer().getLevel(standEntity.level.dimension()).getAllEntities().spliterator(), false);


        java.util.stream.StreamSupport.stream(standEntity.getServer().getLevel(standEntity.level.dimension()).getAllEntities().spliterator(), false)
                .filter(entity -> !entity.equals(standEntity))
                .filter(entity -> entity instanceof LivingEntity)
                .filter(entity -> entity.distanceTo(standEntity) < getHitboxRange())
                .filter(standEntity::hasLineOfSight)
                .forEach(entity -> {
                    Util.spawnParticle(standEntity, 2, entity.getX(), entity.getEyeHeight() + entity.getY(), entity.getZ(), 1.2, 1.6, 1.2, 2);

                    int entitiesHit = 0;
                    Random random = ((LivingEntity) entity).getRandom();

                    if(standEntity.getServer() == null) {return;}
                    if(standEntity.getServer().getLevel(standEntity.level.dimension()) == null) {return;}

                    if (!(entity.equals(standEntity.getMaster())) || (entity.equals(standEntity.getMaster()) && assignedMove.getCanDamageMaster())) {
                        Util.dealStandDamage(standEntity, ((LivingEntity) entity), getDamage(), getDeltaMovement(), getBlockable());
                        entitiesHit++;
                    }

                    if (!(entity.equals(standEntity.getMaster())) || (entity.equals(standEntity.getMaster()) && assignedMove.getCanDamageMaster())) {
                        Util.spawnParticle(standEntity, 3, entity.getX(), entity.getEyeHeight() + entity.getY(), entity.getZ(), 2.4, 1.4, 2.4, 1);
                        Util.spawnParticle(standEntity, 4, entity.getX() + (random.nextFloat() - 0.5), entity.getEyeHeight() + entity.getY() + (random.nextFloat() - 0.5), entity.getZ() + (random.nextFloat() - 0.5), 0.7, 0.9, 0.7, (int) (getDamage() * 8.5));
                    }

                    if(entitiesHit > 0){
                        world.playSound(null, standEntity.blockPosition(), Util.getHitSound(standEntity), SoundSource.NEUTRAL, 0.5F, 0.6f / (random.nextFloat() * 0.6f + 1) * 2);
                    }else{
                        world.playSound(null, standEntity.blockPosition(), SoundInit.PUNCH_MISS.get(), SoundSource.NEUTRAL, 0.25F, 0.6f / (random.nextFloat() * 0.3f + 1) * 2);
                        standEntity.setMostRecentlyDamagedEntity(null);
                    }
                });

        Util.spawnParticle(standEntity, 2, standEntity.getX(), standEntity.getEyeHeight() + standEntity.getY(), standEntity.getZ(), getHitboxRange() * 2, 1.5, getHitboxRange() * 2, 2);
    }
}
