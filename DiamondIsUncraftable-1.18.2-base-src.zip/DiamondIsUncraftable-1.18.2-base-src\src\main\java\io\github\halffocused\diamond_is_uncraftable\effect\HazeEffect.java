package io.github.halffocused.diamond_is_uncraftable.effect;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.damagesource.DamageSource;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class HazeEffect extends MobEffect {
    public HazeEffect(MobEffectCategory typeIn, int liquidColorIn) {
        super(typeIn, liquidColorIn);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 10 == 0;
    }

    @Override
    public void applyEffectTick(LivingEntity entityLivingBaseIn, int amplifier) {
            if(!entityLivingBaseIn.level.isClientSide()) {
                entityLivingBaseIn.hurt(DamageSource.WITHER, amplifier);
                entityLivingBaseIn.invulnerableTime = 0;
            }

    }
}
