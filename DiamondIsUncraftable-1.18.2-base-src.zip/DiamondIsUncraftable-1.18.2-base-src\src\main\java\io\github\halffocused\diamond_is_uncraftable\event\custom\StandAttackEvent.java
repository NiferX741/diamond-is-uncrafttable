package io.github.halffocused.diamond_is_uncraftable.event.custom;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.AbstractStandAttackEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.eventbus.api.Cancelable;
import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Fired before the effects of an {@link AbstractStandAttackEntity} take place.
 * This Event is fired from {@link AbstractStandAttackEntity} and it's children.
 * Note that the {@link AbstractStandAttackEntity}'s target is {@link Nullable} and will always be null if isEntity is false.
 * This Event is {@link Cancelable}.
 * If this event is cancelled the effects of the Stand punch will be canceled (block breaking, damaging entities).
 * This Event does not have a result.
 */
@SuppressWarnings("unused")
@Cancelable
public class StandAttackEvent extends Event {
    private final AbstractStandAttackEntity punch;
    private final HitResult rayTraceResult;
    @Nullable
    private final Entity target;
    private final HitResult.Type type;

    public StandAttackEvent(AbstractStandAttackEntity punch, HitResult rayTraceResult, @Nullable Entity target, HitResult.Type type) {
        this.punch = punch;
        this.rayTraceResult = rayTraceResult;
        this.target = target;
        this.type = type;
    }

    public AbstractStandAttackEntity getPunch() {
        return punch;
    }

    public HitResult getRayTraceResult() {
        return rayTraceResult;
    }

    @Nullable
    public Entity getTarget() {
        return target;
    }

    public HitResult.Type getType() {
        return type;
    }

    /**
     * Fired before an {@link AbstractStandAttackEntity} effects a {@link LivingEntity}.
     * This Event is fired from each Stand's punch effect individually in {@link AbstractStandAttackEntity}.
     * This Event is {@link Cancelable}.
     * If this Event is cancelled no damage or effect will be applied to the target, but knockback will still be applied.
     * This Event does not have a result.
     */
    @Cancelable
    public static class EntityHit extends StandAttackEvent {
        public EntityHit(AbstractStandAttackEntity punch, HitResult rayTraceResult, @Nonnull Entity target) {
            super(punch, rayTraceResult, target, HitResult.Type.ENTITY);
        }
    }

    /**
     * Fired before an {@link AbstractStandAttackEntity} effects a {@link net.minecraft.world.level.block.Block}.
     * This Event is fired from each Stand's punch effect individually in {@link AbstractStandAttackEntity}.
     * This Event is {@link Cancelable}.
     * If this Event is cancelled the block will not be destroyed.
     * This Event does not have a result.
     */
    @Cancelable
    public static class BlockHit extends StandAttackEvent {
        public BlockHit(AbstractStandAttackEntity punch, HitResult rayTraceResult, @Nullable Entity target) {
            super(punch, rayTraceResult, target, HitResult.Type.BLOCK);
        }
    }
}
