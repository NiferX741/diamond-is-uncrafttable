package io.github.halffocused.diamond_is_uncraftable.particle;

import net.minecraft.client.particle.*;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ZipperParticle extends TextureSheetParticle {


    protected ZipperParticle(ClientLevel worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
        super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);


        this.setSize(0.08f, 0.08f);
        //this.quadSize *= this.random.nextFloat() * 2.2F;
        //this.xd *= (double)0.02f;
        //this.yd *= (double)0.02f;
        //this.zd *= (double)0.02f;
        this.quadSize *= 1;
        this.xd = 0;
        this.yd = 0;
        this.zd = 0;
        this.lifetime = 10;

    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        if(this.lifetime-- <= 0) {
            this.remove();
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet spriteSet;

        public Factory(SpriteSet sprite) {
            this.spriteSet = sprite;
        }


        @Override
        public Particle createParticle(SimpleParticleType typeIn, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            ZipperParticle menacingParticle = new ZipperParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed);
            menacingParticle.setColor(1.0f, 1.0f, 1.0f);
            menacingParticle.pickSprite(this.spriteSet);
            return menacingParticle;
        }

    }


}