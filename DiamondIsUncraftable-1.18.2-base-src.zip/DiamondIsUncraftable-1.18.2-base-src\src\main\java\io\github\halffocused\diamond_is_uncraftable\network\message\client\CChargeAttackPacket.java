package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CChargeAttackPacket implements IMessage<CChargeAttackPacket> {
    private boolean isAttackKeyDown;
    private boolean isBarraging;

    public CChargeAttackPacket(boolean isAttackKeyDown, boolean isBarraging) {
        this.isAttackKeyDown = isAttackKeyDown;
        this.isBarraging = isBarraging;
    }

    public CChargeAttackPacket() {
    }

    @Override
    public void encode(CChargeAttackPacket message, FriendlyByteBuf buffer) {
        buffer.writeBoolean(message.isAttackKeyDown);
        buffer.writeBoolean(message.isBarraging);
    }

    @Override
    public CChargeAttackPacket decode(FriendlyByteBuf buffer) {
        return new CChargeAttackPacket(buffer.readBoolean(),buffer.readBoolean());
    }

    @Override
    public void handle(CChargeAttackPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ctx.get().getSender();
                if (sender == null) return;
                if (!sender.level.isClientSide)
                    java.util.stream.StreamSupport.stream(sender.getLevel().getAllEntities().spliterator(), false)
                            .filter(entity -> entity instanceof AbstractStandEntity)
                            .filter(entity -> ((AbstractStandEntity) entity).getMaster().equals(sender))
                            .forEach(entity -> ((AbstractStandEntity) entity).chargeAttack(message.isAttackKeyDown, message.isBarraging));
            });
        }
        ctx.get().setPacketHandled(true);
    }
}

