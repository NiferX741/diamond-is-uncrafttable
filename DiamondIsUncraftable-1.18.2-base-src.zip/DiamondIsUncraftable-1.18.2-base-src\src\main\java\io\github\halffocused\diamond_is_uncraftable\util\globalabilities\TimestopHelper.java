package io.github.halffocused.diamond_is_uncraftable.util.globalabilities;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.capability.Timestop;
import io.github.halffocused.diamond_is_uncraftable.capability.WorldTimestopCapability;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.PistonEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.sql.Time;
import java.util.ArrayList;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = DiamondIsUncraftable.MOD_ID)
public class TimestopHelper {

    public static boolean isTimeStopped(Level worldIn, ChunkPos chunkPosIn) {
        WorldTimestopCapability timestoppedChunks = WorldTimestopCapability.getCapabilityFromWorld(worldIn);
        return timestoppedChunks.getTimestoppedChunkPosList().stream().anyMatch(timestoppedChunk -> timestoppedChunk.getChunkPos().equals(chunkPosIn));
    }

    public static boolean isTimeStopped(Level worldIn, BlockPos blockPosIn) {
        return isTimeStopped(worldIn, worldIn.getChunkAt(blockPosIn).getPos());
    }

    public static boolean isTimeStopped(Level worldIn, Player playerIn) {
        Stand stand = Stand.getCapabilityFromPlayer(playerIn);
        return isTimeStopped(worldIn, playerIn.blockPosition()) && !Util.canStandMoveInStoppedTime(stand.getStandID());
    }

    public static boolean isTimeStopped(Level worldIn, AbstractStandEntity standIn) {
        return isTimeStopped(worldIn, standIn.getMaster());
    }

    public static boolean isTimeStopped(Level worldIn, Entity entityIn) {
        if(entityIn instanceof Player) {
            return isTimeStopped(worldIn, (Player) entityIn);
        }else if(entityIn instanceof AbstractStandEntity){
            return isTimeStopped(worldIn, (AbstractStandEntity) entityIn);
        }else {
            return isTimeStopped(worldIn, entityIn.blockPosition());
        }
    }


    /**
     * Called every tick when a player is stopping time. It does, in order:
     * 1) Remove any timestopped chunks by the player if the player is no longer in range of them.
     * 2) Add all chunks within timestop range of the user to the WorldTimestopCapability
     * @param timeStopper The player who is stopping time.
     */
    public static void timeStopTick(Player timeStopper){
        Level world = timeStopper.getCommandSenderWorld();
        UUID uuid = timeStopper.getUUID();
        int timeStopRange = DiamondIsUncraftableConfig.COMMON.timeStopChunkRange.get();
        WorldTimestopCapability timestoppedChunks = WorldTimestopCapability.getCapabilityFromWorld(world);

        ChunkPos masterChunkPos = world.getChunkAt(timeStopper.blockPosition()).getPos();
        int masterChunkX = masterChunkPos.x;
        int masterChunkZ = masterChunkPos.z;

        ArrayList<WorldTimestopCapability.TimestoppedChunk> outOfRangeChunks = new ArrayList<>();
        for(WorldTimestopCapability.TimestoppedChunk timestoppedChunk : timestoppedChunks.getTimestoppedChunkPosList()){
            if(!chunkWithinTimestopRange(masterChunkPos, timestoppedChunk.getChunkPos()) && timeStopper.getUUID().equals(timestoppedChunk.getUUID())){
                outOfRangeChunks.add(timestoppedChunk);
            }
        }
        for(WorldTimestopCapability.TimestoppedChunk removeChunk : outOfRangeChunks){
            timestoppedChunks.removeTimestoppedChunk(removeChunk.getChunkPos(), removeChunk.getUUID());
        }

        for(int i = masterChunkX - timeStopRange; i <= masterChunkX + timeStopRange; i++){
            for(int j = masterChunkZ - timeStopRange; j <= masterChunkZ + timeStopRange; j++){
                if(chunkWithinTimestopRange(masterChunkPos, new ChunkPos(i,j))){

                    WorldTimestopCapability.TimestoppedChunk chunk = new WorldTimestopCapability.TimestoppedChunk(new ChunkPos(i,j), uuid);
                    if(timestoppedChunks.getTimestoppedChunkPosList().stream().noneMatch(timestoppedChunk -> timestoppedChunk.equals(chunk))) {
                        timestoppedChunks.addTimestoppedChunk(chunk.getChunkPos(), chunk.getUUID());
                    }
                }
            }
        }
    }

    /**
     * Remove all timestopped chunks that were stopped by the supplied player.
     * @param timeStopper The player who is no longer stopping time.
     */
    public static void endTimeStop(Player timeStopper) {
        Level world = timeStopper.getCommandSenderWorld();
        WorldTimestopCapability timestoppedChunks = WorldTimestopCapability.getCapabilityFromWorld(world);

        ArrayList<WorldTimestopCapability.TimestoppedChunk> chunksToRemove = new ArrayList<>();
        for (WorldTimestopCapability.TimestoppedChunk timestoppedChunk : timestoppedChunks.getTimestoppedChunkPosList()) {
            if (timestoppedChunk.getUUID().equals(timeStopper.getUUID())) {
                chunksToRemove.add(timestoppedChunk);
            }
        }
        for(WorldTimestopCapability.TimestoppedChunk removeChunk : chunksToRemove){
            timestoppedChunks.removeTimestoppedChunk(removeChunk.getChunkPos(), removeChunk.getUUID());
        }

    }

    public static boolean chunkWithinTimestopRange(ChunkPos timestopPos, ChunkPos testPos) {
        int timeStopRange = DiamondIsUncraftableConfig.COMMON.timeStopChunkRange.get();
        return Math.abs(timestopPos.x - testPos.x) < timeStopRange && Math.abs(timestopPos.z - testPos.z) < timeStopRange;
    }

    @SubscribeEvent
    public static void fluidEvent(BlockEvent.FluidPlaceBlockEvent event) {
        LevelAccessor world = event.getWorld();

        if(world instanceof Level) {
            if (isTimeStopped((Level) world, event.getPos())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void blockPlaceEvent(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() == null) {
            event.setCanceled(true);
        } else {
            LevelAccessor world = event.getWorld();

            if(world instanceof Level) {
                if (isTimeStopped((Level) world, event.getPos())) {
                    event.setCanceled(true);
                }
            }
        }
    }

    @SubscribeEvent
    public static void blockBreakEvent(BlockEvent.BreakEvent event) {
        LevelAccessor world = event.getWorld();

        if(world instanceof Level) {
            if (isTimeStopped((Level) world, event.getPos())) {
                event.setCanceled(true);
            }
        }
    }


    @SubscribeEvent
    public static void pistonEvent(PistonEvent.Pre event) {
        LevelAccessor world = event.getWorld();

        if(world instanceof Level) {
            if (isTimeStopped((Level) world, event.getPos())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void playerInteract1(PlayerInteractEvent.EntityInteractSpecific event) {
        Level world = event.getWorld();
        Player player = event.getPlayer();

        if(world != null) {
            if (isTimeStopped(world, player)) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void playerInteract2(PlayerInteractEvent.EntityInteract event) {
        Level world = event.getWorld();
        Player player = event.getPlayer();

        if(world != null) {
            if (isTimeStopped(world, player)) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void playerInteract3(PlayerInteractEvent.RightClickBlock event) {
        Level world = event.getWorld();
        Player player = event.getPlayer();

        if(world != null) {
            if (isTimeStopped(world, player)) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void playerInteract4(PlayerInteractEvent.RightClickItem event) {
        Level world = event.getWorld();
        Player player = event.getPlayer();

        if(world != null) {
            if (isTimeStopped(world, player)) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void playerInteract5(PlayerInteractEvent.LeftClickBlock event) {
        Level world = event.getWorld();
        Player player = event.getPlayer();

        if(world != null) {
            if (isTimeStopped(world, player)) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void enderTeleport(EntityTeleportEvent.EnderEntity event) {
        Level world = event.getEntity().getCommandSenderWorld();

        if (isTimeStopped(world, event.getEntityLiving().blockPosition())) {
            event.setCanceled(true);
        }
    }


    @SubscribeEvent
    public static void worldTick(TickEvent.WorldTickEvent event) {
        if (event.world.isClientSide) {
            return;
        }
        ServerLevel world = (ServerLevel) event.world;

        if (!world.isClientSide) {
            java.util.stream.StreamSupport.stream(world.getAllEntities().spliterator(), false)
                    .filter(entity -> !(entity instanceof AbstractStandEntity))
                    .forEach(entity -> {

                        if(entity instanceof Player){
                            Stand.getLazyOptional(((Player) entity)).ifPresent(stand -> stand.setExperiencingTimeStop(isTimeStopped(world, entity.blockPosition())));
                        }

                        if (isTimeStopped(world, entity)) {
                            Timestop.getLazyOptional(entity).ifPresent(timestop -> {
                                if (timestop.isEmpty()) {
                                    timestop.setPos(entity.getX(), entity.getY(), entity.getZ());
                                    timestop.setDeltaMovement(entity.getDeltaMovement().x, entity.getDeltaMovement().y, entity.getDeltaMovement().z);
                                    timestop.setRot(entity.getYRot(), entity.getXRot(), entity.getYHeadRot());
                                    timestop.setFallDistance(entity.fallDistance);
                                    timestop.setFire(entity.getRemainingFireTicks());
                                    if (entity instanceof PrimedTnt)
                                        timestop.setFuse(((PrimedTnt) entity).getFuse());
                                    if (entity instanceof MinecartTNT)
                                        timestop.setFuse(Util.getIntField((MinecartTNT) entity, "fuse"));
                                    if (entity instanceof ItemEntity)
                                        timestop.setAge(Util.getIntField((ItemEntity) entity, "age"));
                                }

                                timestoppedEntityTick(entity);

                            });
                        } else {
                            Timestop.getLazyOptional(entity).ifPresent(timestop -> {
                                if (!timestop.isEmpty()) {
                                    if ((entity instanceof AbstractArrow || entity instanceof ItemEntity || entity instanceof AbstractHurtingProjectile) && (timestop.getMotionX() != 0 && timestop.getMotionY() != 0 && timestop.getMotionZ() != 0)) {
                                        entity.setDeltaMovement(timestop.getMotionX(), timestop.getMotionY(), timestop.getMotionZ());
                                        entity.setNoGravity(false);
                                    } else if (timestop.getMotionX() != 0 && timestop.getMotionY() != 0 && timestop.getMotionZ() != 0) {
                                        entity.setDeltaMovement(timestop.getMotionX(), timestop.getMotionY(), timestop.getMotionZ());
                                    }
                                    entity.hasImpulse = true;

                                    if (entity instanceof Mob) {
                                        ((Mob) entity).setNoAi(false);
                                    }
                                    if (timestop.getFallDistance() != 0) {
                                        entity.fallDistance = timestop.getFallDistance();
                                    }
                                    if(entity instanceof Player){
                                        ((Player) entity).removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                                    }

                                    if (timestop.getDamage().size() > 0)
                                        timestop.getDamage().forEach((source, amount) -> {
                                            DamageSource damageSource = DamageSource.GENERIC;
                                            String newSource = source.replaceAll("[0123456789]", "");
                                            switch (newSource) {
                                                case "inFire": {
                                                    damageSource = DamageSource.IN_FIRE;
                                                    break;
                                                }
                                                case "onFire": {
                                                    damageSource = DamageSource.ON_FIRE;
                                                    break;
                                                }
                                                case "lightningBolt": {
                                                    damageSource = DamageSource.LIGHTNING_BOLT;
                                                    break;
                                                }
                                                case "lava": {
                                                    damageSource = DamageSource.LAVA;
                                                    break;
                                                }
                                                case "hotFloor": {
                                                    damageSource = DamageSource.HOT_FLOOR;
                                                    break;
                                                }
                                                case "inWall": {
                                                    damageSource = DamageSource.IN_WALL;
                                                    break;
                                                }
                                                case "cramming": {
                                                    damageSource = DamageSource.CRAMMING;
                                                    break;
                                                }
                                                case "drown": {
                                                    damageSource = DamageSource.DROWN;
                                                    break;
                                                }
                                                case "starve": {
                                                    damageSource = DamageSource.STARVE;
                                                    break;
                                                }
                                                case "cactus": {
                                                    damageSource = DamageSource.CACTUS;
                                                    break;
                                                }
                                                case "fall": {
                                                    damageSource = DamageSource.FALL;
                                                    break;
                                                }
                                                case "flyIntoWall": {
                                                    damageSource = DamageSource.FLY_INTO_WALL;
                                                    break;
                                                }
                                                case "outOfWorld": {
                                                    damageSource = DamageSource.OUT_OF_WORLD;
                                                    break;
                                                }
                                                case "magic": {
                                                    damageSource = DamageSource.MAGIC;
                                                    break;
                                                }
                                                case "wither": {
                                                    damageSource = DamageSource.WITHER;
                                                    break;
                                                }
                                                case "anvil": {
                                                    damageSource = DamageSource.ANVIL;
                                                    break;
                                                }
                                                case "fallingBlock": {
                                                    damageSource = DamageSource.FALLING_BLOCK;
                                                    break;
                                                }
                                                case "dragonBreath": {
                                                    damageSource = DamageSource.DRAGON_BREATH;
                                                    break;
                                                }
                                                case "dryout": {
                                                    damageSource = DamageSource.DRY_OUT;
                                                    break;
                                                }
                                                case "sweetBerryBush": {
                                                    damageSource = DamageSource.SWEET_BERRY_BUSH;
                                                    break;
                                                }
                                            }
                                            entity.hurt(damageSource, amount * 0.5f);
                                            entity.invulnerableTime = 0;
                                        });
                                    timestop.clear();
                                }
                            });
                        }
                    });
        }
    }

    @SubscribeEvent
    public static void cancelDamage(LivingAttackEvent event) {
        LivingEntity entity = event.getEntityLiving();

        if(entity instanceof Player) {
            Player playerEntity = (Player) entity;

            if(isTimeStopped(playerEntity.level, playerEntity.blockPosition())){
                if(isTimeStopped(playerEntity.level, playerEntity)){ //If time is stopped, and the player is not moving in stopped time.
                    Timestop.getLazyOptional(playerEntity).ifPresent(props -> {
                        if (!props.getDamage().containsKey(event.getSource().getMsgId()))
                            props.getDamage().put(event.getSource().getMsgId(), event.getAmount());
                        else
                            for (int i = 0; i < 1000; i++) {
                                if (!props.getDamage().containsKey(event.getSource().getMsgId() + i)) {
                                    props.getDamage().put(event.getSource().getMsgId() + i, event.getAmount());
                                    break;
                                }
                            }
                    });
                    event.setCanceled(true);
                }else{ //If time is stopped, but the player is moving in stopped time.
                    Entity trueSource = event.getSource().getEntity();
                    if(trueSource == null){ //No environmental damage during timestop
                        event.setCanceled(true);
                    }else{
                        event.setCanceled(isTimeStopped(trueSource.getCommandSenderWorld(), trueSource));
                    }
                }
            }

        }else if (!(entity instanceof AbstractStandEntity)){
            if (isTimeStopped(entity.getCommandSenderWorld(), entity)) {
                Timestop.getLazyOptional(entity).ifPresent(props -> {
                    if (!props.getDamage().containsKey(event.getSource().getMsgId()))
                        props.getDamage().put(event.getSource().getMsgId(), event.getAmount());
                    else
                        for (int i = 0; i < 1000; i++) {
                            if (!props.getDamage().containsKey(event.getSource().getMsgId() + i)) {
                                props.getDamage().put(event.getSource().getMsgId() + i, event.getAmount());
                                break;
                            }
                        }
                });
                event.setCanceled(true);
            }
        }
    }

    public static void timestoppedEntityTick(Entity entity){
        Timestop timestop = Timestop.getCapabilityFromEntity(entity);

        if(!timestop.isEmpty()) {
            entity.teleportTo(timestop.getX(), timestop.getY(), timestop.getZ());

            if ((entity instanceof AbstractArrow) || (entity instanceof ItemEntity) || (entity instanceof AbstractHurtingProjectile))
                entity.setNoGravity(true);
            else {
                entity.setYRot(timestop.getRotationYaw());
                entity.setXRot(timestop.getRotationPitch());
                entity.setYHeadRot(timestop.getYHeadRot());
            }

            if (entity instanceof Mob) {
                ((Mob) entity).setNoAi(true);
            }
            entity.setDeltaMovement(0, 0, 0);
            entity.fallDistance = timestop.getFallDistance();
            entity.setSecondsOnFire(timestop.getFire());

            if (entity instanceof PrimedTnt)
                ((PrimedTnt) entity).setFuse(timestop.getFuse());
            if (entity instanceof MinecartTNT)
                Util.setIntField((MinecartTNT) entity, "fuse", timestop.getFuse());
            if (entity instanceof ItemEntity)
                Util.setIntField((ItemEntity) entity, "age", timestop.getAge());

            if (entity instanceof Player) {
                Stand.getLazyOptional(((Player) entity)).ifPresent(stand -> {
                    Util.applyUnactionableTicks(((Player) entity), 1);
                });
                ((Player) entity).addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 255, false, false));
            }
            entity.hasImpulse = true;
        }
    }

}
