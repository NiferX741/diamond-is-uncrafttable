package io.github.halffocused.diamond_is_uncraftable.entity.stand;


import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.BitesTheDustHelper;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

@SuppressWarnings("ConstantConditions")
public class KillerQueenBitesTheDustEntity extends KillerQueenEntity{

    public KillerQueenBitesTheDustEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public void tick(){
        super.tick();
    }

    public void detonate() {
        if (getMaster() == null || level.isClientSide()) return;
        if(getMaster().isShiftKeyDown()){
            if(!(BitesTheDustHelper.bitesTheDustActive) && spendEnergy(100)){
                BitesTheDustHelper.startBitesTheDust(this);
                Stand.getCapabilityFromPlayer(master).setStandOn(false);
            }
        }else {
            if (spendEnergy(65)) {
                controller.setMoveActive(5);
            }
        }
    }
}

