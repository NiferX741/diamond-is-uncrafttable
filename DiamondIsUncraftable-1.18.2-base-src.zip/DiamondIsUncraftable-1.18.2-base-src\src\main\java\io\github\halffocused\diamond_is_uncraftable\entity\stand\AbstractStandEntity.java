package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import com.google.common.util.concurrent.AtomicDouble;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.capability.StandEffects;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.AbstractStandAttackEntity;
import io.github.halffocused.diamond_is_uncraftable.event.custom.StandEvent;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandMasterPacket;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.MovementAnimationHolder;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.players.OldUsersConverter;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PacketDistributor;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.core.PlayState;
import software.bernie.geckolib3.core.builder.AnimationBuilder;
import software.bernie.geckolib3.core.controller.AnimationController;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;
import software.bernie.geckolib3.core.manager.AnimationData;
import software.bernie.geckolib3.core.manager.AnimationFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings({"unused", "ConstantConditions"})
public abstract class AbstractStandEntity extends Mob implements IEntityAdditionalSpawnData, IAnimatable {
    private static final EntityDataAccessor<Optional<UUID>> MASTER_UNIQUE_ID = SynchedEntityData.defineId(AbstractStandEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    public boolean ability, attackRush;
    public int attackTick, attackTicker;
    protected Player master;

    EntityType<AbstractStandEntity> entityType;

    boolean attacking = false;
    boolean hasAttackTarget = false;
    int ticksSinceLastPunch;
    public int masterKeybindInput;

    private LivingEntity mostRecentlyDamagedEntity = null;

    public HoveringMoveHandler controller;

    private final AnimationFactory factory = new AnimationFactory(this);


    public String currentAnimation;
    public boolean animationLooping;

    boolean lastIsCharging = false;
    boolean lastIsCrouching = false;

    public AbstractStandEntity(EntityType<? extends Mob> type, Level worldIn) {
        super(type, worldIn);
    }

    public static AttributeSupplier.Builder setCustomAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20.0D);
    }

    /**
     * @return Returns the Stand's spawn sound.
     */
    public SoundEvent getSpawnSound(){
        return SoundInit.SUMMON_STAND.get();
    }

    /**
     * @return The Stand's current {@link AbstractStandEntity#master}, also makes sure it isn't <code>null</code>.
     */
    public Player getMaster() { //Don't listen to your IDE, this can be null during a relog.
        return master == null ? master = level.getPlayerByUUID(getMasterUUID()) : master;
    }

    /**
     * Sets the Stand's master, should never be <code>null</code> as it would most likely <b>crash</b> the game.
     *
     * @param master The {@link Player} that will be set as the Stand's {@link AbstractStandEntity#master}.
     */
    public void setMaster(@Nonnull Player master) {
        this.master = master;
    }

    /**
     * @return The {@link UUID} of the Stand's master from it's {@link SynchedEntityData}.
     */
    public UUID getMasterUUID() {
        return entityData.get(MASTER_UNIQUE_ID).orElse(null);
    }

    /**
     * Sets the Stand's master's {@link UUID} to the {@link SynchedEntityData}.
     *
     * @param masterUUID The {@link UUID} that will be set as the Stand's {@link AbstractStandEntity#MASTER_UNIQUE_ID}
     */
    public void setMasterUUID(@Nullable UUID masterUUID) {
        entityData.set(MASTER_UNIQUE_ID, Optional.ofNullable(masterUUID));
    }

    /**
     * Plays the Stand's {@link AbstractStandEntity#getSpawnSound()}.
     */
    public void playSpawnSound() {
        level.playSound(null, master.blockPosition(), getSpawnSound(), SoundSource.NEUTRAL, 1, 1);
    }

    /**
     * Makes the Stand follow it's {@link AbstractStandEntity#master}
     */
    public void followMaster() {
        if (this.master == null) return;

            double standSpacing = -1.5;
            Vec3 position = Util.rotationVectorIgnoreY(master).multiply(standSpacing, standSpacing, -1.75).add(master.position());
            position = position.multiply(1, 0, 1);
            setPos(position.x, master.getY() + 0.45, position.z);

    }

    /**
     * Makes the Stand dodge oncoming attacks, such as TNT, arrows and falling blocks.
     */
    private void dodgeAttacks() {
        if (level.isClientSide) return;
        java.util.stream.StreamSupport.stream(level.getServer().getLevel(level.dimension()).getAllEntities().spliterator(), false)
                .filter(entity -> entity instanceof PrimedTnt || entity instanceof Arrow || entity instanceof FallingBlockEntity || entity instanceof ThrowableItemProjectile)
                .filter(entity -> entity.distanceTo(master) <= Math.PI * 8)
                .forEach(entity -> {
                    double distanceX = getX() - entity.getX();
                    double distanceY = getY() - entity.getY();
                    double distanceZ = getZ() - entity.getZ();
                    if (distanceX > 0)
                        zza -= 0.3;
                    else if (distanceX < 0)
                        zza += 0.3;
                    if (distanceY > 0)
                        yya -= 0.3;
                    else if (distanceY < 0)
                        yya += 0.3;
                    if (distanceZ > 0)
                        xxa -= 0.3;
                    else if (distanceZ < 0)
                        xxa += 0.3;
                });
    }

    /**
     * Called every tick to update the entity's position/logic and remove it if conditions are met.
     */
    @Override
    public void tick() {
        super.tick(); //Queues the tick method to run, code in tick() method won't run if removed.
        fallDistance = 0; //Mutes that god forsaken fall sound, not even overriding the playFallSound method helps without this.
        if (!level.isClientSide && getMaster() != null) { //Calls getMaster to set the master to a @Nonnull value.

            stopRiding();

            if (!master.isAlive()) {
                MinecraftForge.EVENT_BUS.post(new StandEvent.MasterDeathEvent(master, this));
                discard();
            }
            if (master.isSpectator()) discard();
            MinecraftForge.EVENT_BUS.post(new StandEvent.StandTickEvent(master, this)); //Fired after all death checks are passed to avoid confusion.

            Stand.getLazyOptional(master).ifPresent(props -> {
                if (!props.getStandOn()) {
                    MinecraftForge.EVENT_BUS.post(new StandEvent.StandUnsummonedEvent(master, this));
                    discard();
                }
            });
            StandEffects.getLazyOptional(this).ifPresent(props -> {
                if (props.isThreeFreeze()) {
                    master.setDeltaMovement(0, getDeltaMovement().y, 0);
                    master.hasImpulse = true;
                }
            });
            if(getController() != null) { //Literally never happens other than in development when making abilities before attacks.
                getController().tick(lastIsCharging, lastIsCrouching);
            }
        }
    }

    /**
     * Redirects attacks from the Stand to it's master.
     *
     * @param damageSource The {@link DamageSource} damaging the Stand.
     * @param damage       The amount of damage taken.
     * @return Always returns <code>false</code> to prevent the Stand from taking damage, and because I'm paranoid.
     */
    @Override
    public boolean hurt(DamageSource damageSource, float damage) {
        if (master == null || damageSource.getEntity() == master || damageSource == DamageSource.CACTUS || damageSource == DamageSource.FALL || Util.isTimeStoppedForEntity(master))
            return false; //Prevents Stands from taking damage they shouldn't, fall damage, cactus damage, etc.

        Stand.getLazyOptional(master).ifPresent(stand -> {
            if(!stand.getExperiencingTimeStop() && !stand.getExperiencingTimeSkip()) {
                master.hurt(damageSource, damage * getDamageSharingPercentage());
            }
        });

        return false;
    }

    /**
     * Makes Stand's phase through non Stand entities.
     *
     * @param entityIn The {@link Entity} being collided with.
     */
    @Override
    public void push(Entity entityIn) {
        if (entityIn instanceof AbstractStandEntity || entityIn instanceof AbstractStandAttackEntity)
            super.push(entityIn);
    }

    /**
     * Posts the {@link StandEvent.StandSummonedEvent} and sends a {@link SSyncStandMasterPacket} because I'm paranoid.
     */
    @Override
    public void onAddedToWorld() {
        super.onAddedToWorld();
        if (MinecraftForge.EVENT_BUS.post(new StandEvent.StandSummonedEvent(master, this)))
            discard(); //Removes the Stand if the Stand summon event is cancelled.
        if (!level.isClientSide && master != null) {
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> this), new SSyncStandMasterPacket(getId(), master.getId()));
            Stand.getLazyOptional(master).ifPresent(props -> props.setPlayerStand(getId())); //Sets the Stand's Entity#getEntityID to the player's capability.
        }
    }

    /**
     * Fires the {@link StandEvent.StandRemovedEvent}, will cause major issues if super isn't called.
     */
    @Override
    public void onRemovedFromWorld() {
        super.onRemovedFromWorld();
        MinecraftForge.EVENT_BUS.post(new StandEvent.StandRemovedEvent(master, this));
        if (master != null)
            Stand.getLazyOptional(master).ifPresent(props -> props.setPlayerStand(0)); //Resets the Stand#getPlayerStand for easier null checks.
        master.displayClientMessage(new TextComponent(""), true); //Clear the action bar.
    }

    /**
     * Prevents the Stand from despawning due to being far from players.
     *
     * @param distanceToClosestPlayer The Stand's distance to the nearest player.
     * @return Whether or not the Stand should despawn.
     */
    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    /**
     * Makes the Stand not render flames when it's on fire as it looks stupid.
     *
     * @return Whether the entity should render as on fire.
     */
    @Override
    public boolean displayFireAnimation() {
        return false;
    }

    @Override
    public boolean isNoAi() {
        return false;
    }

    @Override
    public boolean isInWall() {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    protected void doPush(Entity entity) {
        if (entity instanceof AbstractStandEntity || entity instanceof AbstractStandAttackEntity)
            push(entity);
    }

    /**
     * Mutes the annoying fall sound.
     */
    @Override
    protected void playBlockFallSound() {
    }

    /**
     * Mute the splash sounds created by the rapid teleportation of the stands  :)
     */

    @Override
    public boolean isInWater() {
        return false;
    }
    @Override
    protected void doWaterSplashEffect() {
    }
    @Override
    protected void playSwimSound(float volume) {
    }


    /**
     * Writes data from the server to a {@link FriendlyByteBuf}.
     *
     * @param buffer The {@link FriendlyByteBuf} to write to.
     */
    @Override
    public void writeSpawnData(FriendlyByteBuf buffer) {
        buffer.writeInt(getMaster() == null ? -1 : master.getId());
    }

    /**
     * Reads the data written to the {@link FriendlyByteBuf} by the server from the client, syncing that data to the client.
     *
     * @param additionalData The {@link FriendlyByteBuf} to read from.
     */
    @Override
    public void readSpawnData(FriendlyByteBuf additionalData) {
        Entity entity = level.getEntity(additionalData.readInt());
        if (entity instanceof Player)
            setMaster((Player) entity);
    }

    /**
     * Registers the Stand's master's UUID to the {@link SynchedEntityData}.
     */
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(MASTER_UNIQUE_ID, Optional.<java.util.UUID>empty());
    }

    /**
     * Writes the Stand's master's UUID to the {@link CompoundTag} for future use.
     */
    @Override
    public void addAdditionalSaveData(CompoundTag compoundNBT) {
        super.addAdditionalSaveData(compoundNBT);
        if (getMasterUUID() != null)
            compoundNBT.putUUID("MasterUUID", getMasterUUID());
    }

    /**
     * Sets the Stand's master to the one written to the {@link CompoundTag}.
     */
    @Override
    public void readAdditionalSaveData(CompoundTag compoundNBT) {
        super.readAdditionalSaveData(compoundNBT);
        UUID id;
        if (compoundNBT.contains("MasterUUID"))
            id = compoundNBT.getUUID("MasterUUID");
        else
            id = compoundNBT.getUUID("MasterUUID");

        if (id != null)
            setMasterUUID(id);
    }

    /**
     * Very important for custom entities, if not implemented the game can crash with a {@link NullPointerException} and/or the entity won't render.
     */
    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    public void setMasterKeybindInput(int masterKeybindInputIn) {
        this.masterKeybindInput = masterKeybindInputIn;
    }

    @Override
    public void registerControllers(AnimationData data) {
        data.addAnimationController(new AnimationController(this, "controller", 2, this::predicate));
    }

    private <E extends IAnimatable> PlayState predicate(AnimationEvent<E> event)
    {
        if (level.isClientSide && currentAnimation != null) {
            event.getController().setAnimation(new AnimationBuilder().addAnimation(currentAnimation, animationLooping));
        }
        return PlayState.CONTINUE;
    }
    @Override
    public AnimationFactory getFactory() {
        return this.factory;
    }

    public void setAnimation(String animationNameIn, boolean animationLoopingIn){
        this.currentAnimation = animationNameIn;
        this.animationLooping = animationLoopingIn;
    }

    /**
     * @return The move that should be used when the stand's owner left-clicks without sneaking.
     */
    public int getJabMoveId(){
        return 1;
    }
    /**
     * @return The move that should be used when the stand's owner left-clicks while sneaking.
     */
    public int getBarrageMoveId(){
        return 2;
    }


    public void goToAttackPosition(double distanceIn){

        Vec3 position = master.getLookAngle().multiply(distanceIn, distanceIn, distanceIn).add(master.position());
        for (double i = position.y - 0.5; level.getBlockState(new BlockPos(position.x, i, position.z)).getMaterial().isSolid(); i++)
            position = position.add(0, 0.5, 0);
        teleportTo(position.x, position.y + 0.75, position.z);

        Stand.getLazyOptional(master).ifPresent(props -> {
            props.setPreventUnsummon(true);
        });
        hasAttackTarget = true;
    }

    /**
     * I could very easily have just written 5 methods and avoided the holder class.
     * This isn't hard-coded because there are stands that change their movement animations based on certain conditions.
     * @return A MovementAnimationHolder().
     */
    public MovementAnimationHolder getMovementAnimations(){
        return new MovementAnimationHolder().create("idle", "forward", "left", "right", "backwards");
    }

    public HoveringMoveHandler getController(){
        return null;
    }

    /**
     * This method can be called on frames of stand moves, useful to create custom frames for niche cases.
     *
     * @param message1 The integer sent with the frame, generally used to differentiate the content of the next two parameters.
     */

    public void messageFrame(int message1, Object message2, Object message3){

    }

    /**
     * Some stands need to keep track of whatever entity they attacked last. This is called on every attack hitbox.
     * When multiple entities are hit, whatever entity is handled last (essentially random) is chosen.
     * @param entityIn The LivingEntity attacked last.
     */
    public void setMostRecentlyDamagedEntity(@Nullable LivingEntity entityIn){
        mostRecentlyDamagedEntity = entityIn;
    }

    public LivingEntity getMostRecentlyDamagedEntity(){
        if(mostRecentlyDamagedEntity != null) {
            if (!mostRecentlyDamagedEntity.isAlive()) {
                mostRecentlyDamagedEntity = null;
            }
        }
        return mostRecentlyDamagedEntity;
    }

    public boolean spendEnergy(double amount){

        return spendEnergy(amount, false);
    }

    /**
     * Attempt to spend energy.
     * @param amount The amount of energy being spent.
     * @param ignoreActionability Should this energy be spendable even if the stand is not currently actionable?
     * @return If the user has enough, spend it and return true. Otherwise, don't spend it and return false.
     */
    public boolean spendEnergy(double amount, boolean ignoreActionability){ //Channeled energy spending shouldn't require the stand to be actionable.

        AtomicBoolean state = new AtomicBoolean(false);

        if(!level.isClientSide) {
            Stand.getLazyOptional(getMaster()).ifPresent(stand -> {

                if (stand.getCurrentStandEnergy() >= amount && ((getController().isActionable()) || ignoreActionability)) {
                    stand.setCurrentStandEnergy(stand.getCurrentStandEnergy() - amount);
                    stand.setEnergyCooldown(40);
                    state.set(true);
                } else {
                    state.set(false);
                }
            });
        }
        return state.get();
    }

    /**
     * Remove energy from a stand user. If they don't have enough, just hit 0.
     * @param amount How much energy to remove
     */
    public void penalizeEnergy(double amount){
        if(!level.isClientSide) {
            Stand.getLazyOptional(getMaster()).ifPresent(stand -> {
                stand.setCurrentStandEnergy(Math.max(0, stand.getCurrentStandEnergy() - amount));
                stand.setEnergyCooldown(20);
            });
        }
    }

    /**
     * Called every tick to update the stands controller (Stand.getController)
     * @param isCharging Is the player inputting left click.
     * @param isBarrage Is the player sneaking.
     */
    public void chargeAttack(boolean isCharging, boolean isBarrage) {
        if (getMaster() == null) return;

        lastIsCharging = isCharging;
        lastIsCrouching = isBarrage;
    }

    /**
     * Add stand energy, up to the maximum amount.
     * @param amount The amount of energy to add.
     */
    public void addEnergy(double amount){
        if(!level.isClientSide()) {
            Stand.getLazyOptional(getMaster()).ifPresent(stand -> {
                stand.setCurrentStandEnergy(Math.min(stand.getMaxStandEnergy(), stand.getCurrentStandEnergy() + amount));
            });
        }
    }

    /**
     * Check if the stand user has a certain amount of energy.
     * @param amount The amount of energy being checked.
     * @return True if the stand user's energy is greater than or equal to @param amount.
     */
    public boolean energyAtThreshold(double amount){

        AtomicBoolean state = new AtomicBoolean(false);

        Stand.getLazyOptional(getMaster()).ifPresent(stand -> {
            state.set(stand.getCurrentStandEnergy() >= amount);
        });
        return state.get();
    }

    /**
     * Get the percentage of a stand user's remaining energy.
     * @return Returns a double value between 0 and 1.
     */
    public double getEnergyPercentage(){
        AtomicDouble doublePercentage = new AtomicDouble(-1);

        Stand.getLazyOptional(getMaster()).ifPresent(stand -> {
            doublePercentage.set(stand.getCurrentStandEnergy() / stand.getMaxStandEnergy());
        });
        return doublePercentage.get();
    }

    /**
     * @return the modifier applied to damage received by the stand before dealt to the stand's master.
     */
    public float getDamageSharingPercentage(){
        return 0.5f;
    }

    public int attackParticle(){
        return 3;
    }
}
