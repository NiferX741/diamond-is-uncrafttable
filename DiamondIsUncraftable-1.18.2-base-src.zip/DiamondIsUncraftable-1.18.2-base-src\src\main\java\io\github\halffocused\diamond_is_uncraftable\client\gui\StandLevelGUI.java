package io.github.halffocused.diamond_is_uncraftable.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;

public class StandLevelGUI extends GuiComponent
{
    public static final Minecraft mc = Minecraft.getInstance();

    private int width;
    private int height;

    public StandLevelGUI()
    {
        width = mc.getWindow().getGuiScaledWidth();
        height = mc.getWindow().getGuiScaledHeight();
    }

    public void renderLevelScreen(){
        drawCenteredString(null, mc.font, "Stand Leveling: ", 10 + mc.font.width("Stand Leveling: ") / 2, height - 2 * (mc.font.lineHeight + 4), Integer.parseInt("FFAA00", 16));
        drawCenteredString(null, mc.font, "Current Points: ", 10 + mc.font.width("Current Points: ") / 2, height - (mc.font.lineHeight + 4), Integer.parseInt("FFAA00", 16));

    }
}
