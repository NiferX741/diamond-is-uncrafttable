package io.github.halffocused.diamond_is_uncraftable.util.globalabilities;

import io.github.halffocused.diamond_is_uncraftable.capability.*;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.KillerQueenBitesTheDustEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BitesTheDustHelper {
    public static final int BITES_THE_DUST_DURATION = 24000;
    public static boolean bitesTheDustActive = false;
    public static int bitesTheDustTicks = -1;
    public static long activatedDayTime = -1;
    public static ServerLevel bitesTheDustWorld = null;
    public static Player bitesTheDustPlayer = null;
    public static Player previousBitesTheDustPlayer = null;
    public static ArrayList<LivingEntity> killedEntities = new ArrayList<>();
    public static ArrayList<ItemEntity> pickedUpItems = new ArrayList<>();
    public static ArrayList<FatedDeath> fatedDeaths = new ArrayList<>();


    public static void startBitesTheDust(KillerQueenBitesTheDustEntity standEntity){
        bitesTheDustPlayer = standEntity.getMaster();
        bitesTheDustTicks = BITES_THE_DUST_DURATION;
        bitesTheDustActive = true;
        bitesTheDustWorld = (ServerLevel) standEntity.level;
        activatedDayTime = bitesTheDustWorld.getDayTime();


        /*
         * Save the current position, health, age, and movement of all entities.
         * Players also have their inventories and Ender Chests saved.
         */

        java.util.stream.StreamSupport.stream(bitesTheDustWorld.getAllEntities().spliterator(), false)
                .filter(entity -> !(entity instanceof AbstractStandEntity))
                .forEach(entity -> BitesTheDustCapability.getLazyOptional(entity).ifPresent(bitesTheDustCapability -> {
                    if(bitesTheDustCapability.isEmpty()){
                        bitesTheDustCapability.setPos(entity.getX(), entity.getY(), entity.getZ());
                        bitesTheDustCapability.setDeltaMovement(entity.getDeltaMovement().x, entity.getDeltaMovement().y, entity.getDeltaMovement().z);
                        bitesTheDustCapability.setRot(entity.getYRot(), entity.getXRot(), entity.getYHeadRot());
                        bitesTheDustCapability.setFallDistance(entity.fallDistance);
                        bitesTheDustCapability.setFire(entity.getRemainingFireTicks());
                        if(entity instanceof LivingEntity) {
                            bitesTheDustCapability.setHealth(((LivingEntity) entity).getHealth());
                            if(entity instanceof Player){
                                bitesTheDustCapability.setIsMaster(entity.equals(bitesTheDustPlayer));
                                bitesTheDustCapability.setHunger(((Player) entity).getFoodData().getFoodLevel());
                            }
                        }
                        if (entity instanceof PrimedTnt)
                            bitesTheDustCapability.setFuse(((PrimedTnt) entity).getFuse());
                        if (entity instanceof MinecartTNT)
                            bitesTheDustCapability.setFuse(Util.getIntField((MinecartTNT) entity, "fuse"));
                        if (entity instanceof ItemEntity)
                            bitesTheDustCapability.setAge(Util.getIntField((ItemEntity) entity, "age"));
                    }

                    if (entity instanceof Player)
                        StandPlayerEffects.getLazyOptional((Player) entity).ifPresent(standPlayerEffects -> {
                            for (int i = 0; i < ((Player) entity).getInventory().items.size(); i++) {
                                ItemStack stack = ((Player) entity).getInventory().items.get(i);
                                if (!stack.isEmpty())
                                    standPlayerEffects.getMainInventory().set(i, stack.copy());
                            }
                            for (int i = 0; i < ((Player) entity).getInventory().armor.size(); i++) {
                                ItemStack stack = ((Player) entity).getInventory().armor.get(i);
                                if (!stack.isEmpty())
                                    standPlayerEffects.getArmorInventory().set(i, stack.copy());
                            }
                            for (int i = 0; i < ((Player) entity).getInventory().offhand.size(); i++) {
                                ItemStack stack = ((Player) entity).getInventory().offhand.get(i);
                                if (!stack.isEmpty())
                                    standPlayerEffects.getOffHandInventory().set(i, stack.copy());
                            }
                            for (int i = 0; i < ((Player) entity).getEnderChestInventory().getContainerSize(); i++) {
                                ItemStack stack = ((Player) entity).getEnderChestInventory().getItem(i);
                                if (!stack.isEmpty())
                                    standPlayerEffects.getEnderChestInventory().set(i, stack.copy());
                            }
                        });
                }));

        /*
         * Save the contents of all loaded LockableTileEntities.
         */

        Util.loadedBlockEntities(bitesTheDustWorld).forEach(tileEntity -> StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
                    if (tileEntity instanceof BaseContainerBlockEntity)
                        for (int i = 0; i < ((BaseContainerBlockEntity) tileEntity).getContainerSize(); i++) {
                            ItemStack stack = ((BaseContainerBlockEntity) tileEntity).getItem(i);
                            if (!stack.isEmpty())
                                standTileEntityEffects.getChestInventory().set(i, stack.copy());
                        }
                }));
    }

    public static void rewindBitesTheDust(){
        bitesTheDustTicks = -1;
        bitesTheDustActive = false;
        bitesTheDustWorld.setDayTime(activatedDayTime);

        for(LivingEntity entity : killedEntities){
            entity.setHealth(entity.getMaxHealth());
            Vec3 position = null;
            for(FatedDeath fatedDeath : fatedDeaths){
                if(fatedDeath.entity.equals(entity)){
                    position = fatedDeath.position;
                }
            }
            if(position != null){
                entity.teleportTo(position.x, position.y, position.z);
            }
            Util.revive(entity);
            bitesTheDustWorld.addFreshEntity(entity);
        }

        for(ItemEntity itemEntity : pickedUpItems){
            Util.revive(itemEntity);
            bitesTheDustWorld.addFreshEntity(itemEntity);
        }
        pickedUpItems.clear();



        killedEntities.clear();

        java.util.stream.StreamSupport.stream(bitesTheDustWorld.getAllEntities().spliterator(), false)
                .filter(entity -> !(entity instanceof AbstractStandEntity))
                .forEach(entity -> BitesTheDustCapability.getLazyOptional(entity).ifPresent(bitesTheDustCapability -> {

                    if(bitesTheDustCapability.isEmpty() && !(entity instanceof Player)){ //remove all non-player entities that weren't there when BTD started.
                        entity.discard();
                    }else {
                        entity.teleportTo(bitesTheDustCapability.getX(), bitesTheDustCapability.getY(), bitesTheDustCapability.getZ());

                        entity.setYRot(bitesTheDustCapability.getRotationYaw());
                        entity.setXRot(bitesTheDustCapability.getRotationPitch());
                        entity.setYHeadRot(bitesTheDustCapability.getYHeadRot());

                        entity.setDeltaMovement(0, 0, 0);
                        entity.fallDistance = bitesTheDustCapability.getFallDistance();
                        entity.setSecondsOnFire(bitesTheDustCapability.getFire());

                        if(bitesTheDustCapability.getFateTicks() != 0){
                            StandEffects.getCapabilityFromEntity(entity).setRemainingTicks(bitesTheDustCapability.getFateTicks());
                        }

                        StandEffects.getLazyOptional(entity).ifPresent(standEffects -> {
                            if (!standEffects.getAlteredTileEntities().isEmpty())
                                standEffects.getAlteredTileEntities().forEach((pos, blockPosList) ->
                                        blockPosList.forEach(blockPos -> {
                                            if (bitesTheDustWorld.getChunkSource().hasChunk(pos.x, pos.z))
                                                bitesTheDustWorld.getChunkSource().updateChunkForced(pos, true);
                                            BlockEntity tileEntity = bitesTheDustWorld.getBlockEntity(blockPos);
                                            if (!(tileEntity instanceof BaseContainerBlockEntity)) return;
                                            StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
                                                ((BaseContainerBlockEntity) tileEntity).clearContent();
                                                for (int i = 0; i < standTileEntityEffects.getChestInventory().size(); i++) {
                                                    ItemStack stack = standTileEntityEffects.getChestInventory().get(i);
                                                    ((BaseContainerBlockEntity) tileEntity).setItem(i, stack);
                                                    standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                                                }
                                                tileEntity.setChanged();
                                            });
                                        }));
                            if (!standEffects.getDestroyedBlocks().isEmpty()) {
                                Map<BlockPos, BlockState> removalMap = new ConcurrentHashMap<>();
                                standEffects.getDestroyedBlocks().forEach((pos, list) -> {
                                    list.forEach((blockPos, blockState) -> {
                                        if (bitesTheDustWorld.getChunkSource().hasChunk(pos.x, pos.z))
                                            bitesTheDustWorld.getChunkSource().updateChunkForced(pos, true);
                                        bitesTheDustWorld.setBlock(blockPos, blockState, 3);
                                        removalMap.put(blockPos, blockState);
                                    });
                                    if (!removalMap.isEmpty())
                                        removalMap.forEach(list::remove);
                                });
                            }
                            if (standEffects.getBitesTheDustPos() != BlockPos.ZERO) {
                                entity.teleportTo(standEffects.getBitesTheDustPos().getX(), standEffects.getBitesTheDustPos().getY(), standEffects.getBitesTheDustPos().getZ());
                                standEffects.setBitesTheDustPos(BlockPos.ZERO);
                            }
                        });

                        if (entity instanceof LivingEntity) {
                            ((LivingEntity) entity).setHealth(bitesTheDustCapability.getHealth());

                            if (entity instanceof Player) {
                                Stand.getLazyOptional(((Player) entity)).ifPresent(stand -> {
                                    stand.setBitesTheDustEffectTicker(45);
                                });
                                ((Player) entity).getFoodData().setFoodLevel(bitesTheDustCapability.getHunger());
                                StandPlayerEffects.getLazyOptional((Player) entity).ifPresent(standPlayerEffects -> {
                                    ((Player) entity).getInventory().clearContent();
                                    for (int i = 0; i < standPlayerEffects.getMainInventory().size(); i++) {
                                        ItemStack stack = standPlayerEffects.getMainInventory().get(i);
                                        ((Player) entity).getInventory().setItem(i, stack);
                                        standPlayerEffects.getMainInventory().set(i, ItemStack.EMPTY);
                                    }
                                    for (int i = 0; i < standPlayerEffects.getArmorInventory().size(); i++) {
                                        ItemStack stack = standPlayerEffects.getArmorInventory().get(i);
                                        ((Player) entity).getInventory().setItem(i + 36, stack);
                                        standPlayerEffects.getArmorInventory().set(i, ItemStack.EMPTY);
                                    }
                                    for (int i = 0; i < standPlayerEffects.getOffHandInventory().size(); i++) {
                                        ItemStack stack = standPlayerEffects.getOffHandInventory().get(i);
                                        ((Player) entity).getInventory().setItem(i + 40, stack);
                                        standPlayerEffects.getOffHandInventory().set(i, ItemStack.EMPTY);
                                    }
                                    for (int i = 0; i < standPlayerEffects.getEnderChestInventory().size(); i++) {
                                        ItemStack stack = standPlayerEffects.getEnderChestInventory().get(i);
                                        ((Player) entity).getEnderChestInventory().setItem(i, stack);
                                        standPlayerEffects.getEnderChestInventory().set(i, ItemStack.EMPTY);
                                    }
                                });
                            }
                        }
                        if (entity instanceof PrimedTnt)
                            ((PrimedTnt) entity).setFuse(bitesTheDustCapability.getFuse());
                        if (entity instanceof MinecartTNT)
                            Util.setIntField((MinecartTNT) entity, "fuse", bitesTheDustCapability.getFuse());
                        if (entity instanceof ItemEntity)
                            Util.setIntField((ItemEntity) entity, "age", bitesTheDustCapability.getAge());
                        entity.hasImpulse = true;

                        bitesTheDustCapability.clear();
                    }
                }));

        Util.loadedBlockEntities(bitesTheDustWorld).forEach(tileEntity -> StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
            if (tileEntity instanceof BaseContainerBlockEntity)
                for (int i = 0; i < ((BaseContainerBlockEntity) tileEntity).getContainerSize(); i++) {
                    ItemStack stack = standTileEntityEffects.getChestInventory().get(i);
                    ((BaseContainerBlockEntity) tileEntity).setItem(i, stack);
                    standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                }
                tileEntity.setChanged();
        }));

        previousBitesTheDustPlayer = bitesTheDustPlayer;
        bitesTheDustPlayer = null;

    }

    public static void cancelBitesTheDust(){

        pickedUpItems.clear();
        killedEntities.clear();
        activatedDayTime = -1;
        bitesTheDustTicks = -1;
        bitesTheDustActive = false;

        java.util.stream.StreamSupport.stream(bitesTheDustWorld.getAllEntities().spliterator(), false)
                .filter(entity -> !(entity instanceof AbstractStandEntity))
                .forEach(entity -> BitesTheDustCapability.getLazyOptional(entity).ifPresent(bitesTheDustCapability -> {

                    StandEffects.getLazyOptional(entity).ifPresent(standEffects -> {
                        if (!standEffects.getAlteredTileEntities().isEmpty())
                            standEffects.getAlteredTileEntities().forEach((pos, blockPosList) ->
                                    blockPosList.forEach(blockPos -> {
                                        if (bitesTheDustWorld.getChunkSource().hasChunk(pos.x, pos.z))
                                            bitesTheDustWorld.getChunkSource().updateChunkForced(pos, true);
                                        BlockEntity tileEntity = bitesTheDustWorld.getBlockEntity(blockPos);
                                        if (!(tileEntity instanceof BaseContainerBlockEntity)) return;
                                        StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
                                            ((BaseContainerBlockEntity) tileEntity).clearContent();
                                            for (int i = 0; i < standTileEntityEffects.getChestInventory().size(); i++) {
                                                standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                                            }
                                        });
                                    }));
                        if (!standEffects.getDestroyedBlocks().isEmpty()) {
                            Map<BlockPos, BlockState> removalMap = new ConcurrentHashMap<>();
                            standEffects.getDestroyedBlocks().forEach((pos, list) -> {
                                list.forEach((blockPos, blockState) -> {
                                    if (bitesTheDustWorld.getChunkSource().hasChunk(pos.x, pos.z))
                                        bitesTheDustWorld.getChunkSource().updateChunkForced(pos, true);
                                    removalMap.put(blockPos, blockState);
                                });
                                if (!removalMap.isEmpty())
                                    removalMap.forEach(list::remove);
                            });
                        }
                        if (standEffects.getBitesTheDustPos() != BlockPos.ZERO) {
                            standEffects.setBitesTheDustPos(BlockPos.ZERO);
                        }
                    });

                    bitesTheDustCapability.clear();
                }));

        Util.loadedBlockEntities(bitesTheDustWorld).forEach(tileEntity -> StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
            if (tileEntity instanceof BaseContainerBlockEntity)
                for (int i = 0; i < standTileEntityEffects.getChestInventory().size(); i++) {
                    standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                }
        }));

        previousBitesTheDustPlayer = bitesTheDustPlayer;
        bitesTheDustPlayer = null;

    }

    @SubscribeEvent
    public static void worldTick(TickEvent.WorldTickEvent event) {
        if (event.world.isClientSide) {
            return;
        }
        ServerLevel world = (ServerLevel) event.world;
        if(event.phase == TickEvent.Phase.END && world.dimension() == Level.OVERWORLD) {
            if (!world.isClientSide && bitesTheDustActive && bitesTheDustPlayer != null) {
                bitesTheDustTicks--;
                BitesTheDustCapability.getLazyOptional(bitesTheDustPlayer).ifPresent(bitesTheDustCapability -> {
                    bitesTheDustCapability.setAge(bitesTheDustTicks);
                });
                if(bitesTheDustTicks <= 0){
                    rewindBitesTheDust();
                }
            }
            if(!world.isClientSide() && !bitesTheDustActive){
                Iterator<FatedDeath> iterator = fatedDeaths.iterator();
                while (iterator.hasNext()){
                    FatedDeath fatedDeath = iterator.next();
                    fatedDeath.ticksRemaining--;
                    if(fatedDeath.ticksRemaining <= 0){
                        LivingEntity entity = fatedDeath.entity;
                        if (entity instanceof Mob) {
                            Explosion explosion = new Explosion(entity.level, previousBitesTheDustPlayer, entity.getX(), entity.getY(), entity.getZ(), 4, true, Explosion.BlockInteraction.NONE);
                            ((Mob) entity).level.addParticle(net.minecraft.core.particles.ParticleTypes.EXPLOSION, entity.getX(), entity.getY(), entity.getZ(), 0, 0, 0);
                            explosion.finalizeExplosion(true);
                            entity.level.playSound(null, entity.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1, 1);
                            entity.discard();
                        } else if (entity instanceof Player) {
                            Stand.getLazyOptional((Player) entity).ifPresent(bombProps -> {
                                Explosion explosion = new Explosion(entity.level, null, entity.getX(), entity.getY(), entity.getZ(), 4, true, Explosion.BlockInteraction.NONE);
                                ((Player) entity).sweepAttack();
                                explosion.finalizeExplosion(true);
                                entity.hurt(DamageSource.explosion(explosion), Float.MAX_VALUE);
                            });
                        }
                        iterator.remove();
                    }
                }
            }
        }
    }

     private static class FatedDeath{
        LivingEntity entity;
        int ticksRemaining;
        Vec3 position;
        public FatedDeath(LivingEntity entityIn, int ticksRemainingIn, Vec3 positionIn){
            entity = entityIn;
            ticksRemaining = ticksRemainingIn;
            position = positionIn;
        }
     }

     public static void addFatedDeath(LivingEntity entity, Vec3 position){
        fatedDeaths.add(new FatedDeath(entity, (BITES_THE_DUST_DURATION - bitesTheDustTicks), position));
     }

     @SubscribeEvent
     public static void itemPickup(PlayerEvent.ItemPickupEvent event){
        if(bitesTheDustActive){
            pickedUpItems.add(event.getOriginalEntity());
            Util.revive(event.getOriginalEntity());
        }
     }
}
