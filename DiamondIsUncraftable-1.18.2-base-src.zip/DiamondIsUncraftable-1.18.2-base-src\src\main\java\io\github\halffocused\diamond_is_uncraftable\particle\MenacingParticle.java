package io.github.halffocused.diamond_is_uncraftable.particle;

import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;

@OnlyIn(Dist.CLIENT)
public class MenacingParticle extends TextureSheetParticle {


    protected MenacingParticle(Level worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
        super((ClientLevel) worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);


        this.setSize(0.04f, 0.04f);
        this.quadSize *= this.random.nextFloat() * 2.2F;
        //this.xd *= (double)0.02f;
        //this.yd *= (double)0.02f;
        //this.zd *= (double)0.02f;
        this.xd = 0;
        this.yd = 0.04d;
        this.zd = 0;
        this.lifetime = (int)((30.0D * Math.random()) + 10);

    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        if(this.lifetime-- <= 0) {
            this.remove();
        } else {
            this.move(this.xd, this.yd, this.zd);
            if(!(this.random.nextInt(2)==1)) {
                this.xd *= 1.0D;
                this.yd *= 1.0D;
                this.zd *= 1.0D;
            }else{//random vibrations of the menacing particles
                this.yd *= 1.0D;
                if(this.random.nextBoolean()) {
                    if (this.random.nextBoolean()) {
                        this.x += this.random.nextFloat() / 10;
                    } else {
                        this.x += this.random.nextFloat() / -10;
                    }
                }
                if(this.random.nextBoolean()) {
                    if (this.random.nextBoolean()) {
                        this.z += this.random.nextFloat() / 10;
                    } else {
                        this.z += this.random.nextFloat() / -10;
                    }
                }
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet spriteSet;

        public Factory(SpriteSet sprite) {
            this.spriteSet = sprite;
        }


        @Override
        public Particle createParticle(SimpleParticleType typeIn, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            MenacingParticle menacingParticle = new MenacingParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed);
            menacingParticle.setColor(1.0f, 1.0f, 1.0f);
            menacingParticle.pickSprite(this.spriteSet);
            return menacingParticle;
        }
    }


}