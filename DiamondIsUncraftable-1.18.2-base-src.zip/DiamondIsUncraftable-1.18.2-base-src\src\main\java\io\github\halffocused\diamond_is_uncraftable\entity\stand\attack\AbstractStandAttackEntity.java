package io.github.halffocused.diamond_is_uncraftable.entity.stand.attack;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.event.custom.StandAttackEvent;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;

/**
 * This class is a mess, I can barely read it, especially the {@link #tick()} method.
 */
@SuppressWarnings("ALL")
public abstract class AbstractStandAttackEntity extends AbstractHurtingProjectile implements IEntityAdditionalSpawnData {
    public double xTile, yTile, zTile, arrowShake, ticksInAir;
    public AbstractStandEntity shootingStand;
    public Player standMaster;
    protected boolean inGround;

    public AbstractStandAttackEntity(EntityType<? extends AbstractHurtingProjectile> type, Level worldIn) {
        super(type, worldIn);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        setNoGravity(true);
    }

    public AbstractStandAttackEntity(EntityType<? extends AbstractHurtingProjectile> type, Level worldIn, double x, double y, double z) {
        this(type, worldIn);
        setPos(x, y, z);
    }

    public AbstractStandAttackEntity(EntityType<? extends AbstractHurtingProjectile> type, Level worldIn, AbstractStandEntity shooter, Player player) {
        this(type, worldIn, shooter.getX(), shooter.getY() + 0.5, shooter.getZ());
        shootingStand = shooter;
        standMaster = player;
        movePunchInFrontOfStand(shooter);
    }

    protected abstract void onHitEntity(EntityHitResult result);

    protected abstract void onBlockHit(BlockHitResult result);

    public abstract ResourceLocation getTextureLocation();

    /**
     * Defines the range of a Stand attack, {@link Override} to change, default is 1.
     */
    protected int getRange() {
        return 1;
    }

    protected boolean shouldMatchMaster() {
        return true;
    }

    protected boolean shouldBeDestroyedByBlocks(BlockState state) {
        return true;
    }

    private BlockPos getBlockPosFromNBT() {
        return new BlockPos(xTile, yTile, zTile);
    }

    public void shoot(Entity shooter, float pitch, float yaw, float velocity, float inaccuracy) {
        float x = -Mth.sin(yaw * ((float) Math.PI / 180)) * Mth.cos(pitch * ((float) Math.PI / 180));
        float y = -Mth.sin(pitch * ((float) Math.PI / 180));
        float z = Mth.cos(yaw * ((float) Math.PI / 180)) * Mth.cos(pitch * ((float) Math.PI / 180));
        shoot(x, y, z, velocity, inaccuracy);
        setDeltaMovement(getDeltaMovement().add(shooter.getDeltaMovement().x, shooter.isOnGround() ? 0 : shooter.getDeltaMovement().y, shooter.getDeltaMovement().z));
    }

    @Override
    public void shoot(double x, double y, double z, float velocity, float inaccuracy) {
        Vec3 vec3d = (new Vec3(x, y, z)).normalize().add(this.random.nextGaussian() * (double) 0.0075 * (double) inaccuracy, this.random.nextGaussian() * (double) 0.0075 * (double) inaccuracy, this.random.nextGaussian() * (double) 0.0075 * (double) inaccuracy).scale(velocity);
        setDeltaMovement(vec3d);
        float f = Mth.sqrt((float) Util.horizontalMag(vec3d));
        setYRot((float) (Mth.atan2(vec3d.x, vec3d.z) * (double) (180 / (float) Math.PI)));
        setXRot((float) (Mth.atan2(vec3d.y, f) * (double) (180 / (float) Math.PI)));
        yRotO = getYRot();
        xRotO = getXRot();
    }

    public void randomizePositions() {
        if (shootingStand == null) return;
        Vec3 random = new Vec3(this.random.nextDouble() * 2 - 1, this.random.nextDouble() * 2 - 1, this.random.nextDouble() * 2 - 1);
        Vec3 position = position().add(random).add(standMaster.getLookAngle().multiply(1.5, 0.2, 1.5));
        setPos(position.x, position.y, position.z);
        setRot(getYRot(), getXRot());
    }

    public void movePunchInFrontOfStand(AbstractStandEntity stand) {
        if (stand.getMaster() == null) return;
        Vec3 position = position().add(stand.getMaster().getLookAngle().multiply(0.5, 0.1, 0.5));
        setPos(position.x, position.y, position.z);
    }

    public void setVelocity(double x, double y, double z) {
        setDeltaMovement(x, y, z);
        if (xRotO == 0 && yRotO == 0) {
            setXRot((float) (Mth.atan2(y, (double) Mth.sqrt((float) (x * x + z * z))) * (double) (180 / (float) Math.PI)));
            setYRot((float) (Mth.atan2(x, z) * (double) (180 / (float) Math.PI)));
            xRotO = getXRot();
            yRotO = getYRot();
            moveTo(getX(), getY(), getZ(), getYRot(), getXRot());
            inGround = false;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (standMaster != null && shouldMatchMaster())
            setRot(standMaster.getYRot(), standMaster.getXRot());
        if (shootingStand == null && !level.isClientSide)
            discard();
        BlockPos blockPos = new BlockPos(xTile, yTile, zTile);
        BlockState blockState = level.getBlockState(blockPos);
        if (blockState.getMaterial() != Material.AIR && !blockState.getCollisionShape(level, blockPos).isEmpty())
            if (blockState.getCollisionShape(level, blockPos).bounds().move(blockPos).contains(position()))
                inGround = true;
        if (arrowShake > 0)
            arrowShake--;

        if (!inGround) {
            ticksInAir++;
            if (ticksInAir > getRange() && !level.isClientSide)
                discard();
            BlockHitResult raytraceresult = level.clip(new ClipContext(position(), position().add(getDeltaMovement()), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, this));
            EntityHitResult entityRayTraceResult = null;
            EntityHitResult result = getEntityHitResult(position(), position().add(getDeltaMovement()));
            if (result != null) {
                entityRayTraceResult = result;
                if (raytraceresult != null && entityRayTraceResult.getEntity() instanceof AbstractStandAttackEntity) {
                    AbstractStandAttackEntity punch = (AbstractStandAttackEntity) entityRayTraceResult.getEntity();
                    if (punch.shootingStand == shootingStand)
                        raytraceresult = null;
                }
                if (raytraceresult != null && entityRayTraceResult.getEntity() instanceof Player) {
                    Player playerEntity = (Player) entityRayTraceResult.getEntity();
                    if (playerEntity.equals(standMaster))
                        raytraceresult = null;
                    else
                        entityRayTraceResult = new EntityHitResult(playerEntity);
                }
                if (entityRayTraceResult != null && entityRayTraceResult.getEntity() instanceof AbstractStandEntity)
                    if (entityRayTraceResult.getEntity() == shootingStand)
                        entityRayTraceResult = null;
            }
            if (entityRayTraceResult != null && !ForgeEventFactory.onProjectileImpact(this, entityRayTraceResult)) {
                if (entityRayTraceResult.getEntity() instanceof Player && entityRayTraceResult.getEntity().equals(standMaster))
                    return;
                onHit(entityRayTraceResult);
            }
            if (raytraceresult != null && !ForgeEventFactory.onProjectileImpact(this, raytraceresult))
                onHit(raytraceresult);
            setPos(getX() + getDeltaMovement().x, getY() + getDeltaMovement().y, getZ() + getDeltaMovement().z);
            float f1 = 0.99f;
            if (isInWater())
                for (int i = 0; i < 4; i++)
                    level.addParticle(ParticleTypes.BUBBLE, getX() - getDeltaMovement().x * 0.25, getY() - getDeltaMovement().y * 0.25, getZ() - getDeltaMovement().z * 0.25, getDeltaMovement().x, getDeltaMovement().y, getDeltaMovement().z);
            if (isInWater())
                clearFire();

            setDeltaMovement(getDeltaMovement().multiply(f1, f1, f1));
            setPos(getX(), getY(), getZ());
            checkInsideBlocks();
        }
    }

    protected void onHit(HitResult result) {
        if (result.getType() != HitResult.Type.MISS)
            if (MinecraftForge.EVENT_BUS.post(new StandAttackEvent(
                    this,
                    result,
                    result.getType() == HitResult.Type.ENTITY ? ((EntityHitResult) result).getEntity() : null,
                    result.getType()
            ))) return;
        if (result.getType() == HitResult.Type.ENTITY) {
            Entity entity = ((EntityHitResult) result).getEntity();
            if (!entity.equals(standMaster) && !entity.equals(this)) {
                if (isOnFire() && !(entity instanceof EnderMan))
                    entity.setSecondsOnFire(5);
                if (entity instanceof LivingEntity) {
                    LivingEntity livingEntity = (LivingEntity) entity;
                    if (!level.isClientSide) {
                        level.addParticle(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 1, 0, 0);
                        if (!level.isClientSide) {
                            if (MinecraftForge.EVENT_BUS.post(new StandAttackEvent.EntityHit(this, result, entity)) && shouldRemoveOnHitEntity()) {
                                discard();
                                return;
                            }
                            onHitEntity((EntityHitResult) result);
                        }
                    }
                    if (standMaster != null && !livingEntity.equals(standMaster) && livingEntity instanceof Player && standMaster instanceof ServerPlayer)
                        ((ServerPlayer) standMaster).connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.ARROW_HIT_PLAYER, 0));
                }
                if (!(entity instanceof EnderMan) && shouldRemoveOnHitEntity())
                    discard();
            }
        } else if (result.getType() == HitResult.Type.BLOCK) {
            BlockPos blockPos = ((BlockHitResult) result).getBlockPos();
            BlockState state = level.getBlockState(blockPos);
            if (state == null)
                state = Blocks.AIR.defaultBlockState();
            xTile = blockPos.getX();
            yTile = blockPos.getY();
            zTile = blockPos.getZ();
            if(level.getBlockState(blockPos).getMaterial().isSolid()) {
            if (shouldBeDestroyedByBlocks(state))
                setDeltaMovement((float) (result.getLocation().x - getX()), (float) (result.getLocation().y - getY()), (float) (result.getLocation().z - getZ()));
                float f2 = Mth.sqrt((float) (getDeltaMovement().x * getDeltaMovement().x + getDeltaMovement().y * getDeltaMovement().y + getDeltaMovement().z * getDeltaMovement().z));
                setPos(getX() - getDeltaMovement().x / f2 * 0.05000000074505806, getY() - getDeltaMovement().y / f2 * 0.05000000074505806, getZ() - getDeltaMovement().z / f2 * 0.05000000074505806);
                inGround = true;
                arrowShake = 7;
                if (!level.isClientSide) {
                    if (MinecraftForge.EVENT_BUS.post(new StandAttackEvent.BlockHit(this, result, null))) {
                        discard();
                        return;
                    }
                    if (MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, blockPos, state, standMaster))) {
                        discard();
                        return;
                    }
                    onBlockHit((BlockHitResult) result);
                    if (state.getMaterial() != Material.AIR) {
                        state.getBlock().onProjectileHit(level, state, (BlockHitResult) result, this);
                        if (shouldBeDestroyedByBlocks(state))
                            discard();
                    }
                }
            }
        }
    }

    @Override
    public void move(MoverType type, Vec3 pos) {
        super.move(type, pos);
        if (inGround) {
            xTile = Mth.floor(getX());
            yTile = Mth.floor(getY());
            zTile = Mth.floor(getZ());
        }
    }

    @Nullable
    protected EntityHitResult getEntityHitResult(Vec3 startVec, Vec3 endVec) {
        return ProjectileUtil.getEntityHitResult(level, this, startVec, endVec, getBoundingBox().expandTowards(getDeltaMovement()).inflate(1), (entity) ->
                !entity.isSpectator() && entity.isAlive() && entity.isPickable() && (!entity.equals(shootingStand) || ticksInAir > getRange()) && !entity.equals(standMaster));
    }

    @Override
    public void playerTouch(Player entityIn) {
        if (!level.isClientSide && inGround && arrowShake <= 0 && !entityIn.equals(standMaster)) discard();
    }

    @Override
    public void push(Entity entityIn) {
        if (!entityIn.equals(shootingStand) && !entityIn.equals(standMaster))
            super.push(entityIn);
    }

    protected boolean isMovementNoisy() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void writeSpawnData(FriendlyByteBuf buffer) {
        buffer.writeInt(shootingStand == null ? -1 : shootingStand.getId());
        buffer.writeInt(standMaster == null ? -1 : standMaster.getId());
    }

    @Override
    public void readSpawnData(FriendlyByteBuf additionalData) {
        Entity stand = level.getEntity(additionalData.readInt());
        Entity master = level.getEntity(additionalData.readInt());
        if (stand instanceof AbstractStandEntity)
            shootingStand = (AbstractStandEntity) stand;
        if (master instanceof Player)
            standMaster = (Player) master;
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        xTile = compound.getDouble("xTile");
        yTile = compound.getDouble("yTile");
        zTile = compound.getDouble("zTile");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        compound.putDouble("xTile", xTile);
        compound.putDouble("yTile", yTile);
        compound.putDouble("zTile", zTile);
    }

    @Override
    protected void defineSynchedData() {
    }

    protected boolean shouldRemoveOnHitEntity(){
        return true;
    }

    protected SoundEvent getHitEntitySound() {
        return SoundInit.PUNCH_1.get();
    }

    protected boolean isFireballFiery() {
        return false;
    }

    protected float getMotionFactor() {
        return 1F;
    }
}