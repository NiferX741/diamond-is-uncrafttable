package io.github.halffocused.diamond_is_uncraftable.util;


import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

import javax.annotation.CheckForNull;
import java.util.Optional;
import java.util.function.Predicate;

public class HitscanHelper {

    @CheckForNull
    public static EntityHitResult getEntityFromRaytrace(LivingEntity entityIn, double range)
    {
        return getEntityFromRaytrace(entityIn, range, 1.0F);
    }

    @CheckForNull
    public static EntityHitResult getEntityFromRaytrace(LivingEntity startEntity, double range, float ticks) {
        Level world = startEntity.getCommandSenderWorld();

        Vec3 look = startEntity.getLookAngle();
        Vec3 start = startEntity.getEyePosition(ticks);

        Vec3 end = new Vec3(startEntity.getX() + look.x * range, startEntity.getEyeY() + look.y * range, startEntity.getZ() + look.z * range);
        ClipContext context = new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, startEntity);

        HitResult rayTraceResult = world.clip(context);
        double traceDistance = rayTraceResult.getLocation().distanceToSqr(start);

        AABB playerBox = startEntity.getBoundingBox().expandTowards(look.scale(traceDistance)).expandTowards(1.0D, 1.0D, 1.0D);

        Predicate<Entity> filter = entity -> !entity.isSpectator() && entity.isPickable() && entity instanceof LivingEntity;
        for (Entity possible : world.getEntities(startEntity, playerBox, filter)) {
            AABB entityBox = possible.getBoundingBox().inflate(0.3D);
            Optional<Vec3> optional = entityBox.clip(start, end);
            if (optional.isPresent()) {
                Vec3 position = optional.get();
                double distance = start.distanceToSqr(position);

                if (distance < traceDistance) {
                    return new EntityHitResult(possible, position);
                }
            }
        }
        return null;
    }


    @CheckForNull
    public static EntityHitResult getEntityFromRaytracePos(LivingEntity entityIn, double range)
    {
        return getEntityFromRaytrace(entityIn, range, 1.0F);
    }

    @CheckForNull
    public static EntityHitResult getEntityFromRaytracePos(Vec3 positionIn, Vec3 vectorIn, AABB boundingBoxIn, LivingEntity ignoreEntity, Level worldIn, double range, float ticks) {

        Vec3 end = new Vec3(positionIn.x + vectorIn.x * range, positionIn.y + vectorIn.y * range, positionIn.z + vectorIn.z * range);
        ClipContext context = new ClipContext(positionIn, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null);

        HitResult rayTraceResult = worldIn.clip(context);
        double traceDistance = rayTraceResult.getLocation().distanceToSqr(positionIn);

        AABB playerBox = boundingBoxIn.expandTowards(vectorIn.scale(traceDistance)).expandTowards(1.0D, 1.0D, 1.0D);

        Predicate<Entity> filter = entity -> !entity.isSpectator() && entity.isPickable() && entity instanceof LivingEntity;
        for (Entity possible : worldIn.getEntities(ignoreEntity, playerBox, filter)) {
            AABB entityBox = possible.getBoundingBox().inflate(0.3D);
            Optional<Vec3> optional = entityBox.clip(positionIn, end);
            if (optional.isPresent()) {
                Vec3 position = optional.get();
                double distance = positionIn.distanceToSqr(position);

                if (distance < traceDistance) {
                    return new EntityHitResult(possible, position);
                }
            }
        }
        return null;
    }


    @CheckForNull
    public static EntityHitResult traceToEntity(Player player, Entity target)
    {
        return traceToEntity(player, target, 1.0F);
    }

    @CheckForNull
    public static EntityHitResult traceToEntity(Player player, Entity target, float ticks) {
        Vec3 start = player.getEyePosition(ticks);
        Vec3 end = target.position();

        AABB targetBox = target.getBoundingBox().inflate(0.3D);
        Optional<Vec3> optional = targetBox.clip(start, end);

        return optional.map(vector3d -> new EntityHitResult(target, vector3d)).orElse(null);
    }
}
