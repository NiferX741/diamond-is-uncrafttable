package io.github.halffocused.diamond_is_uncraftable.capability;

import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class StandTileEntityEffects implements ICapabilitySerializable<Tag> {
    public static final Capability<StandTileEntityEffects> STAND_TILE_ENTITY_EFFECTS = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<StandTileEntityEffects> STORAGE;
    private final BlockEntity tileEntity;
    private LazyOptional<StandTileEntityEffects> holder = LazyOptional.of(() -> new StandTileEntityEffects(getBlockEntity()));
    private NonNullList<ItemStack> chestInventory = NonNullList.withSize(27, ItemStack.EMPTY);
    private NonNullList<ItemStack> furnaceInventory = NonNullList.withSize(3, ItemStack.EMPTY);
    private NonNullList<ItemStack> brewingInventory = NonNullList.withSize(5, ItemStack.EMPTY);
    private NonNullList<ItemStack> barrelInventory = NonNullList.withSize(27, ItemStack.EMPTY);
    private NonNullList<ItemStack> dispenserInventory = NonNullList.withSize(9, ItemStack.EMPTY);
    private NonNullList<ItemStack> hopperInventory = NonNullList.withSize(5, ItemStack.EMPTY);
    private NonNullList<ItemStack> shulkerBoxInventory = NonNullList.withSize(27, ItemStack.EMPTY);

    public StandTileEntityEffects(BlockEntity tileEntity) {
        this.tileEntity = tileEntity;
    }

    public static LazyOptional<StandTileEntityEffects> getLazyOptional(BlockEntity tileEntity) {
        return tileEntity.getCapability(STAND_TILE_ENTITY_EFFECTS);
    }

    public static void register() {
        STORAGE = new CapStorage<StandTileEntityEffects>() {
            @Override
            public Tag writeNBT(Capability<StandTileEntityEffects> capability, StandTileEntityEffects instance, Direction side) {
                CompoundTag compoundNBT = new CompoundTag();
                ListTag chestInventory = new ListTag();
                for (int i = 0; i < instance.chestInventory.size(); i++)
                    if (!instance.chestInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.chestInventory.get(i).save(compoundnbt);
                        chestInventory.add(compoundnbt);
                    }
                compoundNBT.put("chestInventory", chestInventory);
                ListTag furnaceInventory = new ListTag();
                for (int i = 0; i < instance.furnaceInventory.size(); i++)
                    if (!instance.furnaceInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.furnaceInventory.get(i).save(compoundnbt);
                        furnaceInventory.add(compoundnbt);
                    }
                compoundNBT.put("furnaceInventory", furnaceInventory);
                ListTag brewingInventory = new ListTag();
                for (int i = 0; i < instance.brewingInventory.size(); i++)
                    if (!instance.brewingInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.brewingInventory.get(i).save(compoundnbt);
                        brewingInventory.add(compoundnbt);
                    }
                compoundNBT.put("brewingInventory", brewingInventory);
                ListTag barrelInventory = new ListTag();
                for (int i = 0; i < instance.barrelInventory.size(); i++)
                    if (!instance.barrelInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.barrelInventory.get(i).save(compoundnbt);
                        barrelInventory.add(compoundnbt);
                    }
                compoundNBT.put("barrelInventory", barrelInventory);
                ListTag dispenserInventory = new ListTag();
                for (int i = 0; i < instance.dispenserInventory.size(); i++)
                    if (!instance.dispenserInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.dispenserInventory.get(i).save(compoundnbt);
                        dispenserInventory.add(compoundnbt);
                    }
                compoundNBT.put("dispenserInventory", dispenserInventory);
                ListTag hopperInventory = new ListTag();
                for (int i = 0; i < instance.hopperInventory.size(); i++)
                    if (!instance.hopperInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.hopperInventory.get(i).save(compoundnbt);
                        hopperInventory.add(compoundnbt);
                    }
                compoundNBT.put("hopperInventory", hopperInventory);
                ListTag shulkerBoxInventory = new ListTag();
                for (int i = 0; i < instance.shulkerBoxInventory.size(); i++)
                    if (!instance.shulkerBoxInventory.get(i).isEmpty()) {
                        CompoundTag compoundnbt = new CompoundTag();
                        compoundnbt.putByte("Slot", (byte) i);
                        instance.shulkerBoxInventory.get(i).save(compoundnbt);
                        shulkerBoxInventory.add(compoundnbt);
                    }
                compoundNBT.put("shulkerBoxInventory", shulkerBoxInventory);
                return compoundNBT;
            }

            @Override
            public void readNBT(Capability<StandTileEntityEffects> capability, StandTileEntityEffects instance, Direction side, Tag nbt) {
                ListTag listNBT = ((CompoundTag) nbt).getList("chestInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < listNBT.size(); ++i) {
                    CompoundTag compoundnbt = listNBT.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.chestInventory.size())
                            instance.chestInventory.set(j, itemstack);
                }
                ListTag furnaceInventory = ((CompoundTag) nbt).getList("furnaceInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < furnaceInventory.size(); ++i) {
                    CompoundTag compoundnbt = furnaceInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.furnaceInventory.size())
                            instance.furnaceInventory.set(j, itemstack);
                }
                ListTag brewingInventory = ((CompoundTag) nbt).getList("brewingInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < brewingInventory.size(); ++i) {
                    CompoundTag compoundnbt = brewingInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.brewingInventory.size())
                            instance.brewingInventory.set(j, itemstack);
                }
                ListTag barrelInventory = ((CompoundTag) nbt).getList("barrelInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < barrelInventory.size(); ++i) {
                    CompoundTag compoundnbt = barrelInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.barrelInventory.size())
                            instance.barrelInventory.set(j, itemstack);
                }
                ListTag dispenserInventory = ((CompoundTag) nbt).getList("dispenserInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < dispenserInventory.size(); ++i) {
                    CompoundTag compoundnbt = dispenserInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.dispenserInventory.size())
                            instance.dispenserInventory.set(j, itemstack);
                }
                ListTag hopperInventory = ((CompoundTag) nbt).getList("hopperInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < hopperInventory.size(); ++i) {
                    CompoundTag compoundnbt = hopperInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.hopperInventory.size())
                            instance.hopperInventory.set(j, itemstack);
                }
                ListTag shulkerBoxInventory = ((CompoundTag) nbt).getList("shulkerBoxInventory", Tag.TAG_COMPOUND);
                for (int i = 0; i < shulkerBoxInventory.size(); ++i) {
                    CompoundTag compoundnbt = shulkerBoxInventory.getCompound(i);
                    int j = compoundnbt.getByte("Slot") & 255;
                    ItemStack itemstack = ItemStack.of(compoundnbt);
                    if (!itemstack.isEmpty())
                        if (j < instance.shulkerBoxInventory.size())
                            instance.shulkerBoxInventory.set(j, itemstack);
                }
            }
        };
    }

    public BlockEntity getBlockEntity() {
        return tileEntity;
    }

    public NonNullList<ItemStack> getChestInventory() {
        return chestInventory;
    }

    public NonNullList<ItemStack> getFurnaceInventory() {
        return furnaceInventory;
    }

    public NonNullList<ItemStack> getBrewingInventory() {
        return brewingInventory;
    }

    public NonNullList<ItemStack> getBarrelInventory() {
        return barrelInventory;
    }

    public NonNullList<ItemStack> getDispenserInventory() {
        return dispenserInventory;
    }

    public NonNullList<ItemStack> getHopperInventory() {
        return hopperInventory;
    }

    public NonNullList<ItemStack> getShulkerBoxInventory() {
        return shulkerBoxInventory;
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == STAND_TILE_ENTITY_EFFECTS ? holder.cast() : LazyOptional.empty();
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(STAND_TILE_ENTITY_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(STAND_TILE_ENTITY_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }
}
