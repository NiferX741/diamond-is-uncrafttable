package io.github.halffocused.diamond_is_uncraftable.client.entity.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.AbstractStandAttackEntity;
import net.minecraft.client.model.EntityModel;

public abstract class AbstractStandAttackModel<T extends AbstractStandAttackEntity> extends EntityModel<T> {
    public int textureWidth = 64;
    public int textureHeight = 32;
    protected void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        getAttackModel().rotateAngleY = entity.yRotO + (entity.getYRot() - entity.yRotO) * ageInTicks - 90;
    }

    @Override
    public void renderToBuffer(PoseStack matrixStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        getAttackModel().render(matrixStack, buffer, packedLight, packedOverlay);
    }

    protected abstract ModelRenderer getAttackModel();
}
