package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.KillerQueenBitesTheDustEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandMasterPacket;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.BitesTheDustHelper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.Collections;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class CStandSummonPacket implements IMessage<CStandSummonPacket> {
    @Override
    public void encode(CStandSummonPacket message, FriendlyByteBuf buffer) {
    }

    @Override
    public CStandSummonPacket decode(FriendlyByteBuf buffer) {
        return new CStandSummonPacket();
    }

    @Override
    public void handle(CStandSummonPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ctx.get().getSender();
                if (sender == null || sender.isSpectator()) return;
                if (!sender.level.isClientSide) {
                    Stand.getLazyOptional(sender).ifPresent(stand -> {

                        boolean wasUnsummonPrevented = false;

                        stand.setMomentum(0);

                        if(!stand.getStandOn()){
                            stand.setStandOn(true);
                        }else{
                            if(!stand.getPreventUnsummon() && !stand.getPreventUnsummon2() && !stand.getPreventUnsummon3()){
                                stand.setStandOn(false);
                            }else{
                                wasUnsummonPrevented = true;
                            }
                        }

                        if (stand.getStandOn() && !wasUnsummonPrevented) {
                            if (stand.getStandID() != 0) {
                                AbstractStandEntity standEntity = Util.StandID.getStandByID(stand.getStandID(), sender.level);
                                if (Collections.frequency(java.util.stream.StreamSupport.stream(sender.getLevel().getAllEntities().spliterator(), false).collect(Collectors.toList()), standEntity) > 0)
                                    return;
                                Vec3 position = sender.getLookAngle().multiply(0.5, 1, 0.5).add(sender.position()).add(0, 0.5, 0);
                                standEntity.moveTo(position.x, position.y, position.z, sender.getYRot(), sender.getXRot());
                                standEntity.setMaster(sender);
                                standEntity.setMasterUUID(sender.getUUID());
                                if (DiamondIsUncraftableConfig.CLIENT.playStandSpawnSounds.get())
                                    standEntity.playSpawnSound();
                                DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> sender), new SSyncStandMasterPacket(standEntity.getId(), sender.getId()));
                                sender.level.addFreshEntity(standEntity);
                                if(standEntity instanceof KillerQueenBitesTheDustEntity){
                                    if(BitesTheDustHelper.bitesTheDustActive && BitesTheDustHelper.bitesTheDustPlayer.equals(sender)
                                    ){
                                        BitesTheDustHelper.cancelBitesTheDust();
                                    }
                                }
                            }
                        } else
                            stand.setAct(0);
                    });
                }
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
