package io.github.halffocused.diamond_is_uncraftable.network.message;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Mostly just used so I don't screw up a method in my packets, also vital to {@link PacketHandler#registerPacket(Class, IMessage)}.
 */
public interface IMessage<MSG> {
    void encode(MSG message, FriendlyByteBuf buffer);

    MSG decode(FriendlyByteBuf buffer);

    void handle(MSG message, Supplier<NetworkEvent.Context> ctx);
}
