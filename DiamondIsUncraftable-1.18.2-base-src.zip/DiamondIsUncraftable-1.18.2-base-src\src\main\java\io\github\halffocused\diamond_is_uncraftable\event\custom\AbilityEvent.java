package io.github.halffocused.diamond_is_uncraftable.event.custom;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.network.message.client.CToggleAbilityPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;

/**
 * {@link AbilityEvent} if fired when the value of {@link Stand#getAbility()} ()} is changed.
 * This event is fired from {@link CToggleAbilityPacket} and has two child events.
 */
public class AbilityEvent extends PlayerEvent {
    public AbilityEvent(Player player) {
        super(player);
    }

    @Override
    public Player getPlayer() {
        return super.getPlayer();
    }

    /**
     * Fired when an {@link Stand#getAbility()} is activated.
     */
    public static class AbilityActivated extends AbilityEvent {

        public AbilityActivated(Player player) {
            super(player);
        }
    }

    /**
     * Fired when an {@link Stand#getAbility()} is deactivated.
     */
    public static class AbilityDeactivated extends AbilityEvent {

        public AbilityDeactivated(Player player) {
            super(player);
        }
    }
}
