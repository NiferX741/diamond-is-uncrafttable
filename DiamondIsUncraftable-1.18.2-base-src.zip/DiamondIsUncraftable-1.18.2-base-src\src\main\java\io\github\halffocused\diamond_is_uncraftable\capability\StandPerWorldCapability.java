package io.github.halffocused.diamond_is_uncraftable.capability;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandPerWorldCapabilityPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class StandPerWorldCapability implements ICapabilitySerializable<Tag> {
    public static final Capability<StandPerWorldCapability> WORLD = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<StandPerWorldCapability> STORAGE;
    Level world;
    private LazyOptional<StandPerWorldCapability> holder = LazyOptional.of(() -> new StandPerWorldCapability(getWorld()));
    private List<Integer> takenStandIDs = new ArrayList<>();

    public StandPerWorldCapability(@Nonnull Level world) {
        this.world = world;
    }

    public static LazyOptional<StandPerWorldCapability> getLazyOptional(Level world) {
        return world.getCapability(WORLD);
    }

    public static StandPerWorldCapability getCapabilityFromWorld(Level world) {
        return world.getCapability(WORLD).orElse(new StandPerWorldCapability(world));
    }

    public static void register() {
        STORAGE = new CapStorage<StandPerWorldCapability>() {
            @Nonnull
            @Override
            public Tag writeNBT(Capability<StandPerWorldCapability> capability, StandPerWorldCapability instance, Direction side) {
                CompoundTag nbt = new CompoundTag();

                ListTag takenStandIDs = new ListTag();
                instance.getTakenStandIDs().forEach(id -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putInt("StandID", id);
                    takenStandIDs.add(compoundNBT);
                });
                nbt.put("TakenStandIDs", takenStandIDs);

                return nbt;
            }

            @Override
            public void readNBT(Capability<StandPerWorldCapability> capability, StandPerWorldCapability instance, Direction side, Tag nbt) {
                CompoundTag compoundNBT = (CompoundTag) nbt;

                compoundNBT.getList("TakenStandIDs", Tag.TAG_COMPOUND).forEach(inbt -> {
                    if (inbt instanceof CompoundTag && ((CompoundTag) inbt).contains("StandID"))
                        instance.addTakenStandId(((CompoundTag) inbt).getInt("StandID"));
                });
            }
        };
    }

    public List<Integer> getTakenStandIDs() {
        return takenStandIDs;
    }


    public void addTakenStandId(int id) {
        takenStandIDs.add(id);
        onDataUpdated();
    }

    public void removeTakenStandId(int id) {
        takenStandIDs.remove(new Integer(id));
        onDataUpdated();
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @Nullable Direction side) {
        return capability == WORLD ? holder.cast() : LazyOptional.empty();
    }

    public Level getWorld() {
        return world;
    }

    public void onDataUpdated() {
        if (!world.isClientSide)
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.ALL.noArg(), new SSyncStandPerWorldCapabilityPacket(this));
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(WORLD, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(WORLD, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }

}
