package io.github.halffocused.diamond_is_uncraftable.util.frame;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import net.minecraft.server.level.ServerPlayer;

public class MenacingFrame extends AbstractFrame{

    public MenacingFrame(int tickIn){
        super(tickIn);
    }

    @Override
    public void doThing(AbstractStandEntity standEntity, Move assignedMove) {
        if(!standEntity.getMaster().level.isClientSide()){
            ServerPlayer playerEntity = (ServerPlayer) standEntity.getMaster();
            Util.giveAdvancement(playerEntity, "menacing");
        }

        Util.spawnParticle(standEntity, 1, standEntity.getX(), standEntity.getY() + 1.5, standEntity.getZ(), 2, 2, 2, 4);

        Util.spawnParticle(standEntity, 1, standEntity.getMaster().getX(), standEntity.getMaster().getY() + 1.5, standEntity.getMaster().getZ(), 2, 2, 2, 4);
    }
}
