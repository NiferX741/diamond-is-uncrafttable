package io.github.halffocused.diamond_is_uncraftable.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.GuiUtils;

public class BitesTheDustEffectGUI extends GuiComponent {
    public static final Minecraft mc = Minecraft.getInstance();

    public void renderEffect() {
        Player player = mc.player;

        if (mc.level == null) return;
        if (player == null) return;

        if(!DiamondIsUncraftableConfig.CLIENT.noTimeSkipFlash.get()) {

            Stand.getLazyOptional(player).ifPresent(props -> {
                if (props.getBitesTheDustEffectTicker() > 0) {

                    //If I had randomly chosen numbers I'm pretty sure I would have gotten these faster than trying to actually figure them out.
                    //This was a very informative introduction to GUIs. What did I learn? Why I couldn't find a guide online.
                    double xScaleFactor = mc.getWindow().getGuiScaledWidth() / 240.0;
                    double yScaleFactor = mc.getWindow().getGuiScaledHeight() / 135.0;


                    PoseStack stack = new PoseStack();
                    RenderSystem.enableBlend();
                    stack.scale((float) xScaleFactor, (float) yScaleFactor, 1);

                    int frame = 46 - (props.getBitesTheDustEffectTicker());
                    String texture = "btd";
                    if(frame < 10){
                        texture += "00" + frame;
                    }else{
                        texture += "0" + frame;
                    }

                    RenderSystem.setShaderTexture(0, new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/gui/bites_the_dust/" + texture + ".png"));
                    GuiUtils.drawTexturedModalRect(stack, 0, 0, 0, 0, 240, 135, 0);
                }
            });
        }
    }
}
