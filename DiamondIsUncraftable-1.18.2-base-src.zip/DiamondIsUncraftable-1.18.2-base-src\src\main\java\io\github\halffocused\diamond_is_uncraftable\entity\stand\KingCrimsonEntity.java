package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.init.EffectInit;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.ChargeAttackFormat;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.MovementAnimationHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import software.bernie.geckolib3.core.IAnimatable;

import java.util.ArrayList;

@SuppressWarnings("ConstantConditions")
public class KingCrimsonEntity extends AbstractStandEntity implements IAnimatable, IOnMasterAttacked, IOnHit {

    ArrayList<EpitaphPairing> pairList = new ArrayList<>();

    int opportunityTicks = 0;
    static boolean activeTimeErase = false;
    int epitaphTicks = -1;
    boolean epitaphFlag = false;
    int epitaphEndingOpportunityTicks = 0;
    public boolean timeEraseActive;
    int timeEraseDuration = 0;
    boolean clipToPosition = false;
    LivingEntity executionTarget = null;

    AttackFramedata mainPunchData = new AttackFramedata(25)
            .addDamageFrame(12, 10, Vec3.ZERO, 2, 1)
            .addMessageFrame(15, 1, 9, null);

    AttackFramedata barrageData = new AttackFramedata(53)
            .generateInterval(8, 45, 3, 2, Vec3.ZERO, 2.7, 4)
            .addMessageFrame(43, 1, 9, null);

    AttackFramedata lightChargeAttack = new AttackFramedata(22)
            .addDamageFrame(8, 16, Vec3.ZERO, 2.0, 1)
            .addMessageFrame(12, 1, 9, null);

    AttackFramedata mediumChargeAttack = new AttackFramedata(24)
            .addDamageFrame(10, 21, Vec3.ZERO, 2.0, 1)
            .addMessageFrame(14, 1, 9, null);

    AttackFramedata chopAttack = new AttackFramedata(25)
            .addDamageFrame(11, 4, Vec3.ZERO, 2.0, 3, false);

    AttackFramedata epitaphChopAttack = new AttackFramedata(30)
            .addDamageFrame(11, 17, Vec3.ZERO, 2.0, 3);

    AttackFramedata timeErase = new AttackFramedata(32)
            .addMessageFrame(30, 4, null, null);

    AttackFramedata execution = new AttackFramedata(95)
            .addDamageFrame(10, 1, Vec3.ZERO, 4, 1)
            .addMessageFrame(14, 2, null, null)
            .addMenacingFrame(15)
            .addMessageFrame(88, 3, null, null)
            .addMenacingFrame(88);

    AttackFramedata recovery = new AttackFramedata(90);

    AttackFramedata epitaph = new AttackFramedata(30)
            .addMessageFrame(11, 5, null, null);

    ChargeAttackFormat chargeAttackFormat = new ChargeAttackFormat("charging")
            .addChargeNode(60, 3, true)
            .addChargeNode(140, 4, true)
            .addChargeNode(200, 6, true)
            .addChargeNode(300, 8, false);


    HoveringMoveHandler controller = new HoveringMoveHandler(this)
            .addMove("Punch", 1, mainPunchData, "crimsonpunch", 1.65)
            .addMove("Barrage",2, barrageData, "crimsonbarrage", HoveringMoveHandler.RepositionConstants.MASTER_POSITION)
            .addMove("Medium Punch",3, lightChargeAttack, "weakcharge", 2.0)
            .addMove("Strong Punch",4, mediumChargeAttack, "midcharge", 2.0)
            .addMove("Time Erase Follow Up",5, chopAttack, "chop", HoveringMoveHandler.RepositionConstants.DO_NOT_MOVE)
            .addMove("Donut Punch",6, execution, "execution", HoveringMoveHandler.RepositionConstants.DO_NOT_MOVE)
            .addMove("Time Erase",7, timeErase, "erase", 1.35)
            .addMove("Recovery",8, recovery, "recovery", HoveringMoveHandler.RepositionConstants.IDLE_POSITION)
            .addMove("Epitaph Prediction",9, epitaph, "epitaph", HoveringMoveHandler.RepositionConstants.IDLE_POSITION)
            .addMove("Epitaph Counter-Attack",10, epitaphChopAttack, "chop", 1.85)
            .addChargeAttack(chargeAttackFormat);

    public HoveringMoveHandler getController(){
        return controller;
    }


    public KingCrimsonEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    public void epitaph() {

        if(spendEnergy(90)) {
            controller.setMoveActive(9);
        }

    }

    public void teleport(double multiplier) {
        if (level.isClientSide || master == null || epitaphTicks > 0) return;

        Stand.getLazyOptional(master).ifPresent(stand -> {
            if (timeEraseActive) {
                endTimeSkip();
            } else if (!timeEraseActive) {
                if (opportunityTicks > 0) {
                    if (getMostRecentlyDamagedEntity() != null && spendEnergy(20, true)) { //
                        stand.setTimeSkipEffectTicker(15);
                        level.playSound(null, blockPosition(), SoundInit.KING_CRIMSON_COMBO.get(), SoundSource.NEUTRAL, 0.65f, 1.2f);
                        if(getMostRecentlyDamagedEntity() instanceof Player){
                            Stand.getLazyOptional(((Player) getMostRecentlyDamagedEntity())).ifPresent(props -> {
                                props.setTimeSkipEffectTicker(15);
                            });
                        }

                        opportunityTicks = 0;
                        controller.cancelActiveMoves();
                        controller.setMoveActive(5);
                    }
                } else {
                    if(opportunityTicks == -10 && !activeTimeErase) {
                        if(!controller.isMoveActive() && getEnergyPercentage() == 1 && spendEnergy(20)) {
                            controller.setMoveActive(7);
                        }
                    }
                }
            }
        });
    }




    @Override
    public void tick() {
        super.tick();
        if (getMaster() == null) return;

        Stand.getLazyOptional(master).ifPresent(stand -> {
            ability = stand.getAbility();
            if (opportunityTicks > 0 && getMostRecentlyDamagedEntity() != null && energyAtThreshold(15)) {
                Util.spawnParticle(this, 6, this.getX(), this.getY() + this.getEyeHeight() - 0.5, this.getZ(), 1.2, 2.5, 1.2, 1);
            }
        });


        opportunityTicks = Math.max(opportunityTicks - 1, -10);

        if (controller.isMoveActive()) {
            if (controller.getActiveMove().getId() == 5 && getMostRecentlyDamagedEntity() != null) {
                Vec3 position = getMostRecentlyDamagedEntity().position().add(getMostRecentlyDamagedEntity().getLookAngle().normalize().reverse().multiply(1.5, 1.5, 1.5));
                setPos(position.x, position.y, position.z);
                lookAt(getMostRecentlyDamagedEntity(), Float.MAX_VALUE, Float.MAX_VALUE);
                getMostRecentlyDamagedEntity().addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 10, 1));
            }

            if (executionTarget != null) {
                if (controller.getActiveMove().getId() == 6) {
                    if (clipToPosition) {
                        Vec3 position = this.position().add(this.getLookAngle().normalize().multiply(3.2, 3.2, 3.2));
                        executionTarget.teleportTo(position.x, position.y + controller.getActiveMove().getFramedata().getTicker() / 80.0, position.z);
                        if(executionTarget instanceof Player){
                            Util.applyUnactionableTicks((Player) executionTarget, 1);
                        }
                    }
                    if (!executionTarget.isAlive()) {
                        executionTarget = null;
                        controller.cancelActiveMoves();
                    }
                }
            }
        }
        if (!level.isClientSide()) {
            if (timeEraseActive) {

                Util.spawnParticle(this, 6, master.getX(), master.getY(), master.getZ(), 30, 12, 30, 125);
                Util.spawnParticle(this, 8, master.getX(), master.getY(), master.getZ(), 30, 12, 30, 125);

                if (timeEraseDuration == 0 || timeEraseDuration % 20 == 0) {
                    //master.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 21, 1));
                }
                for (EpitaphPairing pair : pairList) {
                    if (pair.getPrediction() instanceof Monster) {
                        ((Monster) pair.getPrediction()).setTarget(null);
                    }
                    pair.getPrediction().setLastHurtByMob(null);
                    pair.getPredicted().addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 25, 1));
                    Util.spawnParticle(this, 7, pair.getPrediction().getX(), pair.getPrediction().getY() + 0.75, pair.getPrediction().getZ(), 1.3, 1.45, 1.3, 1);
                }
                master.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 25, 1));
                master.setInvulnerable(true);

                timeEraseDuration++;


                if(epitaphFlag){
                    if(timeEraseDuration >= 100){
                        epitaphFlag = false;
                        endTimeSkip();
                        epitaphEndingOpportunityTicks = 40;
                    }

                    Stand.getLazyOptional(master).ifPresent(stand -> {
                        stand.setCounterBuffer(false);
                    });
                }else{
                    if(!spendEnergy(0.45, true)){ //Channeled energy spending ignores actionability
                        endTimeSkip();
                    }
                }

            } else {
                timeEraseDuration = 0;
                this.setInvisible(false);
                master.setInvulnerable(false);
            }

            if(epitaphTicks > 0){
                Util.spawnParticle(this, 6, master.getX(), master.getY() + 0.75, master.getZ(), 1.3, 1.45, 1.3, 1);
                Util.spawnParticle(this, 7, master.getX(), master.getY() + 0.75, master.getZ(), 1.3, 1.45, 1.3, 1);
            }

            epitaphTicks = Math.max(epitaphTicks - 1, -1);
            epitaphEndingOpportunityTicks = Math.max(epitaphEndingOpportunityTicks - 1, 0);
        }
    }

    private void teleportNearby(LivingEntity entityLiving){
        //right from the chorus fruit

        for(int i = 0; i < 16; ++i) {
            double d3 = entityLiving.getX() + (entityLiving.getRandom().nextDouble() - 0.5D) * 4.0D;
            double d4 = Mth.clamp(entityLiving.getY() + (double)(entityLiving.getRandom().nextInt(2) - 1), 0.0D, (entityLiving.level.getHeight() - 1));
            double d5 = entityLiving.getZ() + (entityLiving.getRandom().nextDouble() - 0.5D) * 4.0D;
            if (entityLiving.isPassenger()) {
                entityLiving.stopRiding();
            }

            entityLiving.randomTeleport(d3, d4, d5, true);
        }
    }

    @Override
    public MovementAnimationHolder getMovementAnimations(){

        return new MovementAnimationHolder().create("kingcrimson", "kingcrimsonforward", "crimsonright", "crimsonleft", "kingcrimsonbackwards");
        //Yes, joejan called the left animation "right" and right animation "left". Make fun of him for me if you see this.
    }

    @Override
    public void messageFrame(int message1, Object message2, Object message3) {
        if(message1 == 1){
            opportunityTicks = (int) message2;
        }
        if(message1 == 2){
            if(getMostRecentlyDamagedEntity() == null){
                controller.cancelActiveMoves();
                controller.setMoveActive(8);
            }else{
                executionTarget = getMostRecentlyDamagedEntity();
                clipToPosition = true;
                executionTarget.setNoGravity(true);
            }
        }

        if(message1 == 3){
            if(executionTarget != null){
                Util.dealStandDamage(this, executionTarget, 50f, Vec3.ZERO, false);
                clipToPosition = false;
                executionTarget.setNoGravity(false);
            }
        }

        if(message1 == 4){
            startTimeSkip();
        }

        if(message1 == 5){
            epitaphTicks = 30;
            Stand.getLazyOptional(master).ifPresent(stand -> {
                stand.setCounterBuffer(true);
            });

            master.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
        }
    }


    @Override
    public void onRemovedFromWorld() {
        super.onRemovedFromWorld();

        if(timeEraseActive){
            endTimeSkip();
        }
        if(executionTarget != null){
            executionTarget.setNoGravity(false);
            executionTarget = null;
        }
    }

    private void startTimeSkip(){
        Stand.getLazyOptional(master).ifPresent(stand -> {
            stand.setPreventUnsummon2(true);
            stand.setExperiencingTimeSkip(true);
        });

        level.playSound(null, blockPosition(), SoundInit.TIME_SKIP_BEGIN.get(), SoundSource.NEUTRAL, 1, 1);

        timeEraseActive = true;
        activeTimeErase = true;
        java.util.stream.StreamSupport.stream(getServer().getLevel(this.level.dimension()).getAllEntities().spliterator(), false)
                .filter(entity -> !entity.equals(master) && !entity.equals(this))
                .filter(entity -> entity instanceof LivingEntity)
                .filter(entity -> verify((LivingEntity) entity))
                .filter(entity -> entity.distanceTo(this) < 50)
                .forEach(entity -> createPairing((LivingEntity) entity));
    }

    public void endTimeSkip(){

        timeEraseActive = false;

        level.playSound(null, blockPosition(), SoundInit.TIME_SKIP_END.get(), SoundSource.NEUTRAL, 1, 1);


        Stand.getLazyOptional(master).ifPresent(stand -> {
            stand.setTimeSkipEffectTicker(15);
            stand.setExperiencingTimeSkip(false);
        });

        pairList.forEach(epitaphPairing -> {
            LivingEntity predicted = epitaphPairing.getPredicted();
            LivingEntity prediction = epitaphPairing.getPrediction();

            predicted.restoreFrom(prediction);
            predicted.teleportTo(prediction.getX(), prediction.getY(), prediction.getZ());
            predicted.setYRot(prediction.getYRot()); predicted.setXRot(prediction.getXRot());
            predicted.setDeltaMovement(prediction.getDeltaMovement());
            predicted.fallDistance = prediction.fallDistance;
            predicted.setInvulnerable(false);

            prediction.setGlowingTag(false);
            prediction.setInvulnerable(false);
            prediction.setPos(prediction.getX(), -999, prediction.getZ());
            prediction.hurt(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);

            if (predicted instanceof Player) {
                Stand.getLazyOptional(((Player) predicted)).ifPresent(props -> {
                    props.setTimeSkipEffectTicker(15);
                    props.setExperiencingTimeSkip(false);
                });
            }
        });
        pairList.clear();

        Stand.getLazyOptional(master).ifPresent(stand -> {
            stand.setPreventUnsummon2(false);
        });

        activeTimeErase = false;
    }

    private void createPairing(LivingEntity entityIn){
        LivingEntity predictionEntity = null;

        if(entityIn instanceof Player){
            predictionEntity = new Villager(EntityType.VILLAGER, entityIn.level);
        }else if(entityIn instanceof ZombifiedPiglin){
            predictionEntity = new ZombifiedPiglin(EntityType.ZOMBIFIED_PIGLIN, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.GOLDEN_SWORD));
        }else if(entityIn instanceof Blaze){
            predictionEntity = new Blaze(EntityType.BLAZE, entityIn.level);
        }else if(entityIn instanceof Drowned){
            predictionEntity = new Drowned(EntityType.DROWNED, entityIn.level);
        }else if(entityIn instanceof ElderGuardian){
            predictionEntity = new ElderGuardian(EntityType.ELDER_GUARDIAN, entityIn.level);
        }else if(entityIn instanceof Endermite){
            predictionEntity = new Endermite(EntityType.ENDERMITE, entityIn.level);
        }else if(entityIn instanceof Evoker){
            predictionEntity = new Evoker(EntityType.EVOKER, entityIn.level);
        }else if(entityIn instanceof Ghast){
            predictionEntity = new Ghast(EntityType.GHAST, entityIn.level);
        }else if(entityIn instanceof Guardian){
            predictionEntity = new Guardian(EntityType.GUARDIAN, entityIn.level);
        }else if(entityIn instanceof MagmaCube){
            predictionEntity = new MagmaCube(EntityType.MAGMA_CUBE, entityIn.level);
        }else if(entityIn instanceof Phantom){
            predictionEntity = new Phantom(EntityType.PHANTOM, entityIn.level);
        }else if(entityIn instanceof Pillager){
            predictionEntity = new Pillager(EntityType.PILLAGER, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.CROSSBOW));
        }else if(entityIn instanceof Ravager){
            predictionEntity = new Ravager(EntityType.RAVAGER, entityIn.level);
        }else if(entityIn instanceof Silverfish){
            predictionEntity = new Silverfish(EntityType.SILVERFISH, entityIn.level);
        }else if(entityIn instanceof Slime){
            predictionEntity = new Slime(EntityType.SLIME, entityIn.level);
        }else if(entityIn instanceof Stray){
            predictionEntity = new Stray(EntityType.STRAY, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.BOW));
        }else if(entityIn instanceof Vex){
            predictionEntity = new Vex(EntityType.VEX, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_SWORD));
        }else if(entityIn instanceof Vindicator){
            predictionEntity = new Vindicator(EntityType.VINDICATOR, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_AXE));
        }else if(entityIn instanceof Witch){
            predictionEntity = new Witch(EntityType.WITCH, entityIn.level);
        }else if(entityIn instanceof WitherSkeleton){
            predictionEntity = new WitherSkeleton(EntityType.WITHER_SKELETON, entityIn.level);
        }else if(entityIn instanceof ZombieVillager){
            predictionEntity = new ZombieVillager(EntityType.ZOMBIE_VILLAGER, entityIn.level);
        }else if(entityIn instanceof Zombie || entityIn instanceof Husk){
            predictionEntity = new Husk(EntityType.HUSK, entityIn.level);
        }else if(entityIn instanceof Skeleton){
            predictionEntity = new Skeleton(EntityType.SKELETON, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.BOW));
        }else if(entityIn instanceof Spider){
            predictionEntity = new Spider(EntityType.SPIDER, entityIn.level);
        }else if(entityIn instanceof Creeper){
            predictionEntity = new Creeper(EntityType.CREEPER, entityIn.level);
        }else if(entityIn instanceof Stray){
            predictionEntity = new Stray(EntityType.STRAY, entityIn.level);
            predictionEntity.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.BOW));
        }else if(entityIn instanceof IronGolem){
            predictionEntity = new IronGolem(EntityType.IRON_GOLEM, entityIn.level);
        }else if(entityIn instanceof EnderMan){
            predictionEntity = new EnderMan(EntityType.ENDERMAN, entityIn.level);
        }else if(entityIn instanceof CaveSpider){
            predictionEntity = new CaveSpider(EntityType.CAVE_SPIDER, entityIn.level);
        }

        if(predictionEntity != null){
            predictionEntity.restoreFrom(entityIn);
            predictionEntity.setGlowingTag(true);
            predictionEntity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 42069420, 1));
            //predictionEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 42069420, 0)); //hehe big number
            predictionEntity.setInvulnerable(true);
            predictionEntity.setSilent(true);
            if(predictionEntity instanceof Monster){
                    ((Monster) predictionEntity).setTarget(null);
            }
            predictionEntity.setLastHurtByMob(null);

            entityIn.setInvulnerable(true);
            teleportNearby(predictionEntity);
            level.addFreshEntity(predictionEntity);

            if(entityIn instanceof Player){
                Stand.getLazyOptional(((Player) entityIn)).ifPresent(stand -> {
                    stand.setExperiencingTimeSkip(true);
                });
            }

            pairList.add(new EpitaphPairing(entityIn, predictionEntity));
        }
    }

    @Override
    public void onMasterAttacked(Entity damager, float damage) {
        if(!level.isClientSide()) {
            if (epitaphTicks > 0) {
                epitaphTicks = -1;
                timeEraseDuration = 0;
                controller.cancelActiveMoves();
                epitaphFlag = true;
                startTimeSkip();
            }
        }
    }

    @Override
    public void onHit(LivingEntity entity, float damage) {
        if(this.getController().isMoveActive()){
            if(getController().getActiveMove().getId() == 5){
                MobEffectInstance debuffEffect = new MobEffectInstance(EffectInit.STAND_WEAKNESS.get(), 80, 1);
                entity.addEffect(debuffEffect);
            }
        }
    }

    class EpitaphPairing{
        private final LivingEntity predicted;
        private final LivingEntity prediction;

        public EpitaphPairing(LivingEntity predictedIn, LivingEntity predictionIn){
            predicted = predictedIn;
            prediction = predictionIn;
        }

        public LivingEntity getPredicted(){
            return predicted;
        }

        public LivingEntity getPrediction(){
            return prediction;
        }
    }

    public boolean verify(LivingEntity livingEntityIn){
        for(EpitaphPairing pair : pairList){
            if(pair.getPredicted().equals(livingEntityIn) || pair.getPrediction().equals(livingEntityIn)){
                return false;
            }
        }
        return true;
    }

    @Override
    public int getJabMoveId(){
        if(epitaphEndingOpportunityTicks > 0){
            return 10;
        }
        return 1;
    }


}