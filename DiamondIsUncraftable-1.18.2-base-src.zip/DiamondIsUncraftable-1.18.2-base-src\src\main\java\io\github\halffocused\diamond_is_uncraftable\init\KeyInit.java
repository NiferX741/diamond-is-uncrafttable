package io.github.halffocused.diamond_is_uncraftable.init;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.ClientRegistry;
import org.lwjgl.glfw.GLFW;

public class KeyInit {
    private static final String KEY_CATEGORY = "key.categories." + DiamondIsUncraftable.MOD_ID;
    public static final KeyMapping SPAWN_STAND = new KeyMapping("key.spawnstand.desc", GLFW.GLFW_KEY_V, KEY_CATEGORY);
    public static final KeyMapping TOGGLE_ABILITY = new KeyMapping("key.ability.desc", GLFW.GLFW_KEY_Y, KEY_CATEGORY);
    public static final KeyMapping ABILITY1 = new KeyMapping("key.ability2.desc", GLFW.GLFW_KEY_X, KEY_CATEGORY);
    public static final KeyMapping ABILITY2 = new KeyMapping("key.ability3.desc", GLFW.GLFW_KEY_Z, KEY_CATEGORY);
    public static final KeyMapping ABILITY3 = new KeyMapping("key.ability4.desc", GLFW.GLFW_KEY_R, KEY_CATEGORY);
    public static final KeyMapping SWITCH_ACT = new KeyMapping("key.switchact.desc", GLFW.GLFW_KEY_B, KEY_CATEGORY);
    public static final KeyMapping SWITCH_TARGETING = new KeyMapping("key.switchtarget.desc", GLFW.GLFW_KEY_C, KEY_CATEGORY);

    public static void register() {
        ClientRegistry.registerKeyBinding(SPAWN_STAND);
        ClientRegistry.registerKeyBinding(TOGGLE_ABILITY);
        ClientRegistry.registerKeyBinding(ABILITY1);
        ClientRegistry.registerKeyBinding(ABILITY2);
        ClientRegistry.registerKeyBinding(ABILITY3);
        ClientRegistry.registerKeyBinding(SWITCH_ACT);
        ClientRegistry.registerKeyBinding(SWITCH_TARGETING);
    }
}
