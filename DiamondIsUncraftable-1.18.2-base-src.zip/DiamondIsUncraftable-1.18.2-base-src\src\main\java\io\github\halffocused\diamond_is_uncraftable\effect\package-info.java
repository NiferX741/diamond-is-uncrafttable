@ParametersAreNonnullByDefault
package io.github.halffocused.diamond_is_uncraftable.effect;


import javax.annotation.ParametersAreNonnullByDefault;