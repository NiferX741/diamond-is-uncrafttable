package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.client.entity.model.PurpleHazeModel;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.PurpleHazeEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import javax.annotation.Nullable;

public class PurpleHazeRenderer extends GeoEntityRenderer<PurpleHazeEntity> {


    public PurpleHazeRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new PurpleHazeModel()); }

    @Override
    public ResourceLocation getTextureLocation(PurpleHazeEntity entity) {
        return new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/stands/purple_haze.png");
    }

}

