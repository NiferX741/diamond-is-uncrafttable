package io.github.halffocused.diamond_is_uncraftable.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;

@SuppressWarnings("deprecation")
public class StandEnergyGUI extends GuiComponent {
    public static final Minecraft mc = Minecraft.getInstance();

    public void renderEnergyBar(PoseStack stack) {

        Player player = mc.player;
        int scaledWidth = mc.getWindow().getGuiScaledWidth();
        int scaledHeight = mc.getWindow().getGuiScaledHeight();
        int x = scaledWidth / 2;
        if (mc.level == null) return;
        if (player == null) return;
        Stand.getLazyOptional(player).ifPresent(stand -> {
            if(stand.getStandOn()) {
                RenderSystem.setShaderTexture(0, new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/gui/energy_meter.png"));
                int i = (int) stand.getMaxStandEnergy();
                if (i > 0) {
                    int j = 182;
                    int k = (int) ((stand.getCurrentStandEnergy() / stand.getMaxStandEnergy()) * 183.0F);
                    int l = scaledHeight - 32 + 3;
                    this.blit(stack, x - 91, l, 0, 64, 182, 5);
                    if (k > 0) {
                        this.blit(stack, x - 91, l, 0, 69, k, 5);
                    }
                }


                String s = "" + (int) stand.getCurrentStandEnergy();
                int i1 = (scaledWidth - mc.font.width(s)) / 2;
                int j1 = scaledHeight - 32 - 3;
                mc.font.draw(stack, s, (float) (i1 + 1), (float) j1, 0);
                mc.font.draw(stack, s, (float) (i1 - 1), (float) j1, 0);
                mc.font.draw(stack, s, (float) i1, (float) (j1 + 1), 0);
                mc.font.draw(stack, s, (float) i1, (float) (j1 - 1), 0);
                mc.font.draw(stack, s, (float) i1, (float) j1, 15823613); //8453920

                if (Util.StandID.MOMENTUM_METER_STANDS.contains(stand.getStandID())) {
                    RenderSystem.setShaderTexture(0, new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/gui/momentum_meter.png"));
                    i = 100;
                    if (i > 0) {
                        int j = 182;
                        int k = (int) ((stand.getMomentum() / 100.0) * 183.0F);
                        int l = scaledHeight - 37 - 8;
                        this.blit(stack, x - 91, l, 0, 64, 182, 5);
                        if (k > 0) {
                            this.blit(stack, x - 91, l, 0, 69, k, 5);
                        }
                    }

                    s = "" + (int) stand.getMomentum();
                    i1 = (scaledWidth - mc.font.width(s)) / 2;
                    j1 = scaledHeight - 39 - 12;
                    mc.font.draw(stack, s, (float) (i1 + 1), (float) j1, 0);
                    mc.font.draw(stack, s, (float) (i1 - 1), (float) j1, 0);
                    mc.font.draw(stack, s, (float) i1, (float) (j1 + 1), 0);
                    mc.font.draw(stack, s, (float) i1, (float) (j1 - 1), 0);
                    mc.font.draw(stack, s, (float) i1, (float) j1, stand.getMomentum() > 50.0 ? 7464704 : 16738665); //8453920
                }
            }else{ //Stand off energy display
                if(stand.getCurrentStandEnergy() / stand.getMaxStandEnergy() != 1){
                    String s = "" + (int) stand.getCurrentStandEnergy();
                    int i1 = (scaledWidth - mc.font.width(s)) / 2;
                    int j1 = scaledHeight - 32 - 12;
                    mc.font.draw(stack, s, (float) (i1 + 1), (float) j1, 0);
                    mc.font.draw(stack, s, (float) (i1 - 1), (float) j1, 0);
                    mc.font.draw(stack, s, (float) i1, (float) (j1 + 1), 0);
                    mc.font.draw(stack, s, (float) i1, (float) (j1 - 1), 0);
                    mc.font.draw(stack, s, (float) i1, (float) j1, 15823613); //8453920
                }
            }
        });

    }
}
