package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.StickyFingersEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStickyFingersDisguisePacket implements IMessage<SSyncStickyFingersDisguisePacket> {
    private int standID;
    private int entityID;

    public SSyncStickyFingersDisguisePacket() {
    }

    public SSyncStickyFingersDisguisePacket(int standID, int entityID) {
        this.standID = standID;
        this.entityID = entityID;
    }

    @Override
    public void encode(SSyncStickyFingersDisguisePacket message, FriendlyByteBuf buffer) {
        buffer.writeInt(message.standID);
        buffer.writeInt(message.entityID);
    }

    @Override
    public SSyncStickyFingersDisguisePacket decode(FriendlyByteBuf buffer) {
        return new SSyncStickyFingersDisguisePacket(buffer.readInt(), buffer.readInt());
    }

    @Override
    public void handle(SSyncStickyFingersDisguisePacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                ClientLevel world = Minecraft.getInstance().level;
                if (world == null) return;
                Entity stand = world.getEntity(message.standID);
                if (message.entityID != -100) {
                    Entity entity = world.getEntity(message.entityID);
                    if (stand instanceof StickyFingersEntity && entity instanceof LivingEntity)
                        ((StickyFingersEntity) stand).disguiseEntity = (LivingEntity) entity;
                } else if (stand instanceof StickyFingersEntity)
                    ((StickyFingersEntity) stand).disguiseEntity = null;
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
