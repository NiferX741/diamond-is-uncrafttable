package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.client.entity.model.StickyFingersModel;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.StickyFingersEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class StickyFingersRenderer extends AbstractStandRenderer<StickyFingersEntity, StickyFingersModel> {
    public StickyFingersRenderer(EntityRendererProvider.Context renderManagerIn) {
        super(renderManagerIn, new StickyFingersModel());
    }

    @Override
    public void render(StickyFingersEntity entityIn, float entityYaw, float partialTicks, PoseStack matrixStackIn, MultiBufferSource bufferIn, int packedLightIn) {
        if (entityIn.disguiseEntity == null)
            super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
    }

    @Override
    public ResourceLocation getTextureLocation(StickyFingersEntity entity) {
        return Util.ResourceLocations.STICKY_FINGERS;
    }
}

