package io.github.halffocused.diamond_is_uncraftable;

import io.github.halffocused.diamond_is_uncraftable.capability.*;
import io.github.halffocused.diamond_is_uncraftable.command.impl.StandCommand;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.event.loot.DesertChestModifier;
import io.github.halffocused.diamond_is_uncraftable.init.*;
import io.github.halffocused.diamond_is_uncraftable.network.message.PacketHandler;
import io.github.halffocused.diamond_is_uncraftable.particle.ParticleList;
import io.github.halffocused.diamond_is_uncraftable.proxy.ClientProxy;
import io.github.halffocused.diamond_is_uncraftable.proxy.IProxy;
import io.github.halffocused.diamond_is_uncraftable.proxy.ServerProxy;
import net.minecraft.data.DataGenerator;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.data.GlobalLootModifierProvider;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.common.loot.LootTableIdCondition;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.forge.event.lifecycle.GatherDataEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.ObjectHolder;
import software.bernie.geckolib3.GeckoLib;

/**
 * @author HalfFocused
 * <p>
 * The main {@link Mod} class, used mostly for registering objects.
 * Much respect to Novarch for being the beginning of this project!!
 * After he left, I took over, so you may see conflicting coding styles and old systems lurking around.
 */
@Mod("diamond_is_uncraftable")
public class DiamondIsUncraftable {
    public static final IProxy PROXY = DistExecutor.safeRunForDist(() -> ClientProxy::new, () -> ServerProxy::new);
    public static final String MOD_ID = "diamond_is_uncraftable";
    public static final ResourceLocation STRUCTURE = new ResourceLocation(MOD_ID, "desert_structure");
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );
    private static final DeferredRegister<GlobalLootModifierSerializer<?>> GLOBAL_LOOT_MODIFIER = DeferredRegister.create(ForgeRegistries.Keys.LOOT_MODIFIER_SERIALIZERS, MOD_ID);

    private static final RegistryObject<DesertChestModifier.Serializer> DESERT_LOOT = GLOBAL_LOOT_MODIFIER.register("desert_loot", DesertChestModifier.Serializer::new);

    public DiamondIsUncraftable() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        IEventBus forgeBus = MinecraftForge.EVENT_BUS;
        modBus.addListener(this::setup);
        forgeBus.addListener(this::registerCommands); //FMLServerStartingEvent is fired on the Forge bus.

        EventInit.registerForgeBus(MinecraftForge.EVENT_BUS);
        ItemInit.ITEMS.register(modBus);
        EntityInit.ENTITY_TYPES.register(modBus);
        SoundInit.SOUNDS.register(modBus);
        ParticleList.PARTICLES.register(modBus);
        EffectInit.EFFECTS.register(modBus);
        GeckoLib.initialize();
        DiamondIsUncraftableConfig.register(ModLoadingContext.get());
        GLOBAL_LOOT_MODIFIER.register(FMLJavaModLoadingContext.get().getModEventBus());
        modBus.register(this);
        modBus.addListener(this::onAttributeCreate);
        modBus.addListener(this::onCapabilityRegister);
    }

    private void onCapabilityRegister(RegisterCapabilitiesEvent event) {
        event.register(Stand.class);
        event.register(Timestop.class);
        event.register(StandEffects.class);
        event.register(StandChunkEffects.class);
        event.register(StandPlayerEffects.class);
        event.register(StandTileEntityEffects.class);
        event.register(StandPerWorldCapability.class);
        event.register(CombatCapability.class);
        event.register(WorldTimestopCapability.class);
        event.register(BitesTheDustCapability.class);
    }

    private void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(EntityInit.KILLER_QUEEN.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.KILLER_QUEEN_BTD.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.SILVER_CHARIOT.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.THE_WORLD.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.KING_CRIMSON.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.PURPLE_HAZE.get(), AbstractStandEntity.setCustomAttributes().build());
        event.put(EntityInit.STICKY_FINGERS.get(), AbstractStandEntity.setCustomAttributes().build());
    }

    private static class DataProvider extends GlobalLootModifierProvider {
        public DataProvider(DataGenerator gen, String modid) {
            super(gen, modid);
        }

        @Override
        protected void start() {
            add("dungeon_loot", DESERT_LOOT.get(), new DesertChestModifier(
                    new LootItemCondition[]{LootTableIdCondition.builder(new ResourceLocation("arrow_in_desert_structure")).build()}, ItemInit.STAND_ARROW.get())
            );
        }
    }

    private void setup(FMLCommonSetupEvent event) {
        Stand.register();
        Timestop.register();
        StandEffects.register();
        StandChunkEffects.register();
        StandPlayerEffects.register();
        StandTileEntityEffects.register();
        PacketHandler.register();
        StandPerWorldCapability.register();
        CombatCapability.register();
        WorldTimestopCapability.register();
        BitesTheDustCapability.register();
    }

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class EventHandlers {
        @SubscribeEvent
        public static void runData(GatherDataEvent event)
        {
            event.getGenerator().addProvider(new DataProvider(event.getGenerator(), MOD_ID));
        }
    }

    private void registerCommands(RegisterCommandsEvent event){
        StandCommand.register(event.getDispatcher());
    }

        public static class JojoItemGroup extends CreativeModeTab {
        public static final CreativeModeTab INSTANCE = new JojoItemGroup();

        private JojoItemGroup() {
            super(MOD_ID);
        }

        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ItemInit.STAND_ARROW.get());
        }

        @Override
        public boolean hasSearchBar() {
            return true;
        }
    }
}
