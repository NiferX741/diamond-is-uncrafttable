package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.WorldTimestopCapability;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncWorldTimestopCapability implements IMessage<SSyncWorldTimestopCapability> {
    private Tag data;

    public SSyncWorldTimestopCapability() {
    }

    private SSyncWorldTimestopCapability(CompoundTag compoundNBT) {
        data = compoundNBT;
    }

    public SSyncWorldTimestopCapability(WorldTimestopCapability props) {
        data = WorldTimestopCapability.STORAGE.writeNBT(WorldTimestopCapability.WORLD, props, null);
    }

    @Override
    public SSyncWorldTimestopCapability decode(FriendlyByteBuf buffer) {
        return new SSyncWorldTimestopCapability(buffer.readNbt());
    }

    @Override
    public void handle(SSyncWorldTimestopCapability message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                Level world = DiamondIsUncraftable.PROXY.getWorld();
                if(world == null) return;
                WorldTimestopCapability.getLazyOptional(world).ifPresent(props -> WorldTimestopCapability.STORAGE.readNBT(WorldTimestopCapability.WORLD, props, null, message.data));
            });
        }
        ctx.get().setPacketHandled(true);
    }

    @Override
    public void encode(SSyncWorldTimestopCapability message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
    }
}
