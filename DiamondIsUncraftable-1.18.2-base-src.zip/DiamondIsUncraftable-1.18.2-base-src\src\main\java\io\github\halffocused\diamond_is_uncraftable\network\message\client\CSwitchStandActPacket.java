package io.github.halffocused.diamond_is_uncraftable.network.message.client;

import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CSwitchStandActPacket implements IMessage<CSwitchStandActPacket> {
    @Override
    public void encode(CSwitchStandActPacket message, FriendlyByteBuf buffer) {
    }

    @Override
    public CSwitchStandActPacket decode(FriendlyByteBuf buffer) {
        return new CSwitchStandActPacket();
    }

    @Override
    public void handle(CSwitchStandActPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_SERVER) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ctx.get().getSender();
                if (sender == null) return;
                Stand.getLazyOptional(sender).ifPresent(stand -> {
                    if (stand.getStandOn()) {
                        stand.changeAct();
                        Util.setupActSwitch(sender, stand.getStandID(), stand.getAct());
                    }
                });
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
