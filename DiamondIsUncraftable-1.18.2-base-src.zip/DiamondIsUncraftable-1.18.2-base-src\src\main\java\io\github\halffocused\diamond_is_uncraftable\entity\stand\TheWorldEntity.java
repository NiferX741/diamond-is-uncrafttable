package io.github.halffocused.diamond_is_uncraftable.entity.stand;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.ChargeAttackFormat;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.HoveringMoveHandler;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.MovementAnimationHolder;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.TimestopHelper;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.common.Mod;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

@SuppressWarnings("ConstantConditions")
@Mod.EventBusSubscriber(modid = DiamondIsUncraftable.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class TheWorldEntity extends AbstractStandEntity implements IMomentum, IOverrideChargeAttack, IOnMasterAttacked {
    public static long dayTime = -1, gameTime = -1;
    /**
     * A list of every {@link TheWorldEntity} in the {@link Level}, used to cancel events and unfreeze entities on logout.
     */
    private static ArrayBlockingQueue<TheWorldEntity> theWorldList = new ArrayBlockingQueue<>(1000000);
    public int timestopTick;
    public boolean shouldDamageBeCancelled;
    public boolean cooldown;
    boolean timeStopped = false;
    public static final int QUICK_STOP_DURATION = 4 + 2;
    int noTeleportPeriod = 0;
    private ArrayList<Player> timestoppedPlayers = new ArrayList<>();

    public HoveringMoveHandler getController(){
        return controller;
    }
    
    private ArrayBlockingQueue<BlockPos> brokenBlocks = new ArrayBlockingQueue<>(100000);

    public TheWorldEntity(EntityType<? extends AbstractStandEntity> type, Level level) {
        super(type, level);
    }

    ChargeAttackFormat chargeAttack = new ChargeAttackFormat("taunt")
            .addChargeNode(11, 3, true);

    AttackFramedata punchData = new AttackFramedata(19)
            .addDamageFrame(7, 3, Vec3.ZERO, 2.1, 2)
            .addDamageFrame(9, 4, Vec3.ZERO, 2.2, 2);

    AttackFramedata tauntTp = new AttackFramedata(1)
            .addMessageFrame(1, 1,null, null);

    AttackFramedata barrageData = new AttackFramedata(125)
                        .generateInterval(10, 125, 2, 2, Vec3.ZERO, 1.7, 6);

    AttackFramedata timestop = new AttackFramedata(62)
            .addMessageFrame(45, 1, null, null)
            .addMenacingFrame(45);

    HoveringMoveHandler controller = new HoveringMoveHandler(this)
            .addMove("Jab",1, punchData, "jab", 1.6)
            .addMove("Barrage",2, barrageData, "MUDA", HoveringMoveHandler.RepositionConstants.MASTER_POSITION)
            .addMove("Taunt",3, tauntTp, null, -1)
            .addMove("Timestop", 4, timestop, "timestop", 2)
            .addChargeAttack(chargeAttack);

    public static ArrayBlockingQueue<TheWorldEntity> getTheWorldList() {
        return theWorldList;
    }

    public void timeStop() {
        if (getMaster() == null) return;
        if (attacking) return;

        if(timeStopped){
            timeStopped = false;
            TimestopHelper.endTimeStop(master);
        }else{
            Stand.getLazyOptional(master).ifPresent(props -> {
                if (spendEnergy(10)) {
                    controller.setMoveActive(4);
                }
            });
        }
    }

    public void teleport(){

        if(!level.isClientSide){

            if(!timeStopped && noTeleportPeriod == 0 && spendEnergy(40)) {
                level.playSound(null, blockPosition(), SoundInit.THE_WORLD_TELEPORT.get(), SoundSource.NEUTRAL, 1, 1);

                master.fallDistance = 0;
                Util.teleportUntilWall(master, master.getLookAngle(), 4);
                Stand.getLazyOptional(master).ifPresent(stand -> {
                    stand.setInstantTimeStopFrame(QUICK_STOP_DURATION);
                });
            }
        }
    }

    public void addBrokenBlocks(BlockPos pos) {
        brokenBlocks.add(pos);
    }

    @Override
    public SoundEvent getSpawnSound() {
        return SoundInit.SUMMON_STAND.get();
    }

    @Override
    public void playSpawnSound() {
        Stand.getLazyOptional(getMaster()).ifPresent(props -> {
            if (!props.getAbility())
                level.playSound(null, getMaster().blockPosition(), SoundInit.THE_WORLD_SUMMON.get(), SoundSource.NEUTRAL, 2, 1);
        });
    }

    public ArrayBlockingQueue<BlockPos> getBrokenBlocks() {
        return brokenBlocks;
    }

    @Override
    public void tick() {
        super.tick();
        if (getMaster() != null && !level.isClientSide()) {

            noTeleportPeriod = Math.max(0, noTeleportPeriod - 1);

            Stand.getLazyOptional(master).ifPresent(props2 -> {


                if (controller.isMoveActive()) {
                    if (controller.getActiveMove().getId() == 2 && controller.getActiveMove().getFramedata().getTicker() > 10) {

                        if(props2.getMomentum() == 0){
                            Style warningStyle = Style.EMPTY.applyFormat(ChatFormatting.RED);
                            TextComponent warning = new TextComponent("The Level needs momentum to perform it's barrage!");
                            warning.setStyle(warningStyle);
                            master.displayClientMessage(warning, false);
                        }

                        props2.setMomentum(Math.max(0, props2.getMomentum() - 1));

                        if (props2.getMomentum() == 0) {
                            controller.cancelActiveMoves();
                        }

                    }
                }
                if(timeStopped){
                    TimestopHelper.timeStopTick(master);
                    if(!spendEnergy((9.0/20), true)){
                        timeStopped = false;
                        TimestopHelper.endTimeStop(master);
                    }
                }
                props2.setPreventUnsummon2(timeStopped);
            });
        }
    }

    @Override
    public void onRemovedFromWorld() {
        super.onRemovedFromWorld();
        timeStopped = false;
        TimestopHelper.endTimeStop(master);
    }

    @Override
    public double addMomentumAmount() {

        if(controller.isMoveActive()){
            if(controller.getActiveMove().getId() == 2 || TimestopHelper.isTimeStopped(level, master.blockPosition())){
                return 0;
            }
        }

        return 7;
    }

    @Override
    public double getMomentumDrainRate() {
        return 2;
    }


    @Override
    public MovementAnimationHolder getMovementAnimations(){
        return new MovementAnimationHolder().create("idle", "foward", "right2", "right", "backwards");
        //Can this mf ever spell every animation name properly????????????? "foward"
    }

    @Override
    public int getJabMoveId() {
        return 1;
    }

    @Override
    public int getBarrageMoveId() {
        return 2;
    }

    @Override
    public void messageFrame(int message1, Object message2, Object message3) {
        if(message1 == 1){
            if(!level.isClientSide()) {
                level.playSound(null, blockPosition(), SoundInit.THE_WORLD_TIME_STOP.get(), SoundSource.NEUTRAL, 1, 1);
                timeStopped = true;
            }
        }
    }

    private void sendToTauntPosition(LivingEntity entityIn, float tauntChargeTicks){
        double tauntDistance = getTauntDistance((int) tauntChargeTicks);
        Vec3 modifiedPositionVec = new Vec3(master.getX(), entityIn.getY(), master.getZ());
        Vec3 vec = entityIn.position().subtract(modifiedPositionVec).normalize();
        Util.teleportUntilWall(entityIn, vec, tauntDistance);

        entityIn.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 5, 1));
        entityIn.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 1));

        if(entityIn instanceof Player){
            Util.applyUnactionableTicks(((Player) entityIn), 20);

            Stand.getLazyOptional(((Player) entityIn)).ifPresent(effect -> {
                effect.setInstantTimeStopFrame(QUICK_STOP_DURATION);
            });
        }
    }

    @Override
    public void chargeAttackRelease(int ticksCharged) {
        if(!TimestopHelper.isTimeStopped(level, master.blockPosition())) {

            level.playSound(null, blockPosition(), SoundInit.THE_WORLD_TELEPORT.get(), SoundSource.NEUTRAL, 1, 1);
            if (getTauntDistance(ticksCharged) > 0) {

                Stand.getLazyOptional(master).ifPresent(effect -> {
                    effect.setInstantTimeStopFrame(QUICK_STOP_DURATION);
                });

                java.util.stream.StreamSupport.stream(getServer().getLevel(level.dimension()).getAllEntities().spliterator(), false)
                        .filter(entity -> !entity.equals(master) && !entity.equals(this))
                        .filter(entity -> entity instanceof LivingEntity)
                        .filter(entity -> entity.distanceTo(master) <= 7)
                        .forEach(entity -> sendToTauntPosition((LivingEntity) entity, ticksCharged));
            }
        }
    }

    @Override
    public TextComponent generateHudText(int ticksCharged) {

        double tauntDistance = getTauntDistance(ticksCharged);

        if(!spendEnergy(0.35) || ticksCharged > 199){
            controller.forceChargeAttackRelease();
        }

        Style distanceStyle = Style.EMPTY.applyFormat(ChatFormatting.GRAY).withBold(true);

        DecimalFormat format = new DecimalFormat("0.0");

        TextComponent returnValue = ticksCharged < 15 ? new TextComponent("Charging...") : new TextComponent(format.format(tauntDistance) + " Blocks");
        returnValue.setStyle(distanceStyle);

        return returnValue;
    }

    @Override
    public boolean shouldAllowChargeAttack() {
        return true;
    }

    @Override
    public void onMasterAttacked(Entity damager, float damage) {

        noTeleportPeriod = 40;

        if(controller.isMoveActive()){
            if(controller.getActiveMove().getId() == 4){
                controller.cancelActiveMoves();
                penalizeEnergy(30);
            }
        }
    }

    private double getTauntDistance(int ticks){
        return ticks < 15 ? 0 : Math.min(ticks / 12.0, 8);
    }

    @Override
    public float getDamageSharingPercentage(){
        return 0.65f;
    }
}
