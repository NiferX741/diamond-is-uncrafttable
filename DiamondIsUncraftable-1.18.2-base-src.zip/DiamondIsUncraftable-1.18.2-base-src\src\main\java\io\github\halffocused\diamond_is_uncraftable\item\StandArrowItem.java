package io.github.halffocused.diamond_is_uncraftable.item;


import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.capability.StandPerWorldCapability;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.StandArrowEntity;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.init.ItemInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Objects;

public class StandArrowItem extends ArrowItem {
    final int standID;
    final TextComponent tooltip;
    final TextComponent description;
    final String tooltip2;
    boolean newSystem;

    public StandArrowItem(Properties properties, int standID, ItemInit.StandArrowTooltip tooltip) {
        super(properties);
        this.standID = standID;
        this.description = tooltip.getDescription();
        this.tooltip = tooltip.getMoveset();
        this.tooltip2 = null;
        newSystem = true;
    }

    public StandArrowItem(Properties properties, int standID, String tooltip) {
        super(properties);
        this.standID = standID;
        this.tooltip = null;
        this.description = null;
        this.tooltip2 = tooltip;
        newSystem = false;
    }

    @SuppressWarnings("ConstantConditions")
    @Override //TODO add an animation when obtaining GER
    public void releaseUsing(ItemStack stack, Level world, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player)) return;
        if(!world.isClientSide()) {
            Player player = (Player) entity;
            Stand.getLazyOptional(player).ifPresent(stand -> {
                int random;
                StandPerWorldCapability standPerWorld = StandPerWorldCapability.getCapabilityFromWorld(world.getServer().getLevel(entity.level.dimension()));
                int newStandID;
                if(DiamondIsUncraftableConfig.COMMON.uniqueStandMode.get()) {


                    if (standPerWorld.getTakenStandIDs().size() == Util.StandID.STANDS.length) {
                        player.displayClientMessage(new TextComponent("There are no more available stands!"), true);
                        return;
                    }

                    do {
                        random = world.random.nextInt(Util.StandID.STANDS.length);
                    } while (standPerWorld.getTakenStandIDs().contains(random));
                }else{
                    random = world.random.nextInt(Util.StandID.STANDS.length);
                }

                if (standID == 0)
                    newStandID = Util.StandID.STANDS[random];
                else
                    newStandID = standID;

                if (stand.getStandID() == 0) {
                    if (!player.isCreative())
                        stack.shrink(1);
                    stand.setStandID(newStandID);
                    if(DiamondIsUncraftableConfig.COMMON.uniqueStandMode.get()) {
                        standPerWorld.addTakenStandId(random);
                    }
                    stand.setStandOn(true);
                    final AbstractStandEntity standEntity = Util.StandID.getStandByID(newStandID, world);
                    if (standEntity != null) { //Can be null if Stand is The Emperor or Beach Boy
                        standEntity.moveTo(player.getX() + 0.1, player.getY(), player.getZ(), player.getYRot(), player.getXRot());
                        standEntity.setMasterUUID(player.getUUID());
                        standEntity.setMaster(player);
                        world.addFreshEntity(standEntity);
                    }
                }
            });
        }
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level worldIn, Player playerIn, InteractionHand handIn) {
        ItemStack stack = playerIn.getItemInHand(handIn);
        Stand stand = Stand.getCapabilityFromPlayer(playerIn);
        if (!Stand.getLazyOptional(playerIn).isPresent()) return InteractionResultHolder.fail(stack);
        if (stand.getStandID() == 0) {
            playerIn.startUsingItem(handIn);
            return InteractionResultHolder.success(stack);
        } else if (stand.getStandID() != 0) {
            playerIn.displayClientMessage(new TextComponent("You already have a Stand!"), true);
            return InteractionResultHolder.fail(stack);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level worldIn, List<Component> tooltip, TooltipFlag flagIn) {
        if (standID != 0) {
            if (!newSystem && (Util.isClientHoldingShift() && !this.tooltip2.equals("")) || newSystem && (Util.isClientHoldingShift() && !tooltip.isEmpty()))
                tooltip.add(newSystem ? this.tooltip : new TextComponent(this.tooltip2));
            else if (!Util.isClientHoldingShift())
                tooltip.add(description);
                tooltip.add(new TextComponent("Hold\u00A7e Shift\u00A7f for moveset!"));
        } else
            tooltip.add(newSystem ? this.tooltip : new TextComponent(this.tooltip2));
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.isAllowedOnBooks();
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public int getEnchantmentValue() {
        return 1;
    }

    @Override
    public UseAnim getUseAnimation(final ItemStack itemStack) {
        return UseAnim.BOW;
    }

    @Override
    public int getUseDuration(final ItemStack itemStack) {
        return 7200;
    }

    @Override
    public boolean isInfinite(ItemStack stack, ItemStack bow, Player shooter) {
        return false;
    }

    @Override
    public AbstractArrow createArrow(Level world, ItemStack stack, LivingEntity entity) {
        return new StandArrowEntity(world, entity);
    }

}