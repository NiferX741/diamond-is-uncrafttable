package io.github.halffocused.diamond_is_uncraftable.capability;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandEffectsCapabilityPacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import static io.github.halffocused.diamond_is_uncraftable.util.Util.Null;

public class StandEffects implements ICapabilitySerializable<Tag> {
    public static final Capability<StandEffects> STAND_EFFECTS = CapabilityManager.get(new CapabilityToken<>(){});
    public static CapStorage<StandEffects> STORAGE;
    private final Entity entity;
    private boolean aging;
    private Vec3 motion = Vec3.ZERO;
    private boolean bomb;
    private UUID standUser = UUID.fromString("c9362041-f5e8-447c-80a8-9db27a2646bb");
    private boolean rotating;
    private byte soundEffect;
    private boolean threeFreeze;
    private double timeNearFlames;
    private BlockPos bitesTheDustPos = BlockPos.ZERO;
    private int remainingTicks = -1;
    private Map<ChunkPos, Map<BlockPos, BlockState>> destroyedBlocks = new ConcurrentHashMap<>();
    private boolean shouldBeRemoved;
    private int hitstun;
    private Map<ChunkPos, ArrayBlockingQueue<BlockPos>> alteredTileEntities = new ConcurrentHashMap<>();
    private LazyOptional<StandEffects> holder = LazyOptional.of(() -> new StandEffects(getEntity()));

    public StandEffects(Entity entity) {
        this.entity = entity;
    }

    public static LazyOptional<StandEffects> getLazyOptional(Entity entity) {
        return entity.getCapability(STAND_EFFECTS);
    }

    public static StandEffects getCapabilityFromEntity(Entity entity) {
        return entity.getCapability(STAND_EFFECTS).orElse(new StandEffects(entity));
    }

    public static void register() {
        STORAGE = new CapStorage<StandEffects>() {
            @Override
            public Tag writeNBT(Capability<StandEffects> capability, StandEffects instance, Direction side) {
                CompoundTag nbt = new CompoundTag();
                nbt.putBoolean("aging", instance.aging);
                nbt.putDouble("motionX", instance.motion.x);
                nbt.putDouble("motionY", instance.motion.y);
                nbt.putDouble("motionZ", instance.motion.z);
                nbt.putBoolean("bomb", instance.bomb);
                nbt.putUUID("standUser", instance.standUser);
                nbt.putBoolean("rotating", instance.rotating);
                nbt.putByte("soundEffect", instance.soundEffect);
                nbt.putBoolean("threeFreeze", instance.threeFreeze);
                nbt.putDouble("timeNearFlames", instance.timeNearFlames);
                nbt.putDouble("bitesTheDustX", instance.bitesTheDustPos.getX());
                nbt.putDouble("bitesTheDustY", instance.bitesTheDustPos.getY());
                nbt.putDouble("bitesTheDustZ", instance.bitesTheDustPos.getZ());
                nbt.putInt("hitstun", instance.hitstun);
                nbt.putLong("timeOfDeath", instance.remainingTicks);
                nbt.putBoolean("shouldBeRemoved", instance.shouldBeRemoved);
                ListTag destroyedBlocks = new ListTag();
                instance.destroyedBlocks.forEach((pos, list) -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putInt("chunkPosX", pos.x);
                    compoundNBT.putInt("chunkPosZ", pos.z);
                    ListTag listNBT = new ListTag();
                    list.forEach((blockPos, blockState) -> {
                        CompoundTag compound = new CompoundTag();
                        compound.putDouble("blockPosX", blockPos.getX());
                        compound.putDouble("blockPosY", blockPos.getY());
                        compound.putDouble("blockPosZ", blockPos.getZ());
                        compound.putInt("blockState", Block.getId(blockState));
                        listNBT.add(compound);
                    });
                    compoundNBT.put("blockPosList", listNBT);
                    destroyedBlocks.add(compoundNBT);
                });
                nbt.put("destroyedBlocks", destroyedBlocks);
                ListTag alteredTileEntities = new ListTag();
                instance.alteredTileEntities.forEach((pos, blockPosList) -> {
                    CompoundTag compoundNBT = new CompoundTag();
                    compoundNBT.putInt("chunkPosX", pos.x);
                    compoundNBT.putInt("chunkPosZ", pos.z);
                    ListTag listNBT = new ListTag();
                    blockPosList.forEach(blockPos -> {
                        CompoundTag compound = new CompoundTag();
                        compound.putDouble("blockPosX", blockPos.getX());
                        compound.putDouble("blockPosY", blockPos.getY());
                        compound.putDouble("blockPosZ", blockPos.getZ());
                        listNBT.add(compound);
                    });
                    compoundNBT.put("blockPosList", listNBT);
                    alteredTileEntities.add(compoundNBT);
                });
                nbt.put("alteredTileEntities", alteredTileEntities);
                return nbt;
            }

            @Override
            public void readNBT(Capability<StandEffects> capability, StandEffects instance, Direction side, Tag nbt) {
                CompoundTag compoundNBT = (CompoundTag) nbt;
                instance.aging = compoundNBT.getBoolean("aging");
                instance.motion = new Vec3(compoundNBT.getDouble("motionX"), compoundNBT.getDouble("motionY"), compoundNBT.getDouble("motionZ"));
                instance.bomb = compoundNBT.getBoolean("bomb");
                instance.standUser = compoundNBT.getUUID("standUser");
                instance.rotating = compoundNBT.getBoolean("rotating");
                instance.soundEffect = compoundNBT.getByte("soundEffect");
                instance.threeFreeze = compoundNBT.getBoolean("threeFreeze");
                instance.timeNearFlames = compoundNBT.getDouble("timeNearFlames");
                instance.hitstun = compoundNBT.getInt("hitstun");
                instance.bitesTheDustPos = new BlockPos(compoundNBT.getDouble("bitesTheDustX"), compoundNBT.getDouble("bitesTheDustY"), compoundNBT.getDouble("bitesTheDustZ"));
                instance.remainingTicks = compoundNBT.getInt("timeOfDeath");
                instance.shouldBeRemoved = compoundNBT.getBoolean("shouldBeRemoved");
                compoundNBT.getList("destroyedBlocks", Tag.TAG_COMPOUND).forEach(compound -> {
                    if (compound instanceof CompoundTag && ((CompoundTag) compound).contains("chunkPosX")) {
                        Map<BlockPos, BlockState> map = new ConcurrentHashMap<>();
                        ((CompoundTag) compound).getList("blockPosList", Tag.TAG_COMPOUND).forEach(inbt -> {
                            if (inbt instanceof CompoundTag && ((CompoundTag) inbt).contains("blockPosX"))
                                map.put(new BlockPos(((CompoundTag) compound).getDouble("blockPosX"), ((CompoundTag) compound).getDouble("blockPosY"), ((CompoundTag) compound).getDouble("blockPosZ")), Block.stateById(compoundNBT.getInt("blockState")));
                        });
                        instance.destroyedBlocks.put(new ChunkPos(((CompoundTag) compound).getInt("chunkPosX"), ((CompoundTag) compound).getInt("chunkPosX")), map);
                    }
                });
                compoundNBT.getList("alteredTileEntities", Tag.TAG_COMPOUND).forEach(compound -> {
                    if (compound instanceof CompoundTag && ((CompoundTag) compound).contains("chunkPosX")) {
                        ArrayBlockingQueue<BlockPos> blockPosList = new ArrayBlockingQueue<>(1000);
                        ((CompoundTag) compound).getList("blockPosList", Tag.TAG_COMPOUND).forEach(inbt -> {
                            if (inbt instanceof CompoundTag && ((CompoundTag) inbt).contains("blockPosX"))
                                blockPosList.add(new BlockPos(((CompoundTag) compound).getDouble("blockPosX"), ((CompoundTag) compound).getDouble("blockPosY"), ((CompoundTag) compound).getDouble("blockPosZ")));
                        });
                        instance.alteredTileEntities.put(new ChunkPos(((CompoundTag) compound).getInt("chunkPosX"), ((CompoundTag) compound).getInt("chunkPosX")), blockPosList);
                    }
                });
            }
        };
    }

    public boolean isShouldBeRemoved() {
        return shouldBeRemoved;
    }

    public void setShouldBeRemoved(boolean shouldBeRemoved) {
        this.shouldBeRemoved = shouldBeRemoved;
        onDataUpdated();
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == STAND_EFFECTS ? holder.cast() : LazyOptional.empty();
    }

    @Override
    public Tag serializeNBT() {
        return STORAGE.writeNBT(STAND_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null);
    }

    @Override
    public void deserializeNBT(Tag nbt) {
        STORAGE.readNBT(STAND_EFFECTS, holder.orElseThrow(() -> new IllegalArgumentException("LazyOptional is empty!")), null, nbt);
    }

    public Entity getEntity() {
        return entity;
    }

    public boolean isAging() {
        return aging;
    }

    public void setAging(boolean aging) {
        this.aging = aging;
        onDataUpdated();
    }

    public Vec3 getDeltaMovement() {
        return motion;
    }

    public void setDeltaMovement(Vec3 motion) {
        this.motion = motion;
        onDataUpdated();
    }

    public boolean isBomb() {
        return bomb;
    }

    public void setBomb(boolean bomb) {
        this.bomb = bomb;
    }

    public UUID getStandUser() {
        return standUser;
    }

    public void setStandUser(UUID standUser) {
        this.standUser = standUser;
        onDataUpdated();
    }



    public boolean isRotating() {
        return rotating;
    }

    public void setRotating(boolean rotating) {
        this.rotating = rotating;
        onDataUpdated();
    }

    public byte getSoundEffect() {
        return soundEffect;
    }

    public void setSoundEffect(byte soundEffect) {
        this.soundEffect = soundEffect;
        onDataUpdated();
    }

    public boolean isThreeFreeze() {
        return threeFreeze;
    }

    public void setThreeFreeze(boolean threeFreeze) {
        this.threeFreeze = threeFreeze;
        onDataUpdated();
    }

    public double getTimeNearFlames() {
        return timeNearFlames;
    }

    public void setTimeNearFlames(double timeNearFlames) {
        this.timeNearFlames = timeNearFlames;
        onDataUpdated();
    }

    public BlockPos getBitesTheDustPos() {
        return bitesTheDustPos;
    }

    public void setBitesTheDustPos(BlockPos bitesTheDustPos) {
        this.bitesTheDustPos = bitesTheDustPos;
        onDataUpdated();
    }

    public int getRemainingTicks() {
        return remainingTicks;
    }

    public void setRemainingTicks(int timeOfDeath) {
        this.remainingTicks = timeOfDeath;
        onDataUpdated();
    }

    public Map<ChunkPos, Map<BlockPos, BlockState>> getDestroyedBlocks() {
        return destroyedBlocks;
    }

    public void putDestroyedBlock(@Nonnull ChunkPos pos, @Nonnull BlockPos blockPos, @Nonnull BlockState state) {
        if (!destroyedBlocks.containsKey(pos)) {
            Map<BlockPos, BlockState> map = new ConcurrentHashMap<>();
            map.put(blockPos, state);
            destroyedBlocks.put(pos, map);
        } else
            destroyedBlocks.get(pos).put(blockPos, state);
        onDataUpdated();
    }

    public void removeDestroyedBlock(@Nonnull ChunkPos pos, @Nonnull BlockPos blockPos) {
        destroyedBlocks.get(pos).remove(blockPos);
        onDataUpdated();
    }

    public Map<ChunkPos, ArrayBlockingQueue<BlockPos>> getAlteredTileEntities() {
        return alteredTileEntities;
    }

    public void putAlteredTileEntity(@Nonnull ChunkPos pos, @Nonnull BlockPos blockPos) {
        if (!alteredTileEntities.containsKey(pos)) {
            ArrayBlockingQueue<BlockPos> list = new ArrayBlockingQueue<>(1000);
            list.add(blockPos);
            alteredTileEntities.put(pos, list);
        } else
            alteredTileEntities.get(pos).add(blockPos);
        onDataUpdated();
    }

    public void onDataUpdated() {
        if (!entity.level.isClientSide)
            DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity), new SSyncStandEffectsCapabilityPacket(this));
    }
}
