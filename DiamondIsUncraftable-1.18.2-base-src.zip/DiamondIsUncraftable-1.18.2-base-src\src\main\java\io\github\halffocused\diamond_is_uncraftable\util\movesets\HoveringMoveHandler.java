package io.github.halffocused.diamond_is_uncraftable.util.movesets;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SAnimatePacket;
import io.github.halffocused.diamond_is_uncraftable.util.*;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.TimestopHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.ChatFormatting;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;

public class HoveringMoveHandler {

    String currentAnimation;

    final static int chargeAttackBuffer = 5; //how long an input has to be held for the charge attack to register.
    final int barWidth = 20; //Width of the bars that appear in the action bar. 20 was my first instinct and I have liked it the most.

    boolean standHasAttackPosition;

    int chargeTicks;
    boolean pilotMode;
    int prevChargeTicks;
    String lastAnimation = "";

    public static class RepositionConstants{
        public static final int MASTER_POSITION = -1;
        public static final int IDLE_POSITION = -2;
        public static final int DO_NOT_MOVE = -3;
    }


    int unactionableTicks = 0;
    int unactionableTicksLastTick;

    int masterKeybindInput = 0;

    int mostRecentChargeAttackTicks = 0;

    /*
    Charge attack variables.
     */
    boolean hasChargeAttack = false;
    ChargeAttackFormat chargeAttackFormat = null;
    boolean forceChargeAttackRelease = false;

    ArrayList<Move> moveList = new ArrayList<>();

    private final AbstractStandEntity stand;


    public HoveringMoveHandler(AbstractStandEntity standIn){
        stand = standIn;
        pilotMode = false;
    }

    public HoveringMoveHandler(AbstractStandEntity standIn, boolean pilotModeIn){
        stand = standIn;
        pilotMode = pilotModeIn;
    }

    public void tick(boolean attackKeyDown, boolean specialKeyDown){
        if(stand.level.isClientSide){return;}
        Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {

            if(Util.isTimeStoppedForEntity(stand.getMaster()) || props.getExperiencingTimeSkip()){
                setUnactionableTicks(1);
            }

            if(stand instanceof IMomentum){
                if(!props.getExperiencingTimeStop() || Util.canStandMoveInStoppedTime(props.getStandID()))
                props.setMomentum(Math.max(0, props.getMomentum() - (((IMomentum) stand).getMomentumDrainRate() / 20.0)));
            }

            handleAnimations();
            handleInputs(attackKeyDown, specialKeyDown);
            handleActionBar(specialKeyDown);
        });


        for(Move move : moveList){ //Tick active moves
            if(move.getFramedata().isActive()){
                move.getFramedata().attackTick(stand);
            }
        }

        Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {
            props.setPreventUnsummon(isMoveActive());

            if(unactionableTicks > 0){
                props.setPreventUnsummon3(true);
            }else if (unactionableTicksLastTick > 0){
                props.setPreventUnsummon3(false);
            }
        });



        unactionableTicksLastTick = unactionableTicks;
        unactionableTicks = Math.max(unactionableTicks - 1, 0);

        if (isMoveActive()) {
            if(getActiveMove().getRepositionDistance() > 0 && !standHasAttackPosition){
                stand.goToAttackPosition(getActiveMove().getRepositionDistance());
                standHasAttackPosition = true;
            }else if(getActiveMove().getRepositionDistance() == RepositionConstants.MASTER_POSITION){
                stand.setPos(stand.getMaster().getX(), stand.getMaster().getY(), stand.getMaster().getZ());
                stand.setYHeadRot(stand.getMaster().yHeadRot);
                stand.setYRot(stand.getMaster().getYRot());
                stand.setXRot(stand.getMaster().getXRot());
            }else if(getActiveMove().getRepositionDistance() == RepositionConstants.IDLE_POSITION){
                stand.followMaster();
                stand.setYHeadRot(stand.getMaster().yHeadRot);
                stand.setYRot(stand.getMaster().getYRot());
                stand.setXRot(stand.getMaster().getXRot());
            }
        }else{
            stand.followMaster();
            stand.setYHeadRot(stand.getMaster().yHeadRot);
            stand.setYRot(stand.getMaster().getYRot());
                stand.setXRot(stand.getMaster().getXRot());
        }

    }

    public boolean isMoveActive(){
        for(Move move : moveList){
            if(move.getFramedata().isActive()){
                return true;
            }
        }
        return false;
    }

    public Move getActiveMove(){
        for(Move move : moveList){
            if(move.getFramedata().isActive()){
                return move;
            }
        }
        return null;
    }

     public void setMoveActive(int id){
        if(unactionableTicks == 0) {
            for (Move move : moveList) {
                if (move.getId() == id) {
                    move.getFramedata().initAttack();

                    Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {
                        props.setPreventUnsummon(true);
                    });
                }
            }
        }
    }

    public Move getMoveById(int id){
        for (Move move : moveList) {
            if (move.getId() == id) {
                return move;
            }
        }
        return null;
    }

    public void cancelActiveMoves(){
        for (Move move : moveList) {
            if (move.getFramedata().isActive()) {
                move.getFramedata().setActive(false);

                Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {
                    props.setPreventUnsummon(false);
                });
            }
        }
    }

    public HoveringMoveHandler addMove(String nameIn, int idIn, AttackFramedata frameIn, String animationIn){
        moveList.add(new Move(nameIn, frameIn, animationIn, idIn));
        return this;
    }

    public HoveringMoveHandler addMove(String nameIn, int idIn, AttackFramedata frameIn,String animationIn, double repositionDistanceIn){
        moveList.add(new Move(nameIn, frameIn, animationIn, idIn, repositionDistanceIn));
        return this;
    }

    public HoveringMoveHandler addChargeAttack(ChargeAttackFormat formatIn){
        chargeAttackFormat = formatIn;
        chargeAttackFormat.setMoveHandler(this);
        hasChargeAttack = true;
        return this;
    }

    public void setAnimation(String animationNameIn, boolean shouldLoop){
        if(!stand.level.isClientSide) {
            if(!animationNameIn.equals(lastAnimation)) {
                DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> stand), new SAnimatePacket(stand.getId(), animationNameIn, shouldLoop));
                currentAnimation = animationNameIn;
                lastAnimation = animationNameIn;
            }
        }
    }

    public void setMasterInputKeybind(int inputIn){
        masterKeybindInput = inputIn;
    }

    private void handleAnimations(){

        Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {

            if(TimestopHelper.isTimeStopped(stand.getMaster().level, stand.getMaster())){
                setAnimation("timestuck", true);
            }else{
                MovementAnimationHolder movementAnimations = stand.getMovementAnimations();

                if (isMoveActive()) {
                    if (getActiveMove().getAnimation() != null) { //moves with null as their animation will play the movement animations
                        setAnimation(getActiveMove().animation, true);
                    } else {
                        if (stand.getMaster().isSprinting()) {
                            setAnimation(movementAnimations.forwardAnimation, true);
                        } else if (this.masterKeybindInput == 0) {
                            setAnimation(movementAnimations.backwardsAnimation, true);
                        } else if (this.masterKeybindInput == 2) {
                            setAnimation(movementAnimations.rightAnimation, true);
                        } else if (this.masterKeybindInput == 1) {
                            setAnimation(movementAnimations.leftAnimation, true);
                        } else if (this.masterKeybindInput == 3) {
                            setAnimation(movementAnimations.idleAnimation, true);
                        }
                    }
                } else if (hasChargeAttack && chargeTicks > chargeAttackBuffer) {
                    if (chargeAttackFormat.isComplexCharge()) {
                        if (chargeAttackFormat.getAnimation1Duration() > chargeTicks - chargeAttackBuffer + chargeAttackBuffer) {
                            setAnimation(chargeAttackFormat.getChargingAnimation(), true);
                        } else {
                            setAnimation(chargeAttackFormat.getChargingAnimation2(), true);
                        }
                    } else {
                        setAnimation(chargeAttackFormat.chargingAnimation, true);
                    }
                } else {
                    if (stand.getMaster().isSprinting()) {
                        setAnimation(movementAnimations.forwardAnimation, true);
                    } else if (this.masterKeybindInput == 0) {
                        setAnimation(movementAnimations.backwardsAnimation, true);
                    } else if (this.masterKeybindInput == 2) {
                        setAnimation(movementAnimations.rightAnimation, true);
                    } else if (this.masterKeybindInput == 1) {
                        setAnimation(movementAnimations.leftAnimation, true);
                    } else if (this.masterKeybindInput == 3) {
                        setAnimation(movementAnimations.idleAnimation, true);
                    }
                }
            }
        });

    }

    private void handleInputs(boolean attackKey, boolean specialKey) {
            Stand.getLazyOptional(stand.getMaster()).ifPresent(props -> {
                props.setCharging(attackKey);
                boolean allowChargeAttack = !(stand instanceof IOverrideChargeAttack) || (((IOverrideChargeAttack) stand).shouldAllowChargeAttack() || chargeTicks != 0);

                if (attackKey && (chargeTicks < chargeAttackBuffer || allowChargeAttack)) {
                        prevChargeTicks = chargeTicks;
                        chargeTicks++;
                } else {
                    prevChargeTicks = chargeTicks;
                    chargeTicks = 0;
                }
            });

        if(isMoveActive())
            chargeTicks = 0;

        if(chargeAttackFormat != null){
            if(chargeAttackFormat.checkForInvoluntary(chargeTicks)){
                chargeTicks = 0;
            }
        }
        if(forceChargeAttackRelease){
            chargeTicks = 0;
        }
        forceChargeAttackRelease = false;
        if (chargeTicks == 0 && chargeTicks != prevChargeTicks && !isMoveActive()) {

            standHasAttackPosition = false;
            int outgoingChargeAttackTicks = prevChargeTicks;

            if(outgoingChargeAttackTicks <= chargeAttackBuffer){
                if(specialKey){
                    setMoveActive(stand.getBarrageMoveId());
                }else{
                    setMoveActive(stand.getJabMoveId());
                }
            }else if (chargeAttackFormat != null){
                if(stand instanceof IOverrideChargeAttack){
                    ((IOverrideChargeAttack) stand).chargeAttackRelease(prevChargeTicks);
                }else {
                    if (chargeAttackFormat.getMoveToActivate(prevChargeTicks) != -1) {
                        setMoveActive(chargeAttackFormat.getMoveToActivate(prevChargeTicks));
                    }
                }
            }
        }
    }

    public void forceChargeAttackRelease(){
        forceChargeAttackRelease = true;
    }

    public boolean isActionable(){
        return !isMoveActive() && unactionableTicks == 0;
    }

    public void setUnactionableTicks(int ticksIn){
        if(unactionableTicks == 0){
            cancelActiveMoves();
        }
        unactionableTicks = ticksIn;
    }

    public void setMostRecentChargeAttackTicks(int tickIn){
        mostRecentChargeAttackTicks = tickIn;
    }

    public int getMostRecentChargeAttackTicks(){
        return mostRecentChargeAttackTicks;
    }

    private void handleActionBar(boolean isShiftKeyDown){

        //I am the only person who sees this code and understands it.

        //Update: There is no one left who sees this code and understands it.

        Player master = stand.getMaster();
        TextComponent actionText = new TextComponent("");
        Style moveNameStyle = Style.EMPTY.applyFormat(ChatFormatting.GRAY).withBold(true);
        Style menacingMoveNameStyle = Style.EMPTY.applyFormat(ChatFormatting.LIGHT_PURPLE).withBold(true).withItalic(true);
        Style notationStyle = Style.EMPTY.applyFormat(ChatFormatting.GRAY).withBold(false);
        Style actionBarBracketStyle = Style.EMPTY.applyFormat(ChatFormatting.BLACK).withBold(true);
        Style positiveStyle = Style.EMPTY.applyFormat(ChatFormatting.GREEN).withBold(false);
        Style negativeStyle = Style.EMPTY.applyFormat(ChatFormatting.RED).withBold(false);
        Style sneakIndicatorOffStyle = Style.EMPTY.applyFormat(ChatFormatting.DARK_RED).withBold(true);
        Style sneakIndicatorOnStyle = Style.EMPTY.applyFormat(ChatFormatting.GREEN).withBold(true);
        if(isMoveActive()){
            actionText.append(new TextComponent(getActiveMove().getName()).setStyle(getActiveMove().isMenacing() ? menacingMoveNameStyle : moveNameStyle));
            actionText.append(new TextComponent(" [").setStyle(actionBarBracketStyle));
            for(int i = 0; i < barWidth; i++){
                if(lerp(0,barWidth, (double) getActiveMove().getFramedata().getTicker() / getActiveMove().getFramedata().getAttackDuration()) > i){
                    actionText.append(new TextComponent("|").setStyle(positiveStyle));
                }else{
                    actionText.append(new TextComponent("|").setStyle(negativeStyle));
                }
            }
            actionText.append(new TextComponent("] ").setStyle(actionBarBracketStyle));
        }else if(hasChargeAttack && chargeTicks > chargeAttackBuffer){

            if(stand instanceof IOverrideChargeAttack){
                actionText = ((IOverrideChargeAttack) stand).generateHudText(chargeTicks);
            }else{
                if (chargeAttackFormat.getMoveToActivate(chargeTicks) != -1) {
                    actionText.append(new TextComponent(getMoveById(chargeAttackFormat.getMoveToActivate(chargeTicks)).getName()).setStyle(moveNameStyle));
                }

                if (chargeAttackFormat.getFollowingNode(chargeTicks) != null) {
                    actionText.append(new TextComponent(" [").setStyle(actionBarBracketStyle));

                    for (int i = 0; i < barWidth; i++) {

                        if (chargeAttackFormat.getNodeToActivate(chargeTicks) != null) {
                            if (lerp(0, barWidth, (double) (chargeTicks - chargeAttackFormat.getNodeToActivate(chargeTicks).tick) / ((chargeAttackFormat.getFollowingNode(chargeTicks).tick) - chargeAttackFormat.getNodeToActivate(chargeTicks).tick)) > i) {
                                actionText.append(new TextComponent("|").setStyle(positiveStyle));
                            } else {
                                actionText.append(new TextComponent("|").setStyle(negativeStyle));
                            }
                        } else {
                            if (lerp(0, barWidth, ((double) chargeTicks) / chargeAttackFormat.getFollowingNode(chargeTicks).tick) > i) {
                                actionText.append(new TextComponent("|").setStyle(positiveStyle));
                            } else {
                                actionText.append(new TextComponent("|").setStyle(negativeStyle));
                            }
                        }


                    }
                    actionText.append(new TextComponent("]-> ").setStyle(actionBarBracketStyle));
                    actionText.append(new TextComponent(getMoveById(chargeAttackFormat.getFollowingNode(chargeTicks).moveOnRelease).getName()).setStyle(moveNameStyle));
                }
            }
        }else if(isActionable()){
            actionText.append(new TextComponent("[Sneak]").setStyle(isShiftKeyDown ? sneakIndicatorOnStyle : sneakIndicatorOffStyle));
            actionText.append(new TextComponent(" Left-Click: ").setStyle(notationStyle));

            if(isShiftKeyDown){
                if(getMoveById(stand.getBarrageMoveId()) != null) {
                    actionText.append(new TextComponent(getMoveById(stand.getBarrageMoveId()).getName()).setStyle(moveNameStyle));
                }
            }else{
                if(getMoveById(stand.getJabMoveId()) != null) {
                    actionText.append(new TextComponent(getMoveById(stand.getJabMoveId()).getName()).setStyle(moveNameStyle));
                }
            }
        }else{
            String timer = ((unactionableTicks / 20.0) + "").substring(0, 3).concat("s");
            actionText.append(new TextComponent("Not Actionable" + (unactionableTicks > 1 ? ": " + timer : "")).setStyle(sneakIndicatorOffStyle));
        }

        master.displayClientMessage(actionText, true);
    }

    private double lerp(int min, int max, double value)
    {
        return min + value * (max - min);
    }
}
