package io.github.halffocused.diamond_is_uncraftable.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.LiteralCommandNode;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.TextComponent;

@SuppressWarnings("unused")
public class StandCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralCommandNode<CommandSourceStack> literalCommandNode = dispatcher.register(Commands.literal("stand")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("set")
                        .then(Commands.argument("target", EntityArgument.player())
                                .then(Commands.literal("king_crimson")
                                        .executes(context -> setPlayerStandID(context.getSource(), EntityArgument.getPlayer(context, "target"), Util.StandID.KING_CRIMSON)))
                                .then(Commands.literal("killer_queen")
                                        .executes(context -> setPlayerStandID(context.getSource(), EntityArgument.getPlayer(context, "target"), Util.StandID.KILLER_QUEEN)))
                                .then(Commands.literal("the_world")
                                        .executes(context -> setPlayerStandID(context.getSource(), EntityArgument.getPlayer(context, "target"), Util.StandID.THE_WORLD)))
                                .then(Commands.literal("silver_chariot")
                                        .executes(context -> setPlayerStandID(context.getSource(), EntityArgument.getPlayer(context, "target"), Util.StandID.SILVER_CHARIOT)))
                                .then(Commands.literal("sticky_fingers")
                                        .executes(context -> setPlayerStandID(context.getSource(), EntityArgument.getPlayer(context, "target"), Util.StandID.STICKY_FINGERS)))
                        ))
                .then(Commands.literal("remove")
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(context -> removePlayerStand(context.getSource(), EntityArgument.getPlayer(context, "target")))
                        ))

                .then(Commands.literal("evolve")
                        .then(Commands.argument("target", EntityArgument.player())
                                .executes(context -> evolvePlayerStand(context.getSource(), EntityArgument.getPlayer(context, "target")))
                        ))

        );
    }

    private static int setPlayerStandID(CommandSourceStack source, Player target, int standID) {
        Stand stand = Stand.getCapabilityFromPlayer(target);
        if (stand.getStandID() != standID) {
            stand.removeStand(false);
            stand.setStandID(standID);
            stand.setStandOn(false);
            source.sendSuccess(new TextComponent("Successfully set StandID for " + target.getDisplayName().getString() + "."), true);
        } else
            source.sendFailure(new TextComponent(target.getDisplayName().getString() + " already has that Stand."));
        return stand.getStandID();
    }

    private static int removePlayerStand(CommandSourceStack source, Player target) {
        Stand props = Stand.getCapabilityFromPlayer(target);
        if (props.getStandID() != 0) {
            props.removeStand(false);
            source.sendSuccess(new TextComponent("Successfully removed Stand from " + target.getDisplayName().getString() + "."), true);
        } else
            source.sendFailure(new TextComponent(target.getDisplayName() + " does not have a Stand."));
        return 1;
    }

    private static int evolvePlayerStand(CommandSourceStack source, Player target) {
        Stand stand = Stand.getCapabilityFromPlayer(target);
        int standID = 0;
        switch (stand.getStandID()) {
            default: {
                source.sendFailure(new TextComponent(target.getDisplayName().getString() + "'s Stand cannot be evolved."));
                break;
            }
            case 0: {
                source.sendFailure(new TextComponent(target.getDisplayName().getString() + " does not have a Stand."));
                break;
            }
            case Util.StandID.KILLER_QUEEN: {
                standID = Util.StandID.KILLER_QUEEN_BTD;
                break;
            }
        }
        if (standID != 0) {
            stand.removeStand(true);
            stand.setStandOn(false);
            stand.setStandID(standID);
            source.sendSuccess(new TextComponent("Successfully evolved " + target.getDisplayName().getString() + "'s Stand."), true);
        }
        return stand.getStandID();
    }
}
