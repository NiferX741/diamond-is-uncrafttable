package io.github.halffocused.diamond_is_uncraftable.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.GuiUtils;

@SuppressWarnings("deprecation")
public class MomentumMeterGUI extends GuiComponent {
    public static final Minecraft mc = Minecraft.getInstance();

    public void renderMeter() {
        Player player = mc.player;
        int posX = mc.getWindow().getGuiScaledWidth() - 180, posY = (mc.getWindow().getGuiScaledHeight() - 256) / 2;

        if (mc.level == null) return;
        if (player == null) return;
        Stand.getLazyOptional(player).ifPresent(props -> {
            if (props.getStandID() == Util.StandID.THE_WORLD && props.getStandOn()) {
                PoseStack stack = new PoseStack();
                RenderSystem.enableBlend();
                stack.translate(posX, posY, 0);
                RenderSystem.setShaderTexture(0, new ResourceLocation(DiamondIsUncraftable.MOD_ID, "textures/gui/momentum_meter.png"));
                GuiUtils.drawTexturedModalRect(stack, 0, 0, 0, 0, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(), 0);
            }
        });
    }
}
