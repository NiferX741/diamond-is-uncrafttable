package io.github.halffocused.diamond_is_uncraftable.util;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.client.entity.model.*;
import io.github.halffocused.diamond_is_uncraftable.client.entity.render.*;
import io.github.halffocused.diamond_is_uncraftable.event.EventClientTick;
import io.github.halffocused.diamond_is_uncraftable.event.EventHandleKeybinds;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.init.KeyInit;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = DiamondIsUncraftable.MOD_ID, bus = Bus.MOD, value = Dist.CLIENT)
public class ClientEventBusSubscriber {
    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        KeyInit.register();
        MinecraftForge.EVENT_BUS.register(EventHandleKeybinds.class);
        MinecraftForge.EVENT_BUS.register(EventClientTick.class);

        event.enqueueWork(() -> {
        EntityRenderers.register(EntityInit.KING_CRIMSON.get(), KingCrimsonRenderer::new);

        EntityRenderers.register(EntityInit.KILLER_QUEEN.get(), KillerQueenRenderer::new);
        EntityRenderers.register(EntityInit.KILLER_QUEEN_BTD.get(), KillerQueenBitesTheDustRenderer::new);

        EntityRenderers.register(EntityInit.SHEER_HEART_ATTACK.get(), SheerHeartAttackRenderer::new);

        EntityRenderers.register(EntityInit.PURPLE_HAZE.get(), PurpleHazeRenderer::new);

        EntityRenderers.register(EntityInit.THE_WORLD.get(), TheWorldRenderer::new);

        EntityRenderers.register(EntityInit.SILVER_CHARIOT.get(), SilverChariotRenderer::new);
        EntityRenderers.register(EntityInit.SILVER_CHARIOT_SWORD.get(), manager -> new StandAttackRenderer<>(manager, new SilverChariotSwordModel()));

        EntityRenderers.register(EntityInit.STAND_ARROW.get(), StandArrowRenderer::new);

        EntityRenderers.register(EntityInit.EMERALD_SPLASH.get(), manager -> new EmeraldSplashRenderer(manager, Minecraft.getInstance().getItemRenderer())); //This renders as an emerald.

        EntityRenderers.register(EntityInit.STICKY_FINGERS.get(), StickyFingersRenderer::new);
        });

        EventClientTick.init(Minecraft.getInstance());
    }
}
