package io.github.halffocused.diamond_is_uncraftable.util;

import net.minecraft.network.chat.TextComponent;

public interface IOverrideChargeAttack {
    void chargeAttackRelease(int ticksCharged);

    TextComponent generateHudText(int ticksCharged);

    boolean shouldAllowChargeAttack();
}
