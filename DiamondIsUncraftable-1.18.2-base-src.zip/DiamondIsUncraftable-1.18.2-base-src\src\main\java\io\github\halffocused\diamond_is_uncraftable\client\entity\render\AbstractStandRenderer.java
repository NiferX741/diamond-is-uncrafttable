package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.world.entity.player.Player;

public abstract class AbstractStandRenderer<T extends AbstractStandEntity, M extends EntityModel<T>> extends MobRenderer<T, M> {
    public AbstractStandRenderer(EntityRendererProvider.Context manager, M model) {
        super(manager, model, 0);
    }

    @Override
    public void render(T entityIn, float entityYaw, float partialTicks, PoseStack matrixStackIn, MultiBufferSource bufferIn, int packedLightIn) {
        if (Minecraft.getInstance().getCameraEntity() instanceof AbstractStandEntity)
            super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
        else if (Minecraft.getInstance().getCameraEntity() instanceof Player)
            Stand.getLazyOptional((Player) Minecraft.getInstance().getCameraEntity()).ifPresent(props -> {
                if (props.getStandID() != 0)
                    super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
            });
    }
}
