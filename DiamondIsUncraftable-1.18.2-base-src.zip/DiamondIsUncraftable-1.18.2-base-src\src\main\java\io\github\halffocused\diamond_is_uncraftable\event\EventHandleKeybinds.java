package io.github.halffocused.diamond_is_uncraftable.event;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.Stand;
import io.github.halffocused.diamond_is_uncraftable.init.KeyInit;
import io.github.halffocused.diamond_is_uncraftable.network.message.client.*;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@Mod.EventBusSubscriber(modid = DiamondIsUncraftable.MOD_ID, bus = Bus.FORGE, value = Dist.CLIENT)
public class EventHandleKeybinds {
    @SubscribeEvent
    public static void onInput(TickEvent.ClientTickEvent event) { //It's recommended to use ClientTickEvent instead of any of the input events.
        if (event.phase != TickEvent.Phase.END || !Minecraft.getInstance().isWindowActive()) return;
        Minecraft mc = Minecraft.getInstance();

        if (mc.player != null) {
            if (KeyInit.SPAWN_STAND.isDown())
                DiamondIsUncraftable.INSTANCE.sendToServer(new CStandSummonPacket());

            if(KeyInit.SWITCH_TARGETING.isDown())
                DiamondIsUncraftable.INSTANCE.sendToServer(new CWalkingStandTargetPacket());

            if (KeyInit.TOGGLE_ABILITY.isDown())
                DiamondIsUncraftable.INSTANCE.sendToServer(new CToggleAbilityPacket());

            DiamondIsUncraftable.INSTANCE.sendToServer(new CChargeAttackPacket(mc.options.keyAttack.isDown(), mc.player.isCrouching()));


            Stand.getLazyOptional(mc.player).ifPresent(props -> {
                if (props.hasAct())
                    if (KeyInit.SWITCH_ACT.isDown())
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CSwitchStandActPacket());

                    if (KeyInit.ABILITY1.isDown())
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CSyncStandAbilitiesPacket((byte) 1));
                    if (KeyInit.ABILITY2.isDown())
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CSyncStandAbilitiesPacket((byte) 2));
                    if (KeyInit.ABILITY3.isDown())
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CSyncStandAbilitiesPacket((byte) 3));

                if (props.getStandOn()) {
                    if (mc.options.keyDown.isDown()) {
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CStandMasterMovementPacket(CStandMasterMovementPacket.Direction.BACKWARDS));
                    }else if (mc.options.keyRight.isDown()) {
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CStandMasterMovementPacket(CStandMasterMovementPacket.Direction.RIGHT));
                    }else if (mc.options.keyLeft.isDown()) {
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CStandMasterMovementPacket(CStandMasterMovementPacket.Direction.LEFT));
                    }else{
                        DiamondIsUncraftable.INSTANCE.sendToServer(new CStandMasterMovementPacket(CStandMasterMovementPacket.Direction.NOT_MOVING));
                    }
                }
            });

        }
    }
}
