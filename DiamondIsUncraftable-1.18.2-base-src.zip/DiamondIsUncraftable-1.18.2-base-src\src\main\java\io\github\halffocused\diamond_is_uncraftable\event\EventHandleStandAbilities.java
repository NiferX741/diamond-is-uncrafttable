package io.github.halffocused.diamond_is_uncraftable.event;

import io.github.halffocused.diamond_is_uncraftable.DiamondIsUncraftable;
import io.github.halffocused.diamond_is_uncraftable.capability.*;
import io.github.halffocused.diamond_is_uncraftable.config.DiamondIsUncraftableConfig;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.*;
import io.github.halffocused.diamond_is_uncraftable.entity.stand.attack.SheerHeartAttackEntity;
import io.github.halffocused.diamond_is_uncraftable.event.custom.StandAttackEvent;
import io.github.halffocused.diamond_is_uncraftable.event.custom.StandEvent;
import io.github.halffocused.diamond_is_uncraftable.init.EffectInit;
import io.github.halffocused.diamond_is_uncraftable.init.EntityInit;
import io.github.halffocused.diamond_is_uncraftable.init.ItemInit;
import io.github.halffocused.diamond_is_uncraftable.network.message.server.SSyncStandMasterPacket;
import io.github.halffocused.diamond_is_uncraftable.util.IOnMasterAttacked;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.BitesTheDustHelper;
import io.github.halffocused.diamond_is_uncraftable.util.globalabilities.TimestopHelper;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.HoneyBottleItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.item.ItemExpireEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.ExplosionEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static io.github.halffocused.diamond_is_uncraftable.util.globalabilities.BitesTheDustHelper.*;

@SuppressWarnings("ConstantConditions")
@Mod.EventBusSubscriber(modid = DiamondIsUncraftable.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class EventHandleStandAbilities {
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if(event.phase == TickEvent.Phase.START) {
            Player player = event.player;
            Stand.getLazyOptional(player).ifPresent(stand -> {

                if(stand.getInstantTimeStopFrame() > 0){
                    stand.setInstantTimeStopFrame(stand.getInstantTimeStopFrame() - 1);
                }
                if(stand.getTimeSkipEffectTicker() > 0){
                    stand.setTimeSkipEffectTicker(stand.getTimeSkipEffectTicker() - 1);
                }
                if(stand.getBitesTheDustEffectTicker() > 0){
                    stand.setBitesTheDustEffectTicker(stand.getBitesTheDustEffectTicker() - 1);
                }

                Random rand = player.level.random;
                int standID = stand.getStandID();
                boolean standOn = stand.getStandOn();
                double cooldown = stand.getCooldown();
                double timeLeft = stand.getTimeLeft();
                double invulnerableTicks = stand.getInvulnerableTicks();

                if (!player.level.isClientSide && stand.getGameTime() != -1 && stand.getGameTime() < player.level.getGameTime() - 24000) {
                    stand.setGameTime(-1);
                    stand.setDayTime(-1);
                    player.setHealth(player.getMaxHealth());
                    Util.loadedBlockEntities((net.minecraft.server.level.ServerLevel) player.level).stream()
                            .filter(tileEntity -> tileEntity instanceof BaseContainerBlockEntity && !tileEntity.getLevel().isClientSide)
                            .forEach(tileEntity -> StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
                                ((BaseContainerBlockEntity) tileEntity).clearContent();
                                if (tileEntity instanceof ChestBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getChestInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getChestInventory().get(i);
                                        ((ChestBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof AbstractFurnaceBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getFurnaceInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getFurnaceInventory().get(i);
                                        ((AbstractFurnaceBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getFurnaceInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof BrewingStandBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getBrewingInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getBrewingInventory().get(i);
                                        ((BrewingStandBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getBrewingInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof BarrelBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getBarrelInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getBarrelInventory().get(i);
                                        ((BarrelBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getBarrelInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof DispenserBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getDispenserInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getDispenserInventory().get(i);
                                        ((DispenserBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getDispenserInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof HopperBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getHopperInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getHopperInventory().get(i);
                                        ((HopperBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getHopperInventory().set(i, ItemStack.EMPTY);
                                    }
                                else if (tileEntity instanceof ShulkerBoxBlockEntity)
                                    for (int i = 0; i < standTileEntityEffects.getShulkerBoxInventory().size(); i++) {
                                        ItemStack stack = standTileEntityEffects.getShulkerBoxInventory().get(i);
                                        ((ShulkerBoxBlockEntity) tileEntity).setItem(i, stack);
                                        standTileEntityEffects.getShulkerBoxInventory().set(i, ItemStack.EMPTY);
                                    }
                                tileEntity.setChanged();
                            }));
                    java.util.stream.StreamSupport.stream(player.getServer().getLevel(player.level.dimension()).getAllEntities().spliterator(), false).forEach(entity -> {
                        if (entity instanceof Player && !entity.level.isClientSide)
                            StandPlayerEffects.getLazyOptional((Player) entity).ifPresent(standPlayerEffects -> {
                                ((Player) entity).getInventory().clearContent();
                                for (int i = 0; i < standPlayerEffects.getMainInventory().size(); i++) {
                                    ItemStack stack = standPlayerEffects.getMainInventory().get(i);
                                    ((Player) entity).getInventory().setItem(i, stack);
                                    standPlayerEffects.getMainInventory().set(i, ItemStack.EMPTY);
                                }
                                for (int i = 0; i < standPlayerEffects.getArmorInventory().size(); i++) {
                                    ItemStack stack = standPlayerEffects.getArmorInventory().get(i);
                                    ((Player) entity).getInventory().setItem(i + 36, stack);
                                    standPlayerEffects.getArmorInventory().set(i, ItemStack.EMPTY);
                                }
                                for (int i = 0; i < standPlayerEffects.getOffHandInventory().size(); i++) {
                                    ItemStack stack = standPlayerEffects.getOffHandInventory().get(i);
                                    ((Player) entity).getInventory().setItem(i + 40, stack);
                                    standPlayerEffects.getOffHandInventory().set(i, ItemStack.EMPTY);
                                }
                            });
                        StandEffects.getLazyOptional(entity).ifPresent(standEffects -> {
                            if (!standEffects.getAlteredTileEntities().isEmpty())
                                standEffects.getAlteredTileEntities().forEach((pos, blockPosList) ->
                                        blockPosList.forEach(blockPos -> {
                                            if (entity.level.getChunkSource().hasChunk(pos.x, pos.z))
                                                entity.level.getChunkSource().updateChunkForced(pos, true);
                                            BlockEntity tileEntity = entity.level.getBlockEntity(blockPos);
                                            if (!(tileEntity instanceof BaseContainerBlockEntity)) return;
                                            StandTileEntityEffects.getLazyOptional(tileEntity).ifPresent(standTileEntityEffects -> {
                                                ((BaseContainerBlockEntity) tileEntity).clearContent();
                                                if (tileEntity instanceof ChestBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getChestInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getChestInventory().get(i);
                                                        ((ChestBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getChestInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof AbstractFurnaceBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getFurnaceInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getFurnaceInventory().get(i);
                                                        ((AbstractFurnaceBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getFurnaceInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof BrewingStandBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getBrewingInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getBrewingInventory().get(i);
                                                        ((BrewingStandBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getBrewingInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof BarrelBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getBarrelInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getBarrelInventory().get(i);
                                                        ((BarrelBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getBarrelInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof DispenserBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getDispenserInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getDispenserInventory().get(i);
                                                        ((DispenserBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getDispenserInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof HopperBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getHopperInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getHopperInventory().get(i);
                                                        ((HopperBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getHopperInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                else if (tileEntity instanceof ShulkerBoxBlockEntity)
                                                    for (int i = 0; i < standTileEntityEffects.getShulkerBoxInventory().size(); i++) {
                                                        ItemStack stack = standTileEntityEffects.getShulkerBoxInventory().get(i);
                                                        ((ShulkerBoxBlockEntity) tileEntity).setItem(i, stack);
                                                        standTileEntityEffects.getShulkerBoxInventory().set(i, ItemStack.EMPTY);
                                                    }
                                                tileEntity.setChanged();
                                            });
                                        }));
                            if (standEffects.isShouldBeRemoved())
                                entity.discard();
                            if (entity instanceof ItemEntity && standEffects.getBitesTheDustPos() == BlockPos.ZERO)
                                entity.discard();
                            if (!standEffects.getDestroyedBlocks().isEmpty()) {
                                Map<BlockPos, BlockState> removalMap = new ConcurrentHashMap<>();
                                standEffects.getDestroyedBlocks().forEach((pos, list) -> {
                                    list.forEach((blockPos, blockState) -> {
                                        if (player.level.getChunkSource().hasChunk(pos.x, pos.z))
                                            player.level.getChunkSource().updateChunkForced(pos, true);
                                        player.level.setBlock(blockPos, blockState, 3);
                                        removalMap.put(blockPos, blockState);
                                    });
                                    if (!removalMap.isEmpty())
                                        removalMap.forEach(list::remove);
                                });
                            }
                            if (standEffects.getBitesTheDustPos() != BlockPos.ZERO) {
                                entity.teleportTo(standEffects.getBitesTheDustPos().getX(), standEffects.getBitesTheDustPos().getY(), standEffects.getBitesTheDustPos().getZ());
                                standEffects.setBitesTheDustPos(BlockPos.ZERO);
                            }
                        });
                    });
                    stand.setCooldown(36000);
                }

                if (invulnerableTicks > 0) {
                    stand.setInvulnerableTicks(stand.getInvulnerableTicks() - 0.5);
                    for (int i = 0; i < 10; i++)
                        player.level.addParticle(
                                ParticleTypes.DRAGON_BREATH,
                                player.getX() + (player.level.random.nextBoolean() ? rand.nextDouble() : -rand.nextDouble()),
                                player.getY() + player.level.random.nextDouble(),
                                player.getZ() + (player.level.random.nextBoolean() ? rand.nextDouble() : -rand.nextDouble()),
                                0, 0.3 + (rand.nextBoolean() ? 0.1 : -0.1), 0);
                    if (invulnerableTicks == 0.5)
                        stand.setCooldown(140);
                }

                if (stand.getEnergyCooldown() == 0) {
                    stand.setCurrentStandEnergy(Math.min(stand.getCurrentStandEnergy() + (stand.getEnergyRegenerationRate() / 20.0f), stand.getMaxStandEnergy()));
                } else {
                    stand.setEnergyCooldown(Math.max(0, stand.getEnergyCooldown() - 1));
                }

                if (standOn) {
                    stand.setStandUnsummonedTime(0);

                } else {
                    stand.setStandUnsummonedTime(Math.min(stand.getStandUnsummonedTime() + 1, (20 * 60 * 5))); //Shouldn't need to know more than like 5 minutes.
                }
                stand.setReflexCooldown(Math.max(0, stand.getReflexCooldown() - 1));
                stand.setInvincibleTicks(Math.max(0, stand.getInvincibleTicks() - 1));
                if(!player.level.isClientSide){
                    if(stand.getStandID() == Util.StandID.KILLER_QUEEN) {
                    java.util.stream.StreamSupport.stream(BlockPos.betweenClosed(player.blockPosition().offset(15, 15, 15), player.blockPosition().offset(-15, -15, -15)).spliterator(), false)
                            .forEach(blockPos -> {
                                if (player.level.getBlockEntity(blockPos) != null) {
                                    if (player.level.getBlockEntity(blockPos) instanceof BaseContainerBlockEntity) {
                                        BaseContainerBlockEntity tile = (BaseContainerBlockEntity) player.level.getBlockEntity(blockPos);
                                        for (int i = 0; i < tile.getContainerSize(); i++) {
                                            CompoundTag nbt = tile.getItem(i).getOrCreateTag();
                                            if (nbt.getBoolean("bomb") && nbt.getUUID("ownerUUID").equals(player.getUUID())) {
                                                Util.spawnClientParticle((ServerPlayer) player, 17, blockPos.getX() + 0.5, blockPos.getY() + 0.5, blockPos.getZ() + 0.5, 1, 2, 1, 1);
                                            }
                                        }
                                    }
                                }
                            });

                        java.util.stream.StreamSupport.stream(BlockPos.betweenClosed(player.blockPosition().offset(10, 10, 10), player.blockPosition().offset(-10, -10, -10)).spliterator(), false)
                                .filter(blockPos -> blockPos.equals(stand.getBlockPos()))
                                .filter(blockPos -> !blockPos.equals(BlockPos.ZERO))
                                .forEach(blockPos -> {
                                    Util.spawnClientParticle((ServerPlayer) player, 8, blockPos.getX() + 0.5, blockPos.getY() + 0.5, blockPos.getZ()+ 0.5, 1, 2, 1, 1);
                                });


                        java.util.stream.StreamSupport.stream(player.level.getServer().getLevel(player.level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity -> entity instanceof LivingEntity)
                            .filter(entity -> !entity.equals(player))
                            .filter(entity -> entity.distanceTo(player) < 20)
                            .forEach(entity -> {

                                if(entity.getId() == stand.getBombEntityId()){
                                    Util.spawnClientParticle((ServerPlayer) player, 8, entity.getX(), entity.getY() + 0.5, entity.getZ(), 1, 2, 1, 1);
                                }

                                if(entity instanceof Player){
                                    boolean hasItemBomb = false;
                                    for(ItemStack stack : ((Player) entity).getInventory().items){
                                        if(stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(player.getUUID())){
                                            hasItemBomb = true;
                                        }
                                    }
                                    for(ItemStack stack : ((Player) entity).getInventory().offhand){
                                        if(stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(player.getUUID())){
                                            hasItemBomb = true;
                                        }
                                    }
                                    for(ItemStack stack : ((Player) entity).getInventory().armor){
                                        if(stack.getOrCreateTag().getBoolean("bomb") && stack.getOrCreateTag().getUUID("ownerUUID").equals(player.getUUID())){
                                            hasItemBomb = true;
                                        }
                                    }
                                    if(hasItemBomb){
                                        Util.spawnClientParticle((ServerPlayer) player, 17, entity.getX(), entity.getY() + 0.5, entity.getZ(), 1, 2, 1, 1);
                                    }
                                    Player playerEntity = (Player) entity;

                                    for (int i = 0; i < playerEntity.getEnderChestInventory().getContainerSize(); i++) {
                                        if (playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().getBoolean("bomb") && playerEntity.getEnderChestInventory().getItem(i).getOrCreateTag().getUUID("ownerUUID").equals(player.getUUID())) {
                                            Util.spawnClientParticle((ServerPlayer) player, 18, entity.getX(), entity.getY() + 0.5, entity.getZ(), 1, 2, 1, 1);
                                        }
                                    }
                                }else {
                                    LivingEntity livingEntity = (LivingEntity) entity;
                                    for (ItemStack stack : livingEntity.getAllSlots()){
                                        CompoundTag nbt = stack.getOrCreateTag();
                                        if(nbt.getBoolean("bomb") && nbt.getUUID("ownerUUID").equals(player.getUUID())){
                                            Util.spawnClientParticle((ServerPlayer) player, 17, livingEntity.getX(), livingEntity.getY() + 0.5, livingEntity.getZ(), 1, 2, 1, 1);
                                        }
                                    }
                                }
                            });
                    }
                }
            });
        }
    }

    @SubscribeEvent
    public static void blockDestroyed(BlockEvent.BreakEvent event) {
        LivingEntity livingEntity = event.getPlayer();
        if (livingEntity == null) return;
        LevelChunk chunk = livingEntity.level.getChunkAt(livingEntity.blockPosition());
        StandEffects.getLazyOptional(livingEntity).ifPresent(standEffects -> {
            if (standEffects.getDestroyedBlocks().containsKey(chunk.getPos()) && standEffects.getDestroyedBlocks().get(chunk.getPos()).containsKey(event.getPos()))
                return;
            if (BitesTheDustHelper.bitesTheDustActive)
                standEffects.putDestroyedBlock(chunk.getPos(), event.getPos(), event.getState());
        });
    }

    @SubscribeEvent
    public static void blockPlaced(BlockEvent.EntityPlaceEvent event) {
        Entity entity = event.getEntity();
        if (entity == null) return;
        LevelChunk chunk = entity.level.getChunkAt(entity.blockPosition());
        StandEffects.getLazyOptional(entity).ifPresent(standEffects -> {
            if (standEffects.getDestroyedBlocks().containsKey(chunk.getPos()) && standEffects.getDestroyedBlocks().get(chunk.getPos()).containsKey(event.getPos()))
                return;
            if (BitesTheDustHelper.bitesTheDustActive)
                standEffects.putDestroyedBlock(chunk.getPos(), event.getPos(), Blocks.AIR.defaultBlockState());

        });
    }

    @SubscribeEvent
    public static void useBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getPlayer();
        if (player == null) return;
        LevelChunk chunk = player.level.getChunkAt(player.blockPosition());
        if (event.getUseBlock() == Event.Result.ALLOW && player.level.getBlockEntity(event.getPos()) != null)
            StandEffects.getLazyOptional(player).ifPresent(standEffects -> {
                if (BitesTheDustHelper.bitesTheDustActive)
                    standEffects.putAlteredTileEntity(chunk.getPos(), event.getPos());
            });
    }

    @SubscribeEvent
    public static void livingDeath(LivingDeathEvent event) {

        if(!event.getEntityLiving().getCommandSenderWorld().isClientSide() && event.getEntityLiving() instanceof Player){
            Player player = ((Player) event.getEntityLiving());
            if(bitesTheDustPlayer != null) {
                if (bitesTheDustPlayer.equals(player)) {
                    if (bitesTheDustActive){
                        event.setCanceled(true);
                        player.setHealth(4f);
                        rewindBitesTheDust();
                    }
                }else if(previousBitesTheDustPlayer != null && previousBitesTheDustPlayer.equals(player)){
                    if(!bitesTheDustActive){
                        fatedDeaths.clear();
                    }
                }
            }
        }
        
        if(!event.getEntity().level.isClientSide() && event.getEntity() instanceof LivingEntity){
            if(BitesTheDustHelper.bitesTheDustActive && !killedEntities.contains(((LivingEntity) event.getEntity()))){
                BitesTheDustCapability bitesTheDustCapability = BitesTheDustCapability.getCapabilityFromEntity(event.getEntity());
                Vec3 originPos = new Vec3(bitesTheDustCapability.getX(), bitesTheDustCapability.getY(), bitesTheDustCapability.getZ());
                BitesTheDustHelper.addFatedDeath(((LivingEntity) event.getEntity()), originPos);

                if(!(event.getEntity() instanceof Player)){
                    killedEntities.add((LivingEntity) event.getEntity());
                    event.getEntity().discard();
                    Util.revive(event.getEntity());
                }
            }
        }

        if(!event.getEntity().level.isClientSide() && event.getEntity() instanceof Player){
            ServerPlayer playerEntity = (ServerPlayer) event.getEntity();
            Stand.getLazyOptional(playerEntity).ifPresent(props -> {


                //This is completely safe to call on players who cannot stop time. All it does is remove any timestopped chunks matching the player's UUID.
                TimestopHelper.endTimeStop(playerEntity);

                java.util.stream.StreamSupport.stream(playerEntity.getLevel().getAllEntities().spliterator(), false)
                        .filter(entity -> entity instanceof SheerHeartAttackEntity)
                        .filter(entity -> ((SheerHeartAttackEntity) entity).standMaster != null)
                        .filter(entity -> ((SheerHeartAttackEntity) entity).standMaster.equals(playerEntity))
                        .forEach(Entity::discard);

                java.util.stream.StreamSupport.stream(playerEntity.getLevel().getAllEntities().spliterator(), false)
                        .filter(entity -> entity instanceof AbstractStandEntity)
                        .filter(entity -> ((AbstractStandEntity) entity).getMaster().equals(playerEntity))
                        .forEach(entity -> {
                            if (entity instanceof KingCrimsonEntity) {
                                if (((KingCrimsonEntity) entity).timeEraseActive) {
                                    ((KingCrimsonEntity) entity).endTimeSkip();
                                }
                            }
                            entity.discard();
                        });
            });
        }

        if(event.getEntity() instanceof Player && event.getSource() != null &&event.getSource().getEntity() != null){

            Player player = (Player) event.getEntity();

            Stand stand = Stand.getCapabilityFromPlayer(player);

            if(stand.getStandID() == Util.StandID.THE_WORLD && !stand.getStandOn() && stand.getReflexCooldown() == 0 && stand.getStandUnsummonedTime() > (20 * 60)){
                player.setHealth(4f);
                event.setCanceled(true);
                stand.setReflexCooldown(20 * 60 * 10);
                stand.setInvincibleTicks(40);
                stand.setCurrentStandEnergy(50);
                stand.setEnergyCooldown(40);
                stand.setStandUnsummonedTime(0);
                stand.setInstantTimeStopFrame(TheWorldEntity.QUICK_STOP_DURATION);

                stand.setStandOn(true);

                AbstractStandEntity standEntity = Util.StandID.getStandByID(stand.getStandID(), player.level);
                Vec3 position = player.getLookAngle().multiply(0.5, 1, 0.5).add(player.position()).add(0, 0.5, 0);
                standEntity.moveTo(position.x, position.y, position.z, player.getYRot(), player.getXRot());
                standEntity.setMaster(player);
                standEntity.setMasterUUID(player.getUUID());
                standEntity.followMaster();
                if (DiamondIsUncraftableConfig.CLIENT.playStandSpawnSounds.get())
                    standEntity.playSpawnSound();
                DiamondIsUncraftable.INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> player), new SSyncStandMasterPacket(standEntity.getId(), player.getId()));
                player.level.addFreshEntity(standEntity);

                java.util.stream.StreamSupport.stream(player.getServer().getLevel(player.level.dimension()).getAllEntities().spliterator(), false)
                        .filter(taunted -> !taunted.equals(player))
                        .filter(taunted -> taunted instanceof LivingEntity)
                        .filter(taunted -> taunted.distanceTo(player) <= 7)
                        .forEach(taunted -> {
                            Vec3 modifiedPositionVec = new Vec3(player.getX(), taunted.getY(), player.getZ());
                            Vec3 vec = taunted.position().subtract(modifiedPositionVec).normalize();
                            Util.teleportUntilWall((LivingEntity) taunted, vec, 7);

                            if(taunted instanceof Player){
                                Util.applyUnactionableTicks(((Player) taunted), 20);

                                Stand.getLazyOptional(((Player) taunted)).ifPresent(effect -> {
                                    effect.setInstantTimeStopFrame(TheWorldEntity.QUICK_STOP_DURATION);
                                });
                            }
                        });

            }else {
                stand.setMomentum(0);
                stand.setRage(0);
                stand.setPreventUnsummon(false);
                stand.setPreventUnsummon2(false);
                stand.setStandOn(false);
            }
        }

        if(event.isCanceled()){
            if(event.getEntity() instanceof ServerPlayer && !event.getEntity().level.isClientSide()){
                ServerPlayer playerEntity = (ServerPlayer) event.getEntity();
                Util.giveAdvancement(playerEntity, "secondchance");
            }
        }
    }

    @SubscribeEvent
    public static void effectRemovedEvent(PotionEvent.PotionRemoveEvent event) {
        if (event.getPotion() == MobEffects.GLOWING) event.getEntityLiving().setGlowingTag(false);
    }

    @SubscribeEvent
    public static void standUnsummoned(StandEvent.StandUnsummonedEvent event) {
        Player player = event.getPlayer();
        Stand.getLazyOptional(player).ifPresent(props -> {
            player.setInvulnerable(false);
            player.setNoGravity(false);
            if (!player.isCreative() && !player.isSpectator())
                ((net.minecraft.server.level.ServerPlayer) player).setGameMode(GameType.SURVIVAL);
        });
    }

    @SubscribeEvent
    public static void standPunchEntityEvent(StandAttackEvent.EntityHit event) {

    }

    @SubscribeEvent
    public static void standPunchBlockEvent(StandAttackEvent.BlockHit event) {

    }

    /*
    Handle with care! It's very easy to make the player immortal by breaking this method.
    Times I've made the player immortal by breaking this method: IIII
    */
    @SubscribeEvent
    public static void cancelDamage(LivingAttackEvent event) {
        LivingEntity entity = event.getEntityLiving();
        if (entity instanceof Player) {
            Stand.getLazyOptional((Player) entity).ifPresent(stand -> {

                if(stand.getExperiencingTimeSkip()){
                    event.setCanceled(true);
                    return;
                }

                if (!entity.level.isClientSide() && stand.getStandOn()) {
                    boolean shouldCancelDamage = false;
                    AtomicReference<AbstractStandEntity> standEntity = new AtomicReference<>();

                    java.util.stream.StreamSupport.stream(entity.getServer().getLevel(entity.level.dimension()).getAllEntities().spliterator(), false)
                            .filter(entity1 -> entity1 instanceof AbstractStandEntity)
                            .filter(entity1 -> ((AbstractStandEntity) entity1).getMaster() != null)
                            .filter(entity1 -> ((AbstractStandEntity) entity1).getMaster().equals(entity))
                            .forEach(entity1 -> standEntity.set((AbstractStandEntity) entity1));

                    if (standEntity.get() instanceof IOnMasterAttacked) {
                        Entity source = event.getSource().getEntity();
                        if (source != null) {

                            IOnMasterAttacked counterStand = ((IOnMasterAttacked) standEntity.get());
                            counterStand.onMasterAttacked(source, event.getAmount());
                            shouldCancelDamage = stand.getCounterBuffer();
                            stand.setCounterBuffer(false);

                            if(shouldCancelDamage && source instanceof LivingEntity){
                                ((LivingEntity) source).addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20, 1));
                                entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20, 1));
                            }
                        }
                    }
                    event.setCanceled(shouldCancelDamage);

                    if(!entity.level.isClientSide() && stand.getInvincibleTicks() > 0){
                        event.setCanceled(true);
                    }
                }
            });
        }
    }

    @SubscribeEvent
    public static void itemPickup(EntityItemPickupEvent event) {
        ItemEntity entity = event.getItem();
        if (entity == null) return;
        if (entity.level.isClientSide) return;
        StandEffects.getLazyOptional(entity).ifPresent(props -> {
            if (props.isBomb()) {
                Player player = entity.level.getPlayerByUUID(props.getStandUser());
                if (player != null) {
                    Util.standExplosion(player, player.level, entity.position(), KillerQueenEntity.explosionRange, 3, KillerQueenEntity.maxExplosionDamage, KillerQueenEntity.minExplosionDamage);
                }
                entity.discard();
                event.setCanceled(true);
            }
        });
    }

    @SubscribeEvent
    public static void itemExpire(ItemExpireEvent event) {
        ItemEntity entity = event.getEntityItem();
        if (entity == null) return;
        if (entity.getItem().getOrCreateTag().getBoolean("bomb"))
            StandEffects.getLazyOptional(entity).ifPresent(props -> {
                Player player = entity.level.getPlayerByUUID(props.getStandUser());
                Stand.getLazyOptional(player).ifPresent(stand -> stand.setAbilityUseCount(0));
            });
    }

    @SubscribeEvent
    public static void noClip(LivingEvent.LivingUpdateEvent event) {
        if (event.getEntityLiving() instanceof Player)
            Stand.getLazyOptional((Player) event.getEntityLiving()).ifPresent(props -> {
                Player player = (Player) event.getEntityLiving();
                if (!player.isSpectator())
                    player.noPhysics = props.getNoClip();
                else
                    player.noPhysics = true;
            });
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getWorld() instanceof Level)) return;
        Level world = (Level) event.getWorld();
        if (world.isClientSide) return;
        LevelChunk chunk = world.getChunkAt(event.getPos());
        StandChunkEffects.getLazyOptional(chunk).ifPresent(props -> {
            props.getSoundEffects().forEach((uuid, list) -> {
                if (list.size() > 0) {
                    List<BlockPos> removalList = new ArrayList<>();
                    list.forEach(blockPos -> {
                        if (blockPos.equals(event.getPos())) {
                            Player player = world.getPlayerByUUID(uuid);
                            Util.activateEchoesAbility(world, event.getPlayer(), event.getPos(), props, player, removalList);
                        }
                    });
                    list.removeAll(removalList);
                }
            });
        });
    }

    @SubscribeEvent
    public static void explosionEvent(ExplosionEvent.Detonate event) {
        Level world = event.getWorld();
        if (world == null || world.isClientSide) return;
        event.getAffectedBlocks().forEach(blockPos ->
                StandChunkEffects.getLazyOptional(world.getChunkAt(blockPos)).ifPresent(props -> {
                    props.getBombs().forEach((uuid, pos) -> {
                        if (pos.equals(blockPos)) {
                            Player player = world.getPlayerByUUID(uuid);
                            Stand.getLazyOptional(player).ifPresent(stand -> {
                                stand.setBlockPos(BlockPos.ZERO);
                                stand.setAbilityUseCount(0);
                            });
                            props.removeBombPos(player);
                        }
                    });
                    props.getSoundEffects().forEach((uuid, list) -> {
                        if (list.size() > 0) {
                            List<BlockPos> removalList = new ArrayList<>();
                            list.forEach(pos -> {
                                if (pos.equals(blockPos)) {
                                    Player player = world.getPlayerByUUID(uuid);
                                    Stand.getLazyOptional(player).ifPresent(stand -> stand.setAbilityUseCount(stand.getAbilityUseCount() - 1));
                                    removalList.add(pos);
                                }
                            });
                            list.removeAll(removalList);
                        }
                    });
                }));
    }

    @SubscribeEvent
    public static void livingTick(LivingEvent.LivingUpdateEvent event) {
        LivingEntity entity = event.getEntityLiving();
        if (entity instanceof AbstractStandEntity) return;
        StandEffects.getLazyOptional(entity).ifPresent(props -> {

            if (props.getSoundEffect() != 0) {
                if (entity.level.random.nextInt(40) == 1) {
                    SoundEvent soundEvent = SoundEvents.GENERIC_EXPLODE;
                    switch (props.getSoundEffect()) {
                        case 1: {
                            soundEvent = SoundEvents.ANVIL_BREAK;
                            break;
                        }
                        case 2: {
                            soundEvent = SoundEvents.BELL_BLOCK;
                            break;
                        }
                        case 3: {
                            soundEvent = SoundEvents.FIREWORK_ROCKET_BLAST;
                            break;
                        }
                        case 4: {
                            soundEvent = SoundEvents.GENERIC_BURN;
                            break;
                        }
                        case 6: {
                            soundEvent = SoundEvents.GLASS_BREAK;
                            break;
                        }
                        case 7: {
                            soundEvent = SoundEvents.METAL_PRESSURE_PLATE_CLICK_ON;
                            break;
                        }
                    }
                    if (props.getSoundEffect() != 2 && props.getSoundEffect() % 2 == 0) {
                        for (int i = 0; i < 2; i++) {
                            entity.level.playSound(null, entity.blockPosition(), soundEvent, SoundSource.BLOCKS, 1, 1);
                            entity.hurt(DamageSource.DROWN, 2);
                        }
                    } else {
                        entity.level.playSound(null, entity.blockPosition(), soundEvent, SoundSource.BLOCKS, 1, 1);
                        entity.hurt(DamageSource.DROWN, 2);
                    }
                }
            }


            if (props.isRotating()) {
                entity.setYRot(entity.getYRot() + 30);
                if (entity.getYRot() > 180)
                    entity.setYRot(-180);
                entity.hurt(DamageSource.OUT_OF_WORLD, 2);
            }
            if (props.isThreeFreeze()) {
                Player playerEntity = entity.level.getPlayerByUUID(props.getStandUser());
                if (playerEntity == null || !playerEntity.isAlive()) return;
                float distance = entity.distanceTo(playerEntity);
                if (distance < 2)
                    entity.setDeltaMovement(0, -1000, 0);
                else if (distance < 3)
                    entity.setDeltaMovement(0, -100, 0);
                else if (distance < 6)
                    entity.setDeltaMovement(0, -50, 0);
                else if (distance < 10)
                    entity.setDeltaMovement(0, -10, 0);
                else if (distance < 15)
                    entity.setDeltaMovement(0, -5, 0);
                else
                    return;
                entity.hasImpulse = true;
            }
            if (props.getTimeNearFlames() > 0) {
                entity.setSecondsOnFire((int) (props.getTimeNearFlames() * 2));
                props.setTimeNearFlames(props.getTimeNearFlames() - 0.25);
                if (entity.level.random.nextInt(6) == 1)
                    entity.hurt(DamageSource.IN_FIRE, 2);
            }
        });

        StandChunkEffects.getLazyOptional(entity.level.getChunkAt(entity.blockPosition())).ifPresent(props ->
                props.getSoundEffects().forEach((uuid, list) -> {
                    if (list.size() > 0) {
                        List<BlockPos> removalList = new ArrayList<>();
                        list.forEach(blockPos -> {
                            if (blockPos.equals(entity.blockPosition().offset(0, -1, 0)))
                                Util.activateEchoesAbility(entity.level, entity, blockPos, props, entity.level.getPlayerByUUID(uuid), removalList);
                        });
                        list.removeAll(removalList);
                    }
                }));
    }



}
