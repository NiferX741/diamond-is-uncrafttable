package io.github.halffocused.diamond_is_uncraftable.network.message.server;

import io.github.halffocused.diamond_is_uncraftable.capability.StandChunkEffects;
import io.github.halffocused.diamond_is_uncraftable.network.message.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SSyncStandChunkEffectCapabilityPacket implements IMessage<SSyncStandChunkEffectCapabilityPacket> {
    private Tag data;
    private ChunkPos pos;

    public SSyncStandChunkEffectCapabilityPacket() {
    }

    private SSyncStandChunkEffectCapabilityPacket(CompoundTag compoundNBT, int x, int z) {
        this.data = compoundNBT;
        this.pos = new ChunkPos(x, z);
    }

    public SSyncStandChunkEffectCapabilityPacket(StandChunkEffects props) {
        this.data = StandChunkEffects.STORAGE.writeNBT(StandChunkEffects.STAND_CHUNK_EFFECTS, props, null);
        this.pos = props.getChunk();
    }

    @Override
    public void encode(SSyncStandChunkEffectCapabilityPacket message, FriendlyByteBuf buffer) {
        buffer.writeNbt((CompoundTag) message.data);
        buffer.writeInt(message.pos.x);
        buffer.writeInt(message.pos.z);
    }

    @Override
    public SSyncStandChunkEffectCapabilityPacket decode(FriendlyByteBuf buffer) {
        return new SSyncStandChunkEffectCapabilityPacket(buffer.readNbt(), buffer.readInt(), buffer.readInt());
    }

    @Override
    public void handle(SSyncStandChunkEffectCapabilityPacket message, Supplier<NetworkEvent.Context> ctx) {
        if (ctx.get().getDirection() == NetworkDirection.PLAY_TO_CLIENT) {
            ctx.get().enqueueWork(() -> {
                if (Minecraft.getInstance().level == null) return;
                StandChunkEffects.getLazyOptional(Minecraft.getInstance().level.getChunk(message.pos.x, message.pos.z)).ifPresent(props ->
                        StandChunkEffects.STORAGE.readNBT(StandChunkEffects.STAND_CHUNK_EFFECTS, props, null, message.data));
            });
        }
        ctx.get().setPacketHandled(true);
    }
}
