package io.github.halffocused.diamond_is_uncraftable.client.entity.render;

import io.github.halffocused.diamond_is_uncraftable.entity.StandArrowEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SpectralArrowRenderer;
import net.minecraft.resources.ResourceLocation;

public class StandArrowRenderer extends ArrowRenderer<StandArrowEntity> {
    public StandArrowRenderer(EntityRendererProvider.Context manager) {
        super(manager);
    }

    @Override
    public ResourceLocation getTextureLocation(StandArrowEntity entity) {
        return new net.minecraft.resources.ResourceLocation("textures/entity/projectiles/spectral_arrow.png");
    }
}
