package io.github.halffocused.diamond_is_uncraftable.util.frame;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.init.SoundInit;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.Random;

public class DamageFrame extends AbstractFrame {

    private float damage;
    private Vec3 motion;
    private double hitboxRange;
    private int pierce;
    private boolean blockable;

    public DamageFrame(int tickIn, float damageIn, Vec3 motionIn, double hitboxRangeIn, int pierceIn, boolean blockableIn) {
        super(tickIn);
        damage = damageIn;
        motion = motionIn;
        hitboxRange = hitboxRangeIn;
        pierce = pierceIn;
        blockable = blockableIn;
    }

    public float getDamage(){
        return damage;
    }

    public Vec3 getDeltaMovement(){
        return motion;
    }

    public double getHitboxRange(){
        return hitboxRange;
    }

    public int getPierce(){
        return pierce;
    }

    public boolean getBlockable(){
        return blockable;
    }

    @Override
    public void doThing(AbstractStandEntity standEntity, Move assignedMove) {
        if(standEntity.getServer() == null) {return;}
        Level world = standEntity.getServer().getLevel(standEntity.level.dimension());
        if(world == null) {return;}

        AABB hitbox = Util.getAttackHitbox(standEntity, getHitboxRange());

        List<Entity> listOfEntities = world.getEntities(standEntity, hitbox);

        Random random = standEntity.getRandom();
        boolean soundFlag = false;
        int entitiesHit = 0;

        for (Entity entity : listOfEntities) {
            if (entity instanceof LivingEntity) {
                if (entity != standEntity && entitiesHit < getPierce()) {
                    if (!(entity.equals(standEntity.getMaster())) || (entity.equals(standEntity.getMaster()) && assignedMove.getCanDamageMaster())) {

                        Util.dealStandDamage(standEntity, (LivingEntity) entity, getDamage(), getDeltaMovement(), getBlockable());

                        entitiesHit++;
                    }
                }
            }
        }

        if(entitiesHit > 0){
            world.playSound(null, standEntity.blockPosition(), Util.getHitSound(standEntity), SoundSource.NEUTRAL, 0.5F, 0.6f / (random.nextFloat() * 0.3f + 1) * 2);
        }else{
            world.playSound(null, standEntity.blockPosition(), SoundInit.PUNCH_MISS.get(), SoundSource.NEUTRAL, 0.25F, 0.6f / (random.nextFloat() * 0.3f + 1) * 2);
            standEntity.setMostRecentlyDamagedEntity(null);
        }
    }
}
