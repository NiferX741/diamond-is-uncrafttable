package io.github.halffocused.diamond_is_uncraftable.util.frame;

import io.github.halffocused.diamond_is_uncraftable.entity.stand.AbstractStandEntity;
import io.github.halffocused.diamond_is_uncraftable.util.Util;
import io.github.halffocused.diamond_is_uncraftable.util.movesets.Move;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.Level;

import java.util.List;

public class EffectFrame extends AbstractFrame{

    private MobEffectInstance effect;
    private double hitboxRange;

    public EffectFrame(int tickIn, MobEffectInstance effectIn, double hitboxRangeIn) {
        super(tickIn);
        effect = effectIn;
        hitboxRange = hitboxRangeIn;
    }

    public double getHitboxRange(){
        return hitboxRange;
    }

    public MobEffectInstance getEffectInstance(){
        return effect;
    }


    @Override
    public void doThing(AbstractStandEntity standEntity, Move assignedMove) {
        if(standEntity.getServer() == null) {return;}
        Level world = standEntity.getServer().getLevel(standEntity.level.dimension());
        if(world == null || standEntity.getServer().getLevel(standEntity.level.dimension()) == null) {return;}

        AABB hitbox = Util.getAttackHitbox(standEntity, getHitboxRange());

        List<Entity> listOfEntities = world.getEntities(standEntity, hitbox);

        for (Entity parseList : listOfEntities) {
            if (parseList instanceof LivingEntity) {
                ((LivingEntity) parseList).addEffect(getEffectInstance());
            }
        }
    }

}
